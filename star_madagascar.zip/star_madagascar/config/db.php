<?php
// ============================================================
// config/db.php — Connexion MySQL
// Star Madagascar · Système de gestion
// ============================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'star_madagascar');
define('DB_USER', 'root');       // Changer en production
define('DB_PASS', '');           // Changer en production
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'Star Madagascar');
define('APP_VERSION', '1.0');
define('APP_URL', 'http://localhost/star_madagascar');

// Fuseau horaire Madagascar
date_default_timezone_set('Indian/Antananarivo');

// ── Connexion PDO ──────────────────────────────────────────
function getDB(): PDO {
  static $pdo = null;
  if ($pdo === null) {
    $dsn = "mysql:host=" . DB_HOST
         . ";dbname=" . DB_NAME
         . ";charset=" . DB_CHARSET;
    try {
      $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
      ]);
      // Même fuseau horaire pour MySQL que pour PHP : sinon NOW()/CURDATE()
      // (MySQL) et date() (PHP) ne sont pas d'accord chez un hébergeur réglé
      // en UTC (InfinityFree...) — commandes « d'hier », heure limite faussée...
      $pdo->exec("SET time_zone = '+03:00'");
    } catch (PDOException $e) {
      // En production : logger l'erreur, ne pas l'afficher
      http_response_code(500);
      die(json_encode(['error' => 'Connexion base de données impossible.']));
    }
  }
  return $pdo;
}

// ============================================================
// assets/js/app.js
// Star Madagascar — Scripts globaux
// ============================================================

// ── Notifications polling ─────────────────────────────────
(function() {
  const ROOT = document.querySelector('meta[name="app-root"]')?.content || '';

  function chargerNotifications() {
    fetch(ROOT + '/api/notifications.php?action=lister')
      .then(r => r.json())
      .then(data => {
        if (!data.success) return;

        const badge = document.querySelector('.notif-badge');
        if (badge) {
          badge.style.display = data.nb_non_lues > 0 ? '' : 'none';
        }

        // Mettre à jour le panneau si ouvert
        const panel = document.getElementById('notifPanel');
        if (panel && panel.style.display !== 'none') {
          renderNotifications(data.notifications);
        }
      })
      .catch(() => {});
  }

  function renderNotifications(notifs) {
    const panel = document.getElementById('notifPanel');
    if (!panel) return;

    if (!notifs.length) {
      panel.innerHTML = '<div style="padding:1.5rem;text-align:center;color:var(--text-mute);font-size:.78rem">Aucune notification</div>';
      return;
    }

    panel.innerHTML = notifs.map(n => `
      <div style="padding:.7rem 1rem;border-bottom:1px solid var(--bg3);
                  background:${n.lu ? '' : 'rgba(232,0,28,.04)'};cursor:pointer"
           onclick="marquerLu(${n.id})">
        <div style="font-size:.78rem;font-weight:${n.lu ? '400' : '600'};color:var(--text);margin-bottom:.2rem">
          ${escHtml(n.titre)}
        </div>
        <div style="font-size:.7rem;color:var(--text-mute);line-height:1.4">${escHtml(n.message)}</div>
        <div style="font-size:.63rem;color:var(--text-mute);margin-top:.2rem">
          ${formatDate(n.created_at)}
        </div>
      </div>
    `).join('');
  }

  function marquerLu(id) {
    fetch(ROOT + '/api/notifications.php?action=marquer_lu&id=' + id)
      .then(() => chargerNotifications())
      .catch(() => {});
  }

  function escHtml(str) {
    const d = document.createElement('div');
    d.appendChild(document.createTextNode(str));
    return d.innerHTML;
  }

  function formatDate(dateStr) {
    const d = new Date(dateStr.replace(' ', 'T'));
    const now = new Date();
    const diff = Math.floor((now - d) / 60000);
    if (diff < 1)  return 'À l\'instant';
    if (diff < 60) return `Il y a ${diff} min`;
    if (diff < 1440) return `Il y a ${Math.floor(diff/60)}h`;
    return d.toLocaleDateString('fr-FR');
  }

  // Toggle panneau notifications
  window.toggleNotifPanel = function() {
    let panel = document.getElementById('notifPanel');
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'notifPanel';
      panel.style.cssText = `
        position:fixed;top:var(--topbar-h);right:1rem;z-index:150;
        width:320px;max-height:420px;overflow-y:auto;
        background:var(--bg2);border:1px solid var(--border);
        border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.4);
      `;
      document.body.appendChild(panel);
    }

    if (panel.style.display === 'none' || !panel.style.display) {
      panel.style.display = 'block';
      chargerNotifications();
      fetch(ROOT + '/api/notifications.php?action=marquer_lu')
        .then(() => {
          const badge = document.querySelector('.notif-badge');
          if (badge) badge.style.display = 'none';
        });
    } else {
      panel.style.display = 'none';
    }
  };

  // Charger au démarrage
  chargerNotifications();
  // Polling toutes les 30 secondes
  setInterval(chargerNotifications, 30000);

  // Attacher au bouton notification
  document.addEventListener('DOMContentLoaded', function() {
    const btn = document.querySelector('.notif-btn');
    if (btn) btn.onclick = window.toggleNotifPanel;

    // Fermer panneau en cliquant ailleurs
    document.addEventListener('click', function(e) {
      const panel = document.getElementById('notifPanel');
      if (panel && !panel.contains(e.target) && !e.target.closest('.notif-btn')) {
        panel.style.display = 'none';
      }
    });
  });

})();

// ── Utilitaires globaux ───────────────────────────────────

// Formater nombre en Ariary
window.formatAr = function(n) {
  return Math.round(n).toLocaleString('fr-FR') + ' Ar';
};

// Formater Hl
window.formatHl = function(n) {
  return parseFloat(n).toFixed(4) + ' hl';
};

// Confirmer avant action dangereuse
window.confirmerAction = function(msg, form) {
  if (confirm(msg || 'Confirmer cette action ?')) {
    if (form) form.submit();
    return true;
  }
  return false;
};

// Toast notification
window.toast = function(msg, type) {
  const t = document.createElement('div');
  t.style.cssText = `
    position:fixed;bottom:1.5rem;right:1.5rem;z-index:9999;
    background:${type==='error'?'var(--red)':'#1e6b3c'};
    color:#fff;padding:.7rem 1.2rem;border-radius:8px;
    font-size:.82rem;font-family:Inter,sans-serif;
    box-shadow:0 4px 16px rgba(0,0,0,.3);
    animation:slideIn .3s ease;
  `;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3500);
};

// Style animation toast
const style = document.createElement('style');
style.textContent = `
@keyframes slideIn {
  from { transform:translateY(20px);opacity:0; }
  to   { transform:translateY(0);opacity:1; }
}
`;
document.head.appendChild(style);

# STAR Madagascar — version fusionnée (V2 + corrigé)

Cette version combine la V2 (base retenue : menus, tableaux de bord, design)
avec les corrections fonctionnelles nécessaires pour que l'application
tourne sans erreur et sans page manquante.

## Nouveautés de la version 21

**Installation** : réimporter `star_madagascar_base.sql`, ou pour une base à
conserver exécuter la section « Version 21 » de `migration_correctifs.sql`.

### Graphiques (Chart.js 4, fichier local `assets/js/vendor/chart.umd.min.js`)
- Fonctions communes dans `includes/graphiques.php` (fonctionne sans internet).
- Admin : réalisé agence par jour vs objectif journalier, volume par famille,
  par type de client, top 10 produits ; Rapports : volume et CA sur 30 jours.
- Manager : volume et visites de l'équipe (30 j), volume du mois par commercial.
- Commercial : activité sur 30 jours, ventes du mois par famille.
- Logistique : entrées / sorties sur 14 jours, stock par famille.
- Caissier : encaissements sur 14 jours, répartition par moyen de paiement.
- Distributeur : achats et livraisons sur 30 jours.

### Règles de consigne STAR (grille officielle « Événements privés » star.mg)
- 30/33 cl : 400 Ar · 50 cl : 500 Ar (Booster 50 cl : 400 Ar) · 65 cl : 500 Ar
  · 100 cl et plus : 700 Ar · casier : 8 000 Ar · PET et canettes : 0 Ar.
- Règle centralisée dans `consigne_bouteille_regle()` (`includes/tarifs.php`) ;
  dans Admin > Produits la consigne est pré-remplie selon la grille et reste
  modifiable, le prix logé est recalculé automatiquement.
- Cristal 50 cl verre n'a pas de valeur dans la grille publiée : 500 Ar appliqué
  (règle 50 cl), à corriger si l'agence utilise un autre montant.

### Icônes et logos
- Les emojis des boutons et menus sont remplacés par des icônes vectorielles
  Lucide (licence ISC) via `includes/icones.php`.
- Logo officiel STAR dans le menu, la barre du haut, la page de connexion et
  les reçus ; logos MVola, Orange Money et Airtel Money dans la caisse
  (choix du moyen de paiement par tuiles) et dans l'historique.
- Cartes produits plus opaques pour rester lisibles au-dessus du fond animé.

## Nouveautés de la version 20

**Installation** : supprimer l'ancienne base puis importer `star_madagascar_base.sql`
(nouveau catalogue + données de simulation). Base à conserver : exécuter la fin
de `migration_correctifs.sql` (section « Version 20 »).

### Objectif de l'agence (`includes/objectifs.php`)
- L'admin saisit l'objectif **mensuel** en HL ; il est réparti automatiquement
  par **semaine** et par **jour ouvré (lundi → samedi)** et enregistré dans la
  table `objectifs` (`semaine`, `jour`). Page Objectifs : tableau semaine par
  semaine et jour par jour, objectif / réalisé / %.
- **Réalisé agence** = volume des commandes **payées** des clients qui achètent
  à l'agence (Distributeur, GMS, Station, Demi-gros). Les commandes des petits
  clients (livrés par un distributeur) n'y comptent pas.
- Le volume du **commercial** sert seulement à suivre son activité et sa prime
  (tableaux de bord commercial et manager) ; son objectif reste le nombre de
  visites. Tableaux de bord admin et manager : barres jour / semaine / mois.

### Reçus
- Le volume HL de chaque ligne (à droite) valait toujours 0 : il est relu en
  base. Reçu commun commercial + distributeur (`includes/recu.php`), imprimable.
  Le détail de commande du distributeur affiche aussi les bouteilles et le volume.

### Photo de profil
- Mon profil : envoi d'une photo (JPG/PNG/WEBP, 2 Mo max, contenu vérifié),
  aperçu, suppression ; photo affichée dans le menu. Dossier
  `assets/images/profils/` protégé (aucun script exécutable).
- Confirmation du nouveau mot de passe (8 caractères minimum).

### Sécurité et corrections
- **Protection CSRF** sur tous les formulaires (jeton ajouté automatiquement).
- Logistique : « Retours consigne enregistrés aujourd'hui » (le compteur « en
  attente » restait toujours à 0).
- Menu « Visite client » : ouvre maintenant la liste des clients du secteur
  (avant, il renvoyait au tableau de bord). Un commercial ne peut visiter /
  commander que pour les clients de son secteur.
- Distributeur : bouton « Livrée » pour confirmer une livraison (les commandes
  restaient « Validée » indéfiniment) ; les livraisons en retard restent visibles.
- Défauts : seulement sur une commande livrée qui contient le produit ; un
  défaut déjà traité ne peut plus être revalidé ; le commercial est prévenu d'un rejet.
- Une demande de code client ne peut plus être activée sans code (bouton activer).
- Rapport journalier / tableau manager : % calculés sur les visites (et non HL ÷ nombre de clients).
- Dates en français sur les tableaux de bord, initiales accentuées correctes.

### Données
- **Catalogue** : 65 produits de la grille officielle STAR « Prix STAR NU TTC »
  (https://www.star.mg/evenements-prives/) : THB Pilsener/Fresh, Gold, Beaufort,
  Booster, Caprice (5 parfums × 4 formats), Youzou, World Cola, D'jino, Tonic,
  XXL, Cristal, Cristalline, Eau Vive ; Queen's 65 cl et Racines 33 cl au tarif
  agence du 13/10/2025.
- **Simulation** (dates relatives au jour de l'import) : 3 secteurs, 18 comptes
  (tous les rôles), 39 clients (distributeurs, GMS, stations, demi-gros,
  épiceries, bars, restaurants + demandes de code en cours), ~870 commandes
  sur 45 jours à tous les statuts, ~1 300 visites avec relevés de stock,
  réceptions et sorties de stock, retours de consigne, défauts à chaque étape,
  objectifs agence et commerciaux. Script de génération : `outils/generer_donnees.py`.
- Comptes : admin@… / `Admin@Star2025` ; tous les autres / `Test@2025`
  (directeur, manager, manager2, manager3, commercial1 à 6, logistique, logistique2,
  caissier, caissier2, distributeur1 à 3 — tous `@star-madagascar.mg`).

## Correctifs de la version 19

**Base existante** : exécuter `migration_correctifs.sql` une fois.
**Nouvelle installation** : importer `star_madagascar_base.sql` (déjà à jour).

### Stock (calcul centralisé dans `includes/stock.php`)
- `RETOUR_DEFAUT` (remplacement d'un produit défectueux) était compté comme une
  **entrée** : il est maintenant compté comme une **sortie** (un produit neuf part).
- La quantité d'un défaut (saisie en **bouteilles**) était enregistrée comme des
  **casiers** : 2 bouteilles cassées ajoutaient 2 casiers au stock.
- `RETOUR_CONSIGNE` (bouteilles/casiers **vides**) n'est plus compté comme du
  stock vendable.
- Casiers et bouteilles sont additionnés en bouteilles puis redécoupés : vendre
  3 bouteilles entame un casier au lieu d'afficher « -3 bouteilles ».
- Validation de sortie (logistique) : blocage des doubles sorties (double clic,
  F5) et vérification du stock disponible avant la sortie.
- Erreur SQL 1690 (colonnes UNSIGNED) évitée quand le stock devient négatif.

### Consigne (`includes/tarifs.php`)
- Verre uniquement : 400 Ar (30/33/35/50 cl), 500 Ar (65 cl), 700 Ar (100 cl et
  +), casier 8 000 Ar. PET et canettes : 0.
- Un casier plein = kit × consigne bouteille + 8 000 Ar (avant, seul le casier
  vide était facturé). Le PAG kit logé est recalculé automatiquement.
- Page commande distributeur : la consigne était comptée deux fois à l'écran.

### Nouveau rôle CAISSIER (`modules/caissier/`)
- Reçoit les bordereaux / références Mobile Money et confirme les paiements
  (référence obligatoire hors espèces, montant reçu contrôlé, référence en
  double refusée). Historique des encaissements (aussi visible par
  l'admin/directeur). L'admin ne confirme plus les paiements.
- Compte de test : `caissier@star-madagascar.mg` / `Test@2025`.

### Autres corrections
- `star_madagascar_base.sql` s'arrêtait en erreur (objectif agence avec
  `commercial_id` NULL interdit) : commandes, visites et index n'étaient pas créés.
- Commande commerciale : montants, crédit consigne, type et mode de paiement du
  client recalculés côté serveur (ils étaient modifiables depuis le navigateur).
- Visite client : relevé de stock affiché en tableau (comme Produits), sans flou
  par champ — le contenu ne disparaît plus au défilement ; messages de
  confirmation ; bouton « Prendre une commande » présélectionne le client.
- Fuseau horaire MySQL aligné sur PHP (+03:00).
- Mots de passe : bcrypt (`password_hash`), conversion automatique des anciens
  SHA-256 à la connexion.
- `preview_dashboard.php` : protégé par connexion admin et corrigé (tables supprimées).

## Installation
1. Créer une base `star_madagascar` (vide) dans MySQL/phpMyAdmin.
2. Importer `star_madagascar_base.sql` — un seul fichier, tables + données
   de test incluses, rien d'autre à exécuter.
3. Vérifier `config/db.php` (hôte, base, utilisateur, mot de passe).
4. Placer le dossier `star_madagascar` dans `htdocs` sous XAMPP.
5. Se connecter avec `admin@star-madagascar.mg` / `Admin@Star2025`, ou l'un
   des comptes de test listés plus bas (mot de passe `Test@2025`).

## Règles métier ajoutées (comptes, consigne, livraison par type de client)

- **Compte d'accès au site** : seul un client de type **Distributeur** a un
  compte utilisateur (email + mot de passe), créé directement depuis
  Clients → Nouveau client dès que le type sélectionné est « Distributeur ».
  Les GMS, Stations, Demi-gros, Épiceries, Bars et Restaurants n'ont jamais
  de compte. Il n'est donc plus possible de créer un utilisateur de rôle
  Distributeur depuis la page **Utilisateurs** — ce rôle y est verrouillé
  (modification des autres champs toujours possible pour un compte existant).
  Si un client change de type et n'est plus Distributeur, son compte est
  automatiquement désactivé.
- **Compte consigne** : seuls les clients **Demi-gros, Distributeur, Station
  et GMS** ont un compte/solde de consigne. Les épiceries, bars et
  restaurants s'approvisionnent auprès d'un distributeur ou d'un demi-gros
  et ne retournent donc jamais de consigne directement à l'agence — ils
  n'apparaissent plus dans la page Retours de consigne ni dans le crédit
  consigne proposé lors d'une commande.
- **Retour de consigne = bouteilles en verre uniquement** : la liste des
  produits proposés lors d'un retour de consigne (module Logistique) est
  filtrée sur `type_emballage = 'VER'` — le plastique (PET) et les canettes
  ne sont pas consignés.
- **Client direct vs petit client (livraison)** : les clients directs
  (Distributeur, GMS, Station, Demi-gros) sont livrés directement par
  l'agence — le champ « Distributeur livreur » ne leur est plus proposé.
  Seuls les petits clients (Épicerie, Bar, Restaurant) s'approvisionnent
  via un distributeur/demi-gros et gardent ce champ.
- DIRECTEUR : accès en lecture seule à Clients, Produits, Utilisateurs,
  Secteurs/Équipes, Objectifs, Commandes (l'ADMIN garde les droits d'écriture).
- Synchronisation secteur → équipe : affecter un commercial à un secteur met
  à jour `utilisateurs.equipe_id` avec l'équipe de ce secteur.
- Statut de présence utilisateur ajouté : En travail, En congé, Absent,
  Suspendu.

## Design : slider produits plein écran

- Le fond animé de **toute l'application** (`includes/layout.php`, donc chaque
  page) et de la page de connexion (`index.php`) affiche les 15 vraies photos
  produits en défilement automatique (aucune flèche, aucun clic — 5 secondes
  par slide, fondu enchaîné).
- Sidebar, topbar, cartes, menu utilisateur, boutons secondaires et champs de
  formulaire sont en verre très dépoli (fond quasi transparent ~9-12% + flou
  26px) pour que le slider soit nettement visible à travers toute
  l'interface, contours et textes restant identiques et bien lisibles.
- Le dégradé du slider (nécessaire à la lisibilité de son propre texte/
  citation) a été adouci pour ne plus assombrir un côté de l'écran plus que
  l'autre.
- `preview_dashboard.php` (à la racine du projet) sert de aperçu autonome
  de ce traitement ; le même réglage est maintenant appliqué à l'ensemble
  du site via `includes/layout.php`.
- Les images sources viennent de `assets/images/produits/` (format WebP,
  ~50 Ko/image) ; le contenu des slides (image, couleur, message) est
  centralisé dans `includes/slider_data.php`, partagé entre la connexion
  et le reste de l'application.

## Déconnexion
Le formulaire de connexion (`index.php`) a `autocomplete="off"` sur l'email
et `autocomplete="new-password"` sur le mot de passe (ce qui empêche la
plupart des navigateurs de proposer un identifiant/mot de passe enregistré),
plus un vidage JS des deux champs au chargement de la page — après une
déconnexion, les champs restent donc vides.

## Menu hamburger (remplace l'ancien menu latéral fixe)
Toute l'application (`includes/layout.php`) est passée d'un topbar + menu
latéral fixes à un bouton hamburger (haut à gauche) qui ouvre un tiroir de
navigation par-dessus le contenu — plus de bandeau latéral qui grignote
l'écran en permanence. Le tiroir reprend tout : pages du rôle, notifications,
profil, déconnexion. Au passage, une règle CSS globale qui forçait
`position:relative` sur tous les enfants directs de `<body>` a été corrigée
(elle aurait annulé le `position:fixed` du hamburger, du tiroir et du fond
plein écran).

## Modales (formulaires en boîte de dialogue)
Les modales (créer/modifier un utilisateur, un client, un produit, une
commande, valider un défaut, etc.) ont leur propre fond noir semi-opaque
déjà présent derrière elles : elles n'ont donc pas besoin d'être
transparentes comme les cartes de page, sous peine de devenir illisibles
et de laisser le contenu défilé transparaître sous l'en-tête figé. Une
nouvelle classe `.modal-box` (fond ~95% opaque, flou) a été appliquée aux
12 boîtes de dialogue du projet (Utilisateurs, Produits, Commandes,
Clients, Historique distributeur, Commande commerciale + sa validation,
Planning, Défauts, Codes clients, Préparation logistique, Stock), ainsi
qu'aux en-têtes figés (« sticky ») de Utilisateurs et Produits qui
devenaient illisibles au défilement.

## Base de données réduite à 13 tables (pour l'UML du mémoire)

Partant du schéma original à 21 tables, un premier nettoyage avait déjà
supprimé 2 tables mortes (`stock_entrepot`, `rapports_journaliers`, jamais
lues nulle part) et une table fantôme (`objectifs_agence`, présente dans un
fichier d'installation obsolète mais jamais utilisée par le code réel). Le
schéma a ensuite été volontairement réduit à **13 tables** en fusionnant 6
paires de tables dont la séparation n'apportait rien de fonctionnel :

| Fusion | Ce qui a changé |
|---|---|
| `familles_produits` → `produits.famille` | La famille d'un produit (ex: "Gold") est un simple champ texte sur le produit, avec autocomplétion dans le formulaire, au lieu d'une table à part. |
| `equipes` → `secteurs` | Un secteur porte directement son nom/zone/description ; plus de notion d'équipe séparée d'un secteur géographique. |
| `affectations_secteur` → `utilisateurs.secteur_id` | Le secteur actuel d'un commercial est un champ direct sur son compte, au lieu d'un historique d'affectations avec dates. On perd l'historique des changements de secteur, pas l'affectation elle-même. |
| `demandes_code_client` → `clients` | Une demande de nouveau client crée directement une ligne `clients` avec `statut='EN_ATTENTE'` (puis `VALIDE_MANAGER`, puis `ACTIF` ou `REJETE`) au lieu d'une table à part recopiée ensuite dans `clients`. Au passage, une **vraie incohérence a été corrigée** : `admin/clients.php` et `admin/codes_clients.php` dupliquaient exactement le même code d'attribution de code client — simplifié une seule fois pour les deux pages. |
| `planning_visites` + `visites_clients` → `visites` | Une visite est une seule ligne qui change de statut : `PLANIFIE` (prévue) devient `VISITE` (réalisée) en place, au lieu de deux tables reliées de façon approximative (le code ne les liait même pas par clé, juste par date). |
| `stock_client_visite` → `visites.stock_releve` (JSON) | Le relevé de stock chez le client (plusieurs produits par visite) est stocké en une seule colonne JSON sur la visite plutôt qu'une table séparée avec une ligne par produit. |

**Tables restantes (13)** : `secteurs`, `utilisateurs`, `produits`, `clients`,
`objectifs`, `visites`, `commandes`, `lignes_commande`, `solde_consigne`,
`retours_consigne`, `mouvements_stock`, `defauts_produits`, `notifications`.

Chacune de ces 13 tables a une raison d'être distincte et facile à justifier
à l'oral. Il serait possible de descendre encore (par exemple fusionner
`solde_consigne` dans `retours_consigne`), mais cela toucherait à la logique
centrale des commandes/paiements avec un risque de régression pour un gain
marginal — nous nous sommes arrêtés au seuil où chaque fusion reste
clairement justifiable.

Les 3 fichiers SQL (`base`, `migration`, `full_install`) ont aussi été
réduits à **un seul fichier** : `star_madagascar_base.sql`, à jour et
directement exécutable (les deux autres étaient redondants et désynchronisés
l'un de l'autre).

## Jeu de données de test

`star_madagascar_base.sql` crée maintenant un jeu de données complet pour
tester le projet immédiatement après import :
- **7 comptes** (un par rôle restant : Directeur, Manager, 2 Commerciaux,
  Logistique, 2 Distributeurs) — mot de passe `Test@2025` pour tous.
- **2 secteurs** (Centre-ville, Périphérie).
- **14 clients** (2 de chaque type : Distributeur, GMS, Station, Demi-gros,
  Épicerie, Bar, Restaurant).
- 2 commandes (une livrée, une en attente), du stock initial, les objectifs
  du mois en cours, une notification et 2 visites (une planifiée, une
  réalisée avec relevé de stock).
- Le compte admin garde son mot de passe dédié `Admin@Star2025`
  (email `admin@star-madagascar.mg`).

## Résultat de la fusion V2 / corrigé

Une comparaison fichier par fichier des deux livraisons a montré que **toutes
les pages présentes dans la V2 existent aussi, à l'identique ou corrigées,
dans la version « corrigé »** — aucune fonctionnalité de la V2 n'a été perdue
en route. En revanche, la V2 avait des incohérences bloquantes que la
version corrigée règle :

### Bugs corrigés (la V2 plantait ou affichait des données fausses)
- `produits.seuil_alerte` était utilisé dans les requêtes SQL (admin/stock,
  logistique/stock, dashboards admin/logistique) alors que cette colonne
  **n'existe pas** dans le schéma fourni (`star_madagascar-1.sql`) → erreur
  SQL fatale. Remplacé par une alerte sur stock nul (`quantite_casiers <= 0`),
  seule règle supportée par les tables fournies.
- Le layout gardait le buffer de sortie ouvert plus longtemps, pour que les
  formulaires en `POST` puissent rediriger sans provoquer
  `Cannot modify header information`.
- Le menu de la V2 pointait déjà vers 10 pages qui n'existaient tout
  simplement pas dans le zip V2 (liens morts / 404) : elles ont été ajoutées
  (voir plus bas).
- Le lien « Mon profil » pointait vers `modules/<rôle>/profil.php`, un
  fichier qui n'existait dans aucun module ; il pointe maintenant vers
  `modules/common/profil.php` (page unique, commune à tous les rôles).
- Le bouton de notifications n'était pas cliquable (pas de lien) ; il pointe
  maintenant vers `modules/common/notifications.php`.
- Saisie des objectifs (admin/objectifs.php) : la V2 tentait d'enregistrer un
  objectif HL par commercial et par mois en `INSERT ... ON DUPLICATE KEY`
  mais avalait silencieusement les erreurs (`catch { /* ignorer */ }`) faute
  de contrainte d'unicité correspondante — les objectifs n'étaient donc pas
  toujours enregistrés. Le modèle a été clarifié : objectif d'**agence** en
  HL (mensuel, une seule valeur) + objectif **commercial** en nombre de
  clients à visiter (le HL vendu reste un indicateur d'activité/performance,
  pas un quota). Les tableaux de bord commercial et manager ont été alignés
  sur ce même modèle pour rester cohérents.
- `modules/admin/utilisateurs.php` définissait une fonction utilisée dans le
  tableau (`role_badge_class`) et la fermeture du layout (`close_layout()`)
  à l'intérieur d'un bloc conditionnel réservé à l'admin — la page plantait
  entièrement (erreur fatale) et s'affichait vide pour un DIRECTEUR. Corrigé.

### Pages ajoutées (référencées par le menu de la V2 mais absentes du zip V2)
- `modules/admin/rapports.php`
- `modules/common/notifications.php`
- `modules/common/profil.php`
- `modules/commercial/clients.php`, `commandes.php`, `objectifs.php`
- `modules/manager/equipe.php`, `commandes.php`, `performances.php`
- `modules/distributeur/consigne.php`

Toutes les tables nécessaires (`notifications`, `retours_consigne`,
`solde_consigne`, `affectations_secteur`, etc.) existaient déjà dans le
schéma de base ; seuls `objectifs_agence` (nouvelle table) et
`utilisateurs.statut_presence` (nouvelle colonne) ont dû être ajoutés par la
migration.

## Limite volontaire
Le design général reprend l'identité visuelle de la V2 (thème sombre,
typographie, cartes) enrichie du fond photo plein écran décrit ci-dessus ;
le travail a porté sur la cohérence des droits, des formulaires, des
données et des flux métier, en plus du design demandé.

## Audit complémentaire (à la demande du client)

- **Vraie cause du problème « Produits/types » persistant** : les listes
  déroulantes natives (`<select>` Famille, Emballage, rôle, secteur, statut,
  etc.) sont dessinées par le **navigateur lui-même** quand on clique dessus
  — leur fond ignore complètement le CSS de la page dans la plupart des
  navigateurs. Résultat : même avec la modale rendue opaque, la liste qui
  s'ouvrait restait blanche et illisible sur fond sombre. Corrigé en
  ajoutant `color-scheme: dark` (une propriété CSS dédiée à ça) sur tout le
  site — le navigateur dessine désormais tous les contrôles natifs
  (select, date, case à cocher...) en thème sombre automatiquement.
- **Incohérence trouvée** : il n'existait aucun moyen de créer une famille
  de produits (« type ») depuis l'interface — seul un choix parmi les
  familles déjà en base était possible, il aurait fallu passer par
  phpMyAdmin pour en ajouter une. Un bouton « + Nouvelle famille » a été
  ajouté sur la page Produits (modale dédiée, code + nom).
- Recherché dans tout le projet d'autres fonctions PHP piégées dans un bloc
  conditionnel (le bug trouvé précédemment sur Utilisateurs) : aucune autre
  occurrence trouvée.

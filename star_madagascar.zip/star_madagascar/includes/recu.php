<?php
// ============================================================
// includes/recu.php
// Reçu / ticket de commande commun (commercial ET distributeur)
// Les lignes et volumes sont relus en base : le volume HL de chaque ligne
// (colonne de droite) vient de lignes_commande.volume_hl.
// ============================================================

function render_recu(PDO $db, int $commande_id, string $emetteur = ''): string {
  $st = $db->prepare("SELECT c.*, cl.nom client_nom, cl.code_client, cl.type client_type,
                             CONCAT(u.prenom,' ',u.nom) commercial_nom
                      FROM commandes c JOIN clients cl ON cl.id=c.client_id
                      LEFT JOIN utilisateurs u ON u.id=c.commercial_id WHERE c.id=?");
  $st->execute([$commande_id]);
  $c = $st->fetch();
  if (!$c) return '';
  $st = $db->prepare("SELECT lc.*, p.description, p.code, p.kit FROM lignes_commande lc
                      JOIN produits p ON p.id=lc.produit_id WHERE lc.commande_id=? ORDER BY lc.id");
  $st->execute([$commande_id]);
  $lignes = $st->fetchAll();

  $e = fn($v) => htmlspecialchars((string)$v);
  $ar = fn($v) => number_format((float)$v, 0, ',', ' ') . ' Ar';
  $hl = fn($v) => number_format((float)$v, 4, ',', ' ') . ' hl';
  $qte = function ($l) {
    $t = [];
    if ($l['quantite_casiers'] > 0)   $t[] = $l['quantite_casiers'] . ' cas.';
    if ($l['quantite_bouteilles'] > 0) $t[] = $l['quantite_bouteilles'] . ' btl';
    return implode(' + ', $t);
  };
  $pied = $c['statut'] === 'EN_ATTENTE_PAIEMENT'
    ? "Paiement à effectuer à l'agence (caisse)"
    : ($c['date_livraison'] ? 'Livraison prévue le ' . date('d/m/Y', strtotime($c['date_livraison'])) : '');

  $lignes_html = '';
  foreach ($lignes as $l) {
    $lignes_html .= '<tr><td class="r-prod"><div class="r-nom">' . $e($l['description']) . '</div>'
      . '<div class="r-det">' . $qte($l) . ' · ' . $ar($l['sous_total']) . '</div></td>'
      . '<td class="r-hl">' . $hl($l['volume_hl']) . '</td></tr>';
  }
  $info = [
    'N° commande' => $c['code_commande'],
    'Date'        => date('d/m/Y H:i', strtotime($c['date_commande'])),
    'Client'      => $c['client_nom'],
    'Code client' => $c['code_client'] ?? '—',
  ];
  if ($c['commercial_nom']) $info['Commercial'] = $c['commercial_nom'];
  else $info['Passée par'] = 'Le client (commande distributeur)';
  $info_html = '';
  foreach ($info as $k => $v) $info_html .= '<div class="r-row"><span>' . $k . '</span><strong>' . $e($v) . '</strong></div>';

  $tot = '<div class="r-row"><span>Produits</span><span>' . $ar($c['montant_ht']) . '</span></div>';
  if ($c['montant_consigne'] > 0) $tot .= '<div class="r-row"><span>Consigne</span><span>' . $ar($c['montant_consigne']) . '</span></div>';
  if ($c['credit_consigne_utilise'] > 0) $tot .= '<div class="r-row r-credit"><span>Crédit consigne</span><span>−' . $ar($c['credit_consigne_utilise']) . '</span></div>';
  $tot .= '<div class="r-row r-total"><span>TOTAL À PAYER</span><span>' . $ar($c['montant_a_payer']) . '</span></div>';
  $tot .= '<div class="r-row r-vol"><span>Volume total</span><span>' . $hl($c['total_hl']) . '</span></div>';

  // Logo officiel STAR (URL absolue : il reste visible dans la fenêtre d'impression)
  $logo = (function_exists('base_url') ? base_url() : '../..') . '/assets/images/logos/star_logo.svg';
  $corps = '<div class="r-head"><img class="r-logo-img" src="' . $e($logo) . '" alt="STAR Madagascar"><div class="r-sub">Agence de Fianarantsoa</div></div>'
    . '<div class="r-sec">' . $info_html . '</div>'
    . '<div class="r-sec"><table class="r-table"><thead><tr><th>Produit</th><th class="r-hl">Volume</th></tr></thead><tbody>'
    . $lignes_html . '</tbody></table></div>'
    . '<div class="r-sec">' . $tot . '</div>'
    . '<div class="r-foot">' . $e($pied) . '<br>Merci pour votre commande · Star Madagascar</div>';

  $css = '.recu{max-width:420px;margin:0 auto;border:1px solid var(--border,#ccc);border-radius:12px;overflow:hidden;background:rgba(18,18,18,.92);color:var(--text,#111);font-size:.78rem}
.recu .r-head{background:#fff;color:#333;text-align:center;padding:.9rem 1rem .7rem;border-bottom:4px solid #E8001C}.recu .r-logo-img{height:48px;width:auto;display:block;margin:0 auto .2rem}.recu .r-sub{font-size:.7rem;color:#555}
.recu .r-sec{padding:.8rem 1rem;border-bottom:1px dashed var(--border,#ccc)}.recu .r-row{display:flex;justify-content:space-between;gap:1rem;margin:.2rem 0}
.recu .r-row span:first-child{color:var(--text-mute,#666)}.recu .r-table{width:100%;border-collapse:collapse}.recu .r-table th{text-align:left;font-size:.62rem;text-transform:uppercase;color:var(--text-mute,#666);padding-bottom:.3rem}
.recu .r-table td{padding:.35rem 0;border-top:1px solid rgba(128,128,128,.2);vertical-align:top}.recu .r-hl,.recu .r-table th.r-hl{text-align:right;white-space:nowrap;font-weight:700;color:#E8001C;padding-left:.8rem}
.recu .r-nom{font-weight:600}.recu .r-det{font-size:.66rem;color:var(--text-mute,#666)}.recu .r-credit span{color:#00a050 !important}
.recu .r-total{font-size:.95rem;font-weight:700;margin-top:.4rem;padding-top:.4rem;border-top:1px solid rgba(128,128,128,.3)}.recu .r-total span:last-child{color:#E8001C}
.recu .r-vol span:last-child{font-weight:700}.recu .r-foot{padding:.8rem;text-align:center;font-size:.66rem;color:var(--text-mute,#666)}';
  $id = 'recu_' . $commande_id;
  return '<style>' . $css . '</style><div class="recu" id="' . $id . '">' . $corps . '</div>
<div style="max-width:420px;margin:.8rem auto 0"><button type="button" class="btn btn-secondary" style="width:100%;justify-content:center"
  onclick="imprimerRecu(\'' . $id . '\')">🖨️ Imprimer le reçu</button></div>
<script>function imprimerRecu(id){const w=window.open("","_blank","width=420,height=650");
w.document.write("<!DOCTYPE html><html><head><meta charset=\'UTF-8\'><title>Reçu</title><style>"+document.querySelector("#"+id).previousElementSibling.textContent
+" body{font-family:Arial,sans-serif;margin:0;padding:10px;background:#fff} .recu{background:#fff;color:#000;border-color:#999} .recu .r-row span:first-child,.recu .r-det,.recu .r-foot,.recu .r-table th{color:#555}</style></head><body>"
+document.getElementById(id).outerHTML+"</body></html>");w.document.close();w.focus();setTimeout(()=>w.print(),400);}</script>';
}

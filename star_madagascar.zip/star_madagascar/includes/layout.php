<?php
// ============================================================
// includes/layout.php
// Header + Sidebar + structure commune
// Usage : include_layout('Titre de la page', ['ROLE1','ROLE2']);
// ============================================================

function include_layout(string $page_title, array $roles = []): array {
  require_once __DIR__ . '/auth_guard.php';
  auth_guard($roles);
  $user = current_user();
  $role = $user['role'];

  // Menu selon le rôle
  $menus = get_menu($role);

  // Chemin relatif vers la racine
  $depth = substr_count($_SERVER['SCRIPT_NAME'], '/') - 2;
  $root  = str_repeat('../', $depth);

  require_once __DIR__ . '/icones.php';
  ob_start('embellir_icones');   // émojis -> icônes SVG (includes/icones.php)
  ?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?= csrf_token() ?>">
<?php require_once __DIR__ . '/graphiques.php'; echo graphiques_script($root); ?>
<title><?= htmlspecialchars($page_title) ?> · Star Madagascar</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
<style>
/* ── VARIABLES ── */
:root {
  color-scheme: dark;
  --bg:       #111111;
  --bg2:      rgba(18,18,18,.42);
  --bg3:      rgba(24,24,24,.62);
  --bg4:      rgba(28,28,28,.55);
  --border:   rgba(255,255,255,.14);
  --red:      #E8001C;
  --red-dim:  rgba(232,0,28,.12);
  --text:     #f5f5f5;
  --text-dim: #cfcfcf;
  --text-mute:#a8a8a8;
  --modal-bg: rgba(24,24,24,.95);
  --bg-solid: rgba(16,16,16,.88);      /* cartes produits : lisibles au-dessus du fond animé */
  --bg-solid-sel: rgba(58,8,14,.92);
}

/* Filet de sécurité : quel que soit ce qu'il y a derrière (photo produit
   claire ou sombre), le texte garde un contour sombre qui le rend lisible. */
body, .side-drawer, .app-shell .card, .form-input, input, select, textarea {
  text-shadow: 0 1px 3px rgba(0,0,0,.85);
}

/* Les modales (formulaires en boîte de dialogue) ont déjà leur propre fond
   noir semi-opaque derrière elles : elles n'ont pas besoin d'être
   transparentes comme les cartes de page, sous peine de devenir illisibles. */
.modal-box{
  background: var(--modal-bg) !important;
  backdrop-filter: blur(20px) !important; -webkit-backdrop-filter: blur(20px) !important;
}
.modal-box .modal-sticky-header{ background: var(--modal-bg) !important; }
.modal-box [style*="var(--bg2)"], .modal-box [style*="var(--bg3)"], .modal-box [style*="var(--bg4)"] {
  background: rgba(255,255,255,.06) !important;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html, body { height: 100%; }
body {
  font-family: 'Inter', sans-serif;
  background: var(--bg);
  color: var(--text);
  overflow: hidden;
}

/* ── MENU HAMBURGER : tiroir qui s'ouvre vers la droite ── */
.hamburger {
  position: fixed; top: 1.1rem; left: 1.2rem; z-index: 60;
  width: 42px; height: 42px; border-radius: 10px;
  background: rgba(255,255,255,.08); border: 1px solid var(--border);
  backdrop-filter: blur(26px); -webkit-backdrop-filter: blur(26px);
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; transition: background .15s;
}
.hamburger:hover { background: rgba(255,255,255,.16); }
.hamburger span { display: block; width: 18px; height: 2px; background: #fff; position: relative; transition: background .2s; }
.hamburger span::before, .hamburger span::after {
  content: ''; position: absolute; left: 0; width: 18px; height: 2px; background: #fff; transition: transform .25s;
}
.hamburger span::before { top: -6px; }
.hamburger span::after  { top: 6px; }
.hamburger.open span { background: transparent; }
.hamburger.open span::before { transform: translateY(6px) rotate(45deg); }
.hamburger.open span::after  { transform: translateY(-6px) rotate(-45deg); }

.drawer-overlay {
  position: fixed; inset: 0; z-index: 55; background: rgba(0,0,0,.35);
  opacity: 0; pointer-events: none; transition: opacity .3s;
}
.drawer-overlay.open { opacity: 1; pointer-events: auto; }

.side-drawer {
  position: fixed; top: 0; left: 0; bottom: 0; width: 280px; z-index: 58;
  background: rgba(14,14,14,.74); backdrop-filter: blur(30px); -webkit-backdrop-filter: blur(30px);
  border-right: 1px solid var(--border);
  padding: 1.4rem 1rem 1.5rem; overflow-y: auto;
  transform: translateX(-100%); transition: transform .32s cubic-bezier(.4,0,.2,1);
  display: flex; flex-direction: column;
}
.side-drawer.open { transform: translateX(0); }
.drawer-brand {
  display: flex; align-items: center; gap: .6rem;
  font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 1rem;
  padding: .5rem .7rem 1.2rem;
}
.drawer-logo { height: 36px; width: auto; display: block; }
.side-drawer .drawer-brand { flex-direction: column; align-items: flex-start; gap: .15rem; padding-left: 3.7rem; padding-top: .2rem; }
.drawer-agence { font-size: .68rem; font-weight: 500; color: var(--text-mute); font-family: Inter, sans-serif; line-height: 1.2; }
.i-svg { width: 1.1em; height: 1.1em; display: inline-block; vertical-align: -.18em; flex-shrink: 0; }
.btn .i-svg { width: 1.05em; height: 1.05em; }
.kpi-label .i-svg, .badge .i-svg { width: .95em; height: .95em; }
.chart-card { margin-bottom: 1rem; }
.chart-title { font-size: .85rem; font-weight: 600; margin-bottom: .2rem; }
.chart-sub { font-size: .7rem; color: var(--text-mute); margin-bottom: .6rem; }
.chart-box { position: relative; width: 100%; }
.pay-chip { display: inline-flex; align-items: center; gap: .35rem; white-space: nowrap; }
.pay-chip img { height: 18px; width: auto; background: #fff; border-radius: 3px; padding: 1px 2px; }
a.card { color: var(--text); }
a.card .i-svg { color: var(--red); }
.topbar-logo { height: 26px; width: auto; margin-left: auto; opacity: .95; }
.drawer-brand-icon {
  width: 30px; height: 30px; border-radius: 7px; background: var(--red);
  display: flex; align-items: center; justify-content: center; font-size: .95rem;
}
.drawer-user {
  display: flex; align-items: center; gap: .7rem;
  padding: .7rem; margin-bottom: 1rem;
  background: rgba(255,255,255,.05); border: 1px solid var(--border); border-radius: 12px;
}
.user-avatar img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
.user-avatar {
  width: 32px; height: 32px; border-radius: 50%; flex-shrink: 0; overflow: hidden;
  background: var(--red); color: #fff;
  display: flex; align-items: center; justify-content: center;
  font-size: .75rem; font-weight: 700;
}
.drawer-user-name { font-size: .82rem; font-weight: 600; color: #fff; }
.drawer-user-role {
  font-size: .62rem; font-weight: 600; color: var(--red);
  background: var(--red-dim); display: inline-block; padding: .1rem .4rem; border-radius: 4px; margin-top: .15rem;
}
.drawer-title {
  font-size: .62rem; font-weight: 600; color: var(--text-mute);
  letter-spacing: .1em; text-transform: uppercase;
  padding: .8rem .7rem .3rem;
}
.side-drawer a {
  display: flex; align-items: center; gap: .7rem;
  padding: .6rem .7rem; border-radius: 9px;
  font-size: .82rem; font-weight: 500; color: var(--text-dim);
  text-decoration: none; transition: background .15s, color .15s; position: relative;
}
.side-drawer a:hover { background: rgba(255,255,255,.08); color: #fff; }
.side-drawer a.active { background: var(--red-dim); color: var(--red); }
.side-drawer a.active::before {
  content: ''; position: absolute; left: 0; top: 20%; bottom: 20%;
  width: 3px; border-radius: 2px; background: var(--red);
}
.side-drawer a.danger:hover { color: var(--red); }
.side-drawer .ico { font-size: .95rem; width: 18px; text-align: center; display: inline-flex; justify-content: center; }
.side-drawer .ico .i-svg { width: 18px; height: 18px; }
.drawer-badge {
  margin-left: auto; min-width: 18px; height: 18px;
  background: var(--red); color: #fff; border-radius: 9px;
  font-size: .6rem; font-weight: 700;
  display: flex; align-items: center; justify-content: center; padding: 0 .3rem;
}
.drawer-spacer { flex: 1; }

/* ── CONTENU ── */
.main-content {
  position: relative; height: 100vh;
  overflow-y: auto; overflow-x: hidden;
  padding: 1.3rem 1.7rem 1.6rem;
}
.content-topbar { padding-left: 3.3rem; margin-bottom: .9rem; display: flex; align-items: center; gap: .8rem; min-height: 42px; }
.content-topbar .topbar-page { font-size: .8rem; color: var(--text-mute); }

/* ── COMPOSANTS RÉUTILISABLES ── */

/* Page header */
.page-header { margin-bottom: 1.6rem; }
.page-header-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: .3rem; }
.page-title {
  font-family: 'Space Grotesk', sans-serif;
  font-size: 1.4rem; font-weight: 700;
  text-shadow: 0 2px 16px rgba(0,0,0,.6);
}
.page-subtitle { font-size: .8rem; color: var(--text-mute); }

/* Boutons */
.btn {
  display: inline-flex; align-items: center; gap: .4rem;
  padding: .55rem 1rem; border-radius: 8px;
  font-size: .8rem; font-weight: 600;
  font-family: 'Inter', sans-serif;
  border: none; cursor: pointer; text-decoration: none;
  transition: all .15s;
}
.btn-primary { background: rgba(232,0,28,.88); color: #fff; backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); }
.btn-primary:hover { opacity: .88; }
.btn-secondary {
  background: var(--bg3); color: var(--text-dim);
  border: 1px solid var(--border);
}
.btn-secondary:hover { color: var(--text); border-color: #444; }
.btn-sm { padding: .35rem .7rem; font-size: .73rem; }

/* Cards */
.card {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.2rem;
  position: relative; overflow: hidden;
}
.card-top-line::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, var(--red), transparent);
}

/* KPI card */
.kpi-card { }
.kpi-label { font-size: .7rem; color: var(--text-mute); font-weight: 500; margin-bottom: .5rem; }
.kpi-value {
  font-family: 'Space Grotesk', sans-serif;
  font-size: 1.9rem; font-weight: 700; line-height: 1;
}
.kpi-value .unit { font-size: .85rem; color: var(--red); font-weight: 500; margin-left: .2rem; }
.kpi-trend { font-size: .7rem; margin-top: .4rem; }
.kpi-trend.up { color: #00c864; }
.kpi-trend.down { color: var(--red); }
.kpi-trend.neutral { color: var(--text-mute); }

/* Progress */
.progress-bar {
  height: 4px; background: var(--bg4); border-radius: 2px; margin-top: .7rem;
}
.progress-fill {
  height: 4px; border-radius: 2px;
  background: linear-gradient(90deg, var(--red), #ff4444);
  transition: width .6s ease;
}
.progress-label {
  display: flex; justify-content: space-between;
  font-size: .63rem; color: var(--text-mute); margin-top: .3rem;
}

/* Table */
.table-wrap { overflow-x: auto; }
.data-table { width: 100%; border-collapse: collapse; font-size: .78rem; }
.data-table th {
  text-align: left; padding: .6rem .8rem;
  font-size: .65rem; font-weight: 600; color: var(--text-mute);
  text-transform: uppercase; letter-spacing: .06em;
  border-bottom: 1px solid var(--border);
  background: var(--bg2); position: sticky; top: 0;
}
.data-table td {
  padding: .65rem .8rem; border-bottom: 1px solid var(--bg3);
  color: var(--text-dim); vertical-align: middle;
}
.data-table tr:hover td { background: var(--bg3); }
.data-table tr:last-child td { border-bottom: none; }

/* Badges */
.badge {
  display: inline-flex; align-items: center;
  padding: .2rem .55rem; border-radius: 5px;
  font-size: .65rem; font-weight: 600;
}
.badge-green  { background: rgba(0,200,100,.12); color: #00c864; }
.badge-red    { background: var(--red-dim); color: var(--red); }
.badge-orange { background: rgba(255,160,0,.12); color: #ffa000; }
.badge-blue   { background: rgba(0,120,255,.12); color: #4d94ff; }
.badge-mute   { background: var(--bg3); color: var(--text-mute); }

/* Grid layouts */
.grid-4 { display: grid; grid-template-columns: repeat(4,1fr); gap: 1rem; }
.grid-3 { display: grid; grid-template-columns: repeat(3,1fr); gap: 1rem; }
.grid-2 { display: grid; grid-template-columns: repeat(2,1fr); gap: 1rem; }

/* Responsive grids */
@media (max-width: 1200px) { .grid-4 { grid-template-columns: repeat(2,1fr); } }
@media (max-width: 900px)  { .grid-3 { grid-template-columns: repeat(2,1fr); } }
@media (max-width: 640px)  {
  .grid-4, .grid-3, .grid-2 { grid-template-columns: 1fr; }
}

/* Alert */
.alert {
  padding: .8rem 1rem; border-radius: 8px;
  font-size: .8rem; margin-bottom: 1rem;
  display: flex; align-items: center; gap: .6rem;
}
.alert-success { background: rgba(0,200,100,.08); border: 1px solid rgba(0,200,100,.2); color: #00c864; }
.alert-error   { background: var(--red-dim); border: 1px solid rgba(232,0,28,.2); color: #ff6b6b; }
.alert-info    { background: rgba(0,120,255,.08); border: 1px solid rgba(0,120,255,.2); color: #4d94ff; }
/* ── SLIDER GLOBAL EN ARRIÈRE-PLAN (photos produits réelles) ── */
.app-slider-bg{position:fixed;inset:0;z-index:0;overflow:hidden;pointer-events:none;background:#0c0c0c}
.app-slider-bg .bg-slide{
  position:absolute;inset:0;opacity:0;transition:opacity 1.6s ease;
  background-image:
    linear-gradient(100deg,rgba(9,9,9,.62) 0%,rgba(9,9,9,.50) 34%,rgba(9,9,9,.38) 58%,rgba(9,9,9,.48) 100%),
    var(--bg-img);
  background-repeat:no-repeat;
  background-position:center, right 3vw bottom -30px;
  background-size:cover, auto 88%;
}
.app-slider-bg .bg-slide.active{opacity:1}
.app-slider-bg .bg-slide::after{content:"";position:absolute;inset:0;background:radial-gradient(circle at 82% 28%, var(--accent-glow), transparent 50%)}
.app-slider-bg .bg-content{position:absolute;left:6vw;bottom:9vh;max-width:460px}
.app-slider-bg .bg-tag{display:inline-block;color:#fff;background:var(--accent,var(--red));font-size:.6rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:.25rem .6rem;border-radius:4px;margin-bottom:.7rem}
.app-slider-bg .bg-quote{font-family:'Space Grotesk',sans-serif;font-size:clamp(1.3rem,2.6vw,2.3rem);font-weight:700;line-height:1.18;color:#fff;text-shadow:0 2px 24px rgba(0,0,0,.7)}
.app-slider-bg .bg-sub{margin-top:.6rem;font-size:.75rem;color:rgba(255,255,255,.75);text-shadow:0 1px 10px rgba(0,0,0,.7)}
@media (max-width:900px){.app-slider-bg .bg-slide{background-position:center, center bottom -10px;background-size:cover, auto 46%}.app-slider-bg .bg-content{left:5vw;right:5vw;bottom:auto;top:6vh;max-width:none}}

/* ── VERRE DÉPOLI : l'interface laisse voir le slider en dessous ── */
.app-shell .card, .btn-secondary, .data-table th, .form-input, select, input, textarea {
  backdrop-filter: blur(26px); -webkit-backdrop-filter: blur(26px);
}
/* Le fond principal ne pose plus de voile : seules les cartes/panneaux
   gardent une légère teinte, pour que le slider soit visible entre elles. */
.app-shell .main-content{background:transparent}
/* La carte utilise bien la variable --bg2 (avant, une valeur .09 codée en dur
   l'écrasait et rendait les cartes presque invisibles sur les photos claires). */
.app-shell .card{background:var(--bg2); border-color: rgba(255,255,255,.14); box-shadow:0 8px 22px rgba(0,0,0,.25)}
/* Pas de flou individuel sur les éléments À L'INTÉRIEUR d'une carte : la carte
   floute déjà le fond. Des dizaines de backdrop-filter imbriqués (un par champ)
   font disparaître le contenu au défilement sur Chrome/Edge/Android. */
.app-shell .card input, .app-shell .card select, .app-shell .card textarea,
.app-shell .card .btn-secondary, .app-shell .card .data-table th,
.app-shell .card .form-input, .prod-card input{backdrop-filter:none; -webkit-backdrop-filter:none}
/* Très longues listes (relevé de stock en visite...) : fond plus opaque, sans
   flou — un calque flouté de plusieurs milliers de pixels de haut dépasse la
   taille de texture du GPU et devient blanc/invisible au scroll. */
.app-shell .card.card-long{backdrop-filter:none; -webkit-backdrop-filter:none; background:rgba(16,16,16,.9)}
.qty-input{width:90px;background:var(--bg3);border:1px solid var(--border);border-radius:7px;
  padding:.4rem .6rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif;text-align:center}
.qty-input:focus{outline:none;border-color:var(--red)}
.app-shell > .main-content{position:relative;z-index:1}
@media (prefers-reduced-motion:reduce){.app-slider-bg .bg-slide{transition:none}}
</style>
</head>
<body class="app-shell">
<?php require_once __DIR__ . '/slider_data.php'; $bg_slides = slider_produits(); ?>
<div class="app-slider-bg" aria-hidden="true">
  <?php foreach ($bg_slides as $i => $s): ?>
  <div class="bg-slide<?= $i === 0 ? ' active' : '' ?>" style="--bg-img:url('<?= $root ?>assets/images/produits/<?= $s['img'] ?>');--accent:<?= $s['accent'] ?>;--accent-glow:<?= $s['accent'] ?>33">
    <div class="bg-content">
      <div class="bg-tag"><?= htmlspecialchars($s['tag']) ?></div>
      <div class="bg-quote"><?= $s['quote'] ?></div>
      <div class="bg-sub"><?= htmlspecialchars($s['sub']) ?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- HAMBURGER + TIROIR DE NAVIGATION -->
<div class="hamburger" id="hamburger" onclick="toggleDrawer()"><span></span></div>
<div class="drawer-overlay" id="drawerOverlay" onclick="toggleDrawer(false)"></div>
<nav class="side-drawer" id="sideDrawer">
  <div class="drawer-brand"><img src="<?= $root ?>assets/images/logos/star_logo_white.png" alt="STAR Madagascar" class="drawer-logo"><span class="drawer-agence">Agence Fianarantsoa</span></div>

  <div class="drawer-user">
    <div class="user-avatar"><?php if (!empty($_SESSION['user_photo'])): ?><img src="<?= $root ?>assets/images/profils/<?= rawurlencode($_SESSION['user_photo']) ?>" alt=""><?php else: ?><?= htmlspecialchars(initiales($user['nom'])) ?><?php endif; ?></div>
    <div>
      <div class="drawer-user-name"><?= htmlspecialchars($user['nom']) ?></div>
      <div class="drawer-user-role"><?= role_label($role) ?></div>
    </div>
  </div>

  <?php foreach ($menus as $section => $items): ?>
    <div class="drawer-title"><?= htmlspecialchars($section) ?></div>
    <?php foreach ($items as $item): ?>
      <a href="<?= $root . $item['url'] ?>" class="<?= is_active($item['url']) ? 'active' : '' ?>">
        <span class="ico"><?= $item['icon'] ?></span>
        <span><?= $item['label'] ?></span>
        <?php if (!empty($item['badge'])): ?>
          <span class="drawer-badge"><?= $item['badge'] ?></span>
        <?php endif; ?>
      </a>
    <?php endforeach; ?>
  <?php endforeach; ?>

  <div class="drawer-title">Compte</div>
  <a href="<?= $root ?>modules/common/notifications.php"><span class="ico">🔔</span> <span>Notifications</span></a>
  <a href="<?= $root ?>modules/common/profil.php"><span class="ico">👤</span> <span>Mon profil</span></a>
  <div class="drawer-spacer"></div>
  <a href="<?= $root ?>auth/logout.php" class="danger" style="color:#E8001C"><span class="ico">🚪</span> <span>Déconnexion</span></a>
</nav>

<!-- MAIN -->
<main class="main-content">
  <div class="content-topbar"><span class="topbar-page"><?= htmlspecialchars($page_title) ?></span><img src="<?= $root ?>assets/images/logos/star_logo_white.png" alt="STAR" class="topbar-logo"></div>
  <?php
  // Le layout reste dans le buffer jusqu'à close_layout().
  // Cela permet aux formulaires POST de faire des redirections sans
  // provoquer « Cannot modify header information ».
  return ['user' => $user, 'root' => $root];
}

// ── Helpers ───────────────────────────────────────────────

function role_label(string $role): string {
  $labels = [
    'ADMIN'          => 'Admin',
    'DIRECTEUR'      => 'Directeur',
    'MANAGER'        => 'Manager',
    'MANAGER_INTERIM'=> 'Manager',
    'COMMERCIAL'     => 'Commercial',
    'LOGISTIQUE'     => 'Logistique',
    'CAISSIER'       => 'Caissier',
    'DISTRIBUTEUR'   => 'Distributeur',
  ];
  return $labels[$role] ?? $role;
}

/** Initiales (compatible accents, sans l'extension mbstring) : « Dépôt Tsaramandroso » -> « DT » */
function initiales(string $nom): string {
  preg_match_all('/(?:^|\s)(\p{L})/u', $nom, $m);
  $i = implode('', array_slice($m[1], 0, 2));
  return $i !== '' ? strtoupper($i) : '?';
}

/** Date en français (ex. « lundi 28 septembre 2026 ») sans dépendre de l'extension intl */
function date_fr(?int $ts = null): string {
  $ts = $ts ?? time();
  $j = ['dimanche','lundi','mardi','mercredi','jeudi','vendredi','samedi'][(int)date('w', $ts)];
  $m = ['','janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'][(int)date('n', $ts)];
  return $j . ' ' . date('j', $ts) . ' ' . $m . ' ' . date('Y', $ts);
}

function is_active(string $url): bool {
  $current = $_SERVER['SCRIPT_NAME'] ?? '';
  return str_ends_with($current, basename($url));
}

function get_menu(string $role): array {
  $menus = [];

  // Menu commun
  $common = [
    'modules/' . strtolower(str_replace('_INTERIM','', $role)) . '/dashboard.php' =>
      ['icon'=>'📊', 'label'=>'Tableau de bord'],
  ];

  switch ($role) {
    case 'ADMIN':
    case 'DIRECTEUR':
      $menus['Gestion'] = [
        ['url'=>'modules/admin/dashboard.php',    'icon'=>'📊', 'label'=>'Tableau de bord'],
        ['url'=>'modules/admin/utilisateurs.php', 'icon'=>'👥', 'label'=>'Utilisateurs'],
        ['url'=>'modules/admin/clients.php',      'icon'=>'🏪', 'label'=>'Clients'],
        ['url'=>'modules/admin/produits.php',     'icon'=>'🍺', 'label'=>'Produits'],
        ['url'=>'modules/admin/secteurs.php',     'icon'=>'🗺️',  'label'=>'Secteurs'],
        ['url'=>'modules/admin/objectifs.php',    'icon'=>'🎯', 'label'=>'Objectifs'],
      ];
      $menus['Suivi'] = [
        ['url'=>'modules/admin/commandes.php',    'icon'=>'📋', 'label'=>'Commandes'],
        ['url'=>'modules/admin/stock.php',        'icon'=>'📦', 'label'=>'Stock entrepôt'],
        ['url'=>'modules/caissier/historique.php','icon'=>'💰', 'label'=>'Encaissements'],
        ['url'=>'modules/admin/rapports.php',     'icon'=>'📈', 'label'=>'Rapports'],
      ];
      break;

    case 'MANAGER':
    case 'MANAGER_INTERIM':
      $menus['Commercial'] = [
        ['url'=>'modules/manager/dashboard.php',     'icon'=>'📊', 'label'=>'Tableau de bord'],
        ['url'=>'modules/manager/equipe.php',        'icon'=>'👥', 'label'=>'Mon équipe'],
        ['url'=>'modules/manager/commandes.php',     'icon'=>'📋', 'label'=>'Commandes'],
        ['url'=>'modules/manager/performances.php',  'icon'=>'📈', 'label'=>'Performances'],
      ];
      $menus['Actions'] = [
        ['url'=>'modules/manager/codes_clients.php', 'icon'=>'🆔', 'label'=>'Codes clients'],
        ['url'=>'modules/manager/defauts.php',       'icon'=>'⚠️',  'label'=>'Défauts produits'],
        ['url'=>'modules/manager/rapport.php',       'icon'=>'📧', 'label'=>'Rapport journalier'],
      ];
      break;

    case 'COMMERCIAL':
      $menus['Terrain'] = [
        ['url'=>'modules/commercial/dashboard.php',  'icon'=>'📊', 'label'=>'Tableau de bord'],
        ['url'=>'modules/commercial/planning.php',   'icon'=>'📅', 'label'=>'Mon planning'],
        ['url'=>'modules/commercial/visite.php',     'icon'=>'🚶', 'label'=>'Visite client'],
        ['url'=>'modules/commercial/commande.php',   'icon'=>'📋', 'label'=>'Nouvelle commande'],
      ];
        $menus['Traitement'] = [
        ['url'=>'modules/commercial/signaler_defaut.php',    'icon'=>'⚠️',  'label'=>'Défauts produits'],
        ];
        break;
        

      
      $menus['Suivi'] = [
        ['url'=>'modules/commercial/commandes.php',  'icon'=>'📂', 'label'=>'Mes commandes'],
        ['url'=>'modules/commercial/objectifs.php',  'icon'=>'🎯', 'label'=>'Mes objectifs'],
        ['url'=>'modules/commercial/clients.php',    'icon'=>'🏪', 'label'=>'Mes clients'],
      ];
      break;

    case 'LOGISTIQUE':
      $menus['Entrepôt'] = [
        ['url'=>'modules/logistique/dashboard.php',  'icon'=>'📊', 'label'=>'Tableau de bord'],
        ['url'=>'modules/logistique/a_preparer.php', 'icon'=>'📦', 'label'=>'À préparer'],
        ['url'=>'modules/logistique/stock.php',      'icon'=>'🏭', 'label'=>'Stock entrepôt'],
        ['url'=>'modules/logistique/mouvements.php', 'icon'=>'🔄', 'label'=>'Mouvements'],
      ];
      $menus['Traitement'] = [
        ['url'=>'modules/logistique/consignes.php',  'icon'=>'🍾', 'label'=>'Retours consigne'],
        ['url'=>'modules/logistique/defauts.php',    'icon'=>'⚠️',  'label'=>'Défauts produits'],
      ];
      break;

    case 'CAISSIER':
      $menus['Caisse'] = [
        ['url'=>'modules/caissier/dashboard.php',  'icon'=>'📊', 'label'=>'Tableau de bord'],
        ['url'=>'modules/caissier/paiements.php',  'icon'=>'💳', 'label'=>'Paiements à encaisser'],
        ['url'=>'modules/caissier/historique.php', 'icon'=>'📂', 'label'=>'Historique encaissements'],
      ];
      break;

    case 'DISTRIBUTEUR':
      $menus['Commandes'] = [
        ['url'=>'modules/distributeur/dashboard.php', 'icon'=>'📊', 'label'=>'Tableau de bord'],
        ['url'=>'modules/distributeur/a_livrer.php',  'icon'=>'🚚', 'label'=>'À livrer demain'],
        ['url'=>'modules/distributeur/commande.php',  'icon'=>'📋', 'label'=>'Passer commande'],
        ['url'=>'modules/distributeur/historique.php','icon'=>'📂', 'label'=>'Historique'],
      ];
      $menus['Compte'] = [
        ['url'=>'modules/distributeur/consigne.php',  'icon'=>'🍾', 'label'=>'Mon solde consigne'],
      ];
      break;
  }

  return $menus;
}

function close_layout(): void {
  $footer = <<<'HTML'
</main>
<script>
// Jeton CSRF ajouté automatiquement à tous les formulaires POST (y compris ceux
// créés plus tard en JavaScript et ceux envoyés par form.submit()).
(function(){
  const TOKEN = document.querySelector('meta[name="csrf-token"]')?.content || '';
  function ajouter(form){
    if (!form || (form.method || '').toLowerCase() !== 'post') return;
    if (form.querySelector('input[name="_csrf"]')) return;
    const i = document.createElement('input');
    i.type = 'hidden'; i.name = '_csrf'; i.value = TOKEN;
    form.appendChild(i);
  }
  document.querySelectorAll('form').forEach(ajouter);
  new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => {
    if (n.nodeType !== 1) return;
    if (n.tagName === 'FORM') ajouter(n);
    n.querySelectorAll && n.querySelectorAll('form').forEach(ajouter);
  }))).observe(document.body, {childList:true, subtree:true});
  document.addEventListener('submit', e => ajouter(e.target), true);
  const nativeSubmit = HTMLFormElement.prototype.submit;
  HTMLFormElement.prototype.submit = function(){ ajouter(this); return nativeSubmit.call(this); };
})();
function toggleDrawer(force) {
  const drawer = document.getElementById('sideDrawer');
  const overlay = document.getElementById('drawerOverlay');
  const burger = document.getElementById('hamburger');
  const open = typeof force === 'boolean' ? force : !drawer.classList.contains('open');
  drawer.classList.toggle('open', open);
  overlay.classList.toggle('open', open);
  burger.classList.toggle('open', open);
}
(function(){
  const slides = document.querySelectorAll('.app-slider-bg .bg-slide');
  if (!slides.length) return;
  let i = 0;
  setInterval(function(){
    slides[i].classList.remove('active');
    i = (i + 1) % slides.length;
    slides[i].classList.add('active');
  }, 5000);
})();
</script>
</body></html>
HTML;
  echo $footer;
  if (ob_get_level() > 0) ob_end_flush();
}

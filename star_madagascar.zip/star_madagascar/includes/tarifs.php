<?php
// ============================================================
// includes/tarifs.php
// Règles de prix centralisées (consigne + calcul d'une ligne de commande)
//
// Consigne : grille officielle STAR (https://www.star.mg/evenements-prives/,
// colonne « consigne unitaire ») — verre uniquement, PET et canettes = 0 :
//   - bouteille 30 / 33 cl            : 400 Ar
//   - bouteille 50 cl (bières)        : 500 Ar  (Gold, Beaufort…)
//   - bouteille 50 cl Booster          : 400 Ar
//   - bouteille 65 cl                  : 500 Ar
//   - bouteille 100 cl et plus         : 700 Ar
//   - casier vide                      : 8 000 Ar
// Ces valeurs sont proposées par défaut à la création d'un produit et restent
// modifiables par l'administrateur (fiche produit) si STAR change sa grille.
// Un casier plein vendu « logé » = produit + (kit × consigne bouteille) + consigne casier.
// ============================================================

const CONSIGNE_CASIER = 8000;

/** Consigne STAR par défaut d'une bouteille (contenance, emballage, famille) */
function consigne_bouteille_regle(int $contenance_cl, string $type_emballage, string $famille = ''): int {
  if ($type_emballage !== 'VER') return 0;
  if ($contenance_cl >= 100) return 700;
  if ($contenance_cl >= 65)  return 500;
  if ($contenance_cl >= 50)  return stripos($famille, 'booster') !== false ? 400 : 500;
  return 400;
}

/** Prix de consigne d'un casier vide selon l'emballage */
function consigne_casier_regle(string $type_emballage): int {
  return $type_emballage === 'VER' ? CONSIGNE_CASIER : 0;
}

/** Consigne totale d'un casier PLEIN (bouteilles + casier) */
function consigne_casier_plein(array $p): float {
  return (int)$p['kit'] * (float)$p['consigne_bouteille'] + (float)$p['consigne_casier'];
}

/**
 * Calcule une ligne de commande à partir des données produit en base.
 * Retour : ['vol'=>hl, 'prix'=>Ar hors consigne, 'csg'=>Ar consigne, 'total'=>Ar]
 */
function calcul_ligne(array $p, int $casiers, int $bouteilles): array {
  $kit  = max(1, (int)$p['kit']);
  $vol  = $casiers * $p['volume_hl'] + $bouteilles * ($p['volume_hl'] / $kit);
  $prix = $casiers * $p['pag_kit_nu'] + $bouteilles * $p['pag_nu'];
  $csg  = $casiers * consigne_casier_plein($p) + $bouteilles * (float)$p['consigne_bouteille'];
  return ['vol' => $vol, 'prix' => $prix, 'csg' => $csg, 'total' => $prix + $csg];
}

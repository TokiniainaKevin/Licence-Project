<?php
// ============================================================
// includes/slider_data.php
// Contenu des slides "produits" partagé entre la page de connexion
// (index.php) et le fond plein écran de l'application (layout.php).
// ============================================================

function slider_produits(): array {
  return [
    ['img'=>'thb-pilsener.webp',          'accent'=>'#E8001C', 'tag'=>'Message du jour', 'quote'=>"Chaque hectolitre compte.<br>Donnez le meilleur aujourd'hui.", 'sub'=>'THB Pilsener · La référence malgache'],
    ['img'=>'gold-blonde.webp',           'accent'=>'#D9A400', 'tag'=>'Motivation',       'quote'=>'Le terrain est à vous.<br>Faites la différence.',            'sub'=>"Gold Blonde · La qualité qui se vend d'elle-même"],
    ['img'=>'gold-blanche-bouteille.webp','accent'=>'#3BB6E8', 'tag'=>'Fraîcheur',        'quote'=>'Un client satisfait aujourd\'hui,<br>c\'est dix demain.',      'sub'=>'Gold Blanche · La légèreté qui rafraîchit'],
    ['img'=>'gold-blanche-canette.webp',  'accent'=>'#3BB6E8', 'tag'=>'Objectif',         'quote'=>'Votre équipe compte sur vous.<br>En avant !',                 'sub'=>'Gold Blanche canette · Toujours prête à servir'],
    ['img'=>'gold-black-canette.webp',    'accent'=>'#C9A227', 'tag'=>'Performance',      'quote'=>'Chaque visite est une opportunité.<br>Saisissez-la.',         'sub'=>'Gold Black · Le caractère qui marque'],
    ['img'=>'gold-8.webp',                'accent'=>'#8B5E00', 'tag'=>'Exigence',         'quote'=>'La rigueur d\'aujourd\'hui<br>fait la réussite de demain.',    'sub'=>'Gold 8° · Une gamme qui s\'impose'],
    ['img'=>'caprice-orange.webp',        'accent'=>'#FF8C1A', 'tag'=>'Énergie',          'quote'=>'Un sourire, une vente.<br>Avancez avec entrain.',             'sub'=>'Caprice Orange · La gamme qui conquiert'],
    ['img'=>'caprice-bonbon-anglais.webp','accent'=>'#7FDBFF', 'tag'=>'Constance',        'quote'=>'La régularité fait<br>les grandes équipes.',                  'sub'=>'Caprice Bonbon Anglais · Une saveur qui fidélise'],
    ['img'=>'caprice-pet.webp',           'accent'=>'#4FC3F7', 'tag'=>'Disponibilité',    'quote'=>'Être présent partout,<br>c\'est gagner partout.',             'sub'=>'Caprice PET · Toujours à portée de main'],
    ['img'=>'caprice-grenadine.webp',     'accent'=>'#E8296B', 'tag'=>'Passion',          'quote'=>'Chaque commande compte.<br>Mettez-y du cœur.',                'sub'=>'Caprice Grenadine · La gamme qui séduit'],
    ['img'=>'caprice-pomme.webp',         'accent'=>'#C6D400', 'tag'=>'Ambition',         'quote'=>'Visez plus haut<br>à chaque visite client.',                  'sub'=>'Caprice Pomme · Une saveur qui rassemble'],
    ['img'=>'queens.webp',                'accent'=>'#2D8B00', 'tag'=>'Excellence',       'quote'=>'La qualité de service<br>fait toute la différence.',          'sub'=>"Queen's · L'élégance qui se démarque"],
    ['img'=>'racines.webp',               'accent'=>'#8B5E34', 'tag'=>'Authenticité',     'quote'=>'Nos racines font<br>notre force sur le terrain.',             'sub'=>'Racines · Le goût qui a du caractère'],
    ['img'=>'booster-cidre.webp',         'accent'=>'#B5C93C', 'tag'=>'Dynamisme',        'quote'=>'Gardez le rythme,<br>l\'équipe compte sur vous.',             'sub'=>'Booster Cidre · Une énergie qui pétille'],
    ['img'=>'booster-original.webp',      'accent'=>'#4C9A2A', 'tag'=>'Motivation',       'quote'=>"Chaque hectolitre vendu<br>rapproche l'équipe de l'objectif.", 'sub'=>"Booster · L'énergie pour aller plus loin"],
  ];
}

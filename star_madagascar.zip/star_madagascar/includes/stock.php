<?php
// ============================================================
// includes/stock.php
// Calcul centralisé du stock entrepôt à partir de mouvements_stock.
//
// Règles (une seule source de vérité, utilisée par toutes les pages) :
//  - ENTREE          : +  (réception entrepôt)
//  - SORTIE          : -  (commande livrée)
//  - RETOUR_DEFAUT   : -  (un produit neuf sort pour remplacer un produit
//                          défectueux ; le produit abîmé n'est pas revendable)
//  - RETOUR_CONSIGNE : 0  (bouteilles/casiers VIDES : ce n'est pas du stock
//                          vendable, seulement tracé pour l'historique)
//
// Casiers et bouteilles sont additionnés en bouteilles (casiers × kit +
// bouteilles) puis re-découpés, pour qu'une vente de bouteilles à l'unité
// entame bien les casiers au lieu de créer un stock de bouteilles négatif.
// ============================================================

function stock_signe_sql(string $alias = 'm'): string {
  return "CASE $alias.type WHEN 'ENTREE' THEN 1 WHEN 'SORTIE' THEN -1 WHEN 'RETOUR_DEFAUT' THEN -1 ELSE 0 END";
}

/** Sous-requête (alias se) : produit_id, total_btl */
function stock_join_sql(string $alias = 'se'): string {
  $s = stock_signe_sql('m');
  return "LEFT JOIN (
    SELECT m.produit_id,
           SUM(($s) * (m.quantite_casiers * CAST(pk.kit AS SIGNED) + m.quantite_bouteilles)) AS total_btl
    FROM mouvements_stock m
    JOIN produits pk ON pk.id = m.produit_id
    GROUP BY m.produit_id
  ) $alias ON $alias.produit_id = p.id";
}

/** Colonnes calculées à mettre dans le SELECT (nécessite p = produits et se = stock_join_sql) */
function stock_cols_sql(string $alias = 'se'): string {
  // CAST(... AS SIGNED) : les colonnes kit/quantités sont UNSIGNED, et MySQL
  // refuse un résultat négatif en arithmétique non signée (erreur 1690).
  $t = "CAST(COALESCE($alias.total_btl,0) AS SIGNED)";
  $k = "CAST(p.kit AS SIGNED)";
  return "$t AS total_bouteilles,
         TRUNCATE($t / $k, 0) AS quantite_casiers,
         $t - TRUNCATE($t / $k, 0) * $k AS quantite_bouteilles,
         ROUND($t * p.volume_hl / $k, 4) AS volume_total_hl";
}

/** Stock disponible d'un produit, en bouteilles */
function stock_disponible_btl(PDO $db, int $produit_id): int {
  $s = stock_signe_sql('m');
  $st = $db->prepare("SELECT COALESCE(SUM(($s) * (m.quantite_casiers * CAST(p.kit AS SIGNED) + m.quantite_bouteilles)),0)
                      FROM mouvements_stock m JOIN produits p ON p.id = m.produit_id
                      WHERE m.produit_id = ?");
  $st->execute([$produit_id]);
  return (int)$st->fetchColumn();
}

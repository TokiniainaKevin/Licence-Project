<?php
// ============================================================
// includes/auth_guard.php
// À inclure en haut de chaque page protégée
// Usage : require_once '../../includes/auth_guard.php';
//         auth_guard(['ADMIN', 'MANAGER']); // rôles autorisés
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

function auth_guard(array $roles = []): void {
  // Non connecté
  if (empty($_SESSION['user_id'])) {
    header('Location: ' . base_url() . '/index.php');
    exit;
  }

  // Session expirée (8h)
  if (time() - ($_SESSION['login_time'] ?? 0) > 28800) {
    session_destroy();
    header('Location: ' . base_url() . '/index.php?error=3');
    exit;
  }

  // Rôle non autorisé
  if (!empty($roles) && !in_array($_SESSION['user_role'], $roles, true)) {
    http_response_code(403);
    die(render_403());
  }

  // Protection CSRF : tout formulaire POST doit renvoyer le jeton secret de
  // la session (ajouté automatiquement à chaque <form method="post"> par le
  // script de includes/layout.php). Une page piégée sur un autre site ne
  // connaît pas ce jeton : sa requête est refusée.
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_valide()) {
    http_response_code(419);
    die(render_csrf_erreur());
  }

  // Renouveler le timer
  $_SESSION['login_time'] = time();
}

function csrf_token(): string {
  if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
  }
  return $_SESSION['csrf_token'];
}

function csrf_valide(): bool {
  $recu = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
  return is_string($recu) && $recu !== '' && hash_equals(csrf_token(), $recu);
}

function render_csrf_erreur(): string {
  return '<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>Formulaire expiré</title>
  <style>body{font-family:Inter,sans-serif;background:#111;color:#f0f0f0;display:flex;align-items:center;
  justify-content:center;height:100vh;margin:0}.box{text-align:center;max-width:420px}
  a{color:#E8001C;text-decoration:none;border:1px solid #E8001C;padding:.5rem 1.2rem;border-radius:8px}</style></head>
  <body><div class="box"><h2>Formulaire expiré</h2><p style="color:#aaa">Pour votre sécurité, ce formulaire
  n\'a pas été accepté (page restée ouverte trop longtemps ou envoyée depuis un autre site).
  Rechargez la page et recommencez.</p><a href="javascript:history.back()">← Retour</a></div></body></html>';
}

function base_url(): string {
  $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
  // Détecter le sous-dossier automatiquement
  $script = $_SERVER['SCRIPT_NAME'] ?? '';
  $base = rtrim(dirname(dirname(dirname($script))), '/');
  return $protocol . '://' . $host . $base;
}

function current_user(): array {
  return [
    'id'     => $_SESSION['user_id']     ?? null,
    'nom'    => $_SESSION['user_nom']    ?? '',
    'email'  => $_SESSION['user_email']  ?? '',
    'role'   => $_SESSION['user_role']   ?? '',
    'secteur' => $_SESSION['user_secteur'] ?? null,
  ];
}

function render_403(): string {
  return '<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
  <title>Accès refusé</title>
  <style>
    body{font-family:Inter,sans-serif;background:#111;color:#f0f0f0;
         display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
    .box{text-align:center}
    .code{font-size:5rem;font-weight:900;color:#E8001C;line-height:1}
    .msg{font-size:1rem;color:#666;margin:.5rem 0 2rem}
    a{color:#E8001C;text-decoration:none;font-size:.85rem;
      border:1px solid #E8001C;padding:.5rem 1.2rem;border-radius:8px}
  </style></head><body>
  <div class="box">
    <div class="code">403</div>
    <div class="msg">Vous n\'avez pas accès à cette page.</div>
    <a href="javascript:history.back()">← Retour</a>
  </div></body></html>';
}

<?php
// ============================================================
// includes/graphiques.php
// Graphiques des tableaux de bord (bibliothèque Chart.js 4, fichier local
// assets/js/vendor/chart.umd.min.js : fonctionne sans connexion internet).
// ============================================================

/** Carte contenant un graphique. $config = configuration Chart.js (tableau PHP) */
function graphique(string $id, string $titre, array $config, int $hauteur = 260, string $sous_titre = ''): string {
  $json = json_encode($config, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP);
  return '<div class="card chart-card"><div class="chart-title">' . htmlspecialchars($titre) . '</div>'
       . ($sous_titre ? '<div class="chart-sub">' . htmlspecialchars($sous_titre) . '</div>' : '')
       . '<div class="chart-box" style="height:' . $hauteur . 'px"><canvas id="' . $id . '"></canvas></div></div>'
       . '<script>window.addEventListener("load",function(){if(window.Chart){new Chart(document.getElementById("' . $id . '"),'
       . 'etoffer(' . $json . '));}});</script>';
}

/** Séries de jours [Y-m-d => 0] entre deux dates (dimanches exclus si $ouvres) */
function jours_periode(int $nb, bool $ouvres = true): array {
  $r = [];
  for ($i = $nb - 1; $i >= 0; $i--) {
    $ts = strtotime("-$i days");
    if ($ouvres && (int)date('N', $ts) === 7) continue;
    $r[date('Y-m-d', $ts)] = 0;
  }
  return $r;
}

/** Remplit une série [date => valeur] à partir de lignes SQL (colonnes d, v) */
function serie(array $jours, array $lignes): array {
  foreach ($lignes as $l) if (array_key_exists($l['d'], $jours)) $jours[$l['d']] = round((float)$l['v'], 2);
  return $jours;
}

function etiquettes_jours(array $jours): array {
  return array_map(fn($d) => date('d/m', strtotime($d)), array_keys($jours));
}

/** Script commun : thème sombre + couleurs STAR, à charger une fois par page */
function graphiques_script(string $root): string {
  return '<script src="' . $root . 'assets/js/vendor/chart.umd.min.js"></script><script>
if (window.Chart) {
  Chart.defaults.color = "#cfcfcf";
  Chart.defaults.borderColor = "rgba(255,255,255,.08)";
  Chart.defaults.font.family = "Inter, sans-serif";
  Chart.defaults.font.size = 12;
  Chart.defaults.plugins.legend.labels.boxWidth = 12;
  Chart.defaults.maintainAspectRatio = false;
}
const fmtFR = n => Number(n).toLocaleString("fr-FR", {maximumFractionDigits: 2});
function etoffer(cfg){
  cfg.options = cfg.options || {};
  cfg.options.plugins = cfg.options.plugins || {};
  cfg.options.plugins.tooltip = Object.assign({callbacks:{label:c=>" "+(c.dataset.label?c.dataset.label+" : ":"")+fmtFR(c.parsed.y ?? c.parsed.x ?? c.parsed)+(cfg.unite?" "+cfg.unite:"")}}, cfg.options.plugins.tooltip||{});
  // Graduations des axes de valeurs au format français (20 000 000 au lieu de 20,000,000)
  const horiz = cfg.options.indexAxis === "y";
  cfg.options.scales = cfg.options.scales || {};
  (horiz ? ["x"] : ["y", "y1"]).forEach(k => {
    if (k === "y1" && !cfg.options.scales.y1) return;
    const sc = cfg.options.scales[k] = cfg.options.scales[k] || {};
    sc.ticks = Object.assign({callback: v => fmtFR(v)}, sc.ticks || {});
  });
  if (horiz) { const sy = cfg.options.scales.y = cfg.options.scales.y || {}; sy.ticks = Object.assign({autoSkip:false}, sy.ticks || {}); }
  return cfg;
}
</script>';
}

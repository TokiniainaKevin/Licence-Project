<?php
// ============================================================
// includes/objectifs.php
// Objectif de l'AGENCE (en HL) : mensuel -> hebdomadaire -> journalier
//
// - Jours ouvrés : du lundi au samedi (dimanche exclu).
// - Objectif journalier = objectif mensuel / nombre de jours ouvrés du mois.
// - Objectif hebdomadaire = objectif journalier × jours ouvrés de la semaine
//   (la 1re et la dernière semaine d'un mois sont souvent incomplètes).
// - Réalisé agence = volume des commandes des clients qui achètent À L'AGENCE
//   (Distributeur, GMS, Station, Demi-gros = commandes CLIENT_DIRECT), une fois
//   payées. Les commandes des petits clients (bars, épiceries, restaurants) sont
//   livrées par un distributeur : elles comptent pour l'activité/prime du
//   commercial, pas pour l'objectif agence (le distributeur, lui, rachète à
//   l'agence et c'est cet achat qui compte).
// ============================================================

const STATUTS_PAYES = "'PAYEE','EN_PREPARATION','LIVREE','TERMINEE','DEFAUT_SIGNALE'";

/** Jours ouvrés (lundi-samedi) du mois, groupés par semaine : [n => ['YYYY-MM-DD', ...]] */
function semaines_ouvrees(int $annee, int $mois): array {
  $semaines = []; $n = 0; $derniere_iso = null;
  $nb = (int)date('t', mktime(0, 0, 0, $mois, 1, $annee));
  for ($j = 1; $j <= $nb; $j++) {
    $ts = mktime(0, 0, 0, $mois, $j, $annee);
    if ((int)date('N', $ts) === 7) continue;           // dimanche
    $iso = date('o-W', $ts);
    if ($iso !== $derniere_iso) { $n++; $derniere_iso = $iso; }
    $semaines[$n][] = date('Y-m-d', $ts);
  }
  return $semaines;
}

function nb_jours_ouvres(int $annee, int $mois): int {
  return array_sum(array_map('count', semaines_ouvrees($annee, $mois)));
}

/** Numéro de semaine (dans le mois) d'une date */
function semaine_du_mois(string $date): int {
  [$a, $m] = array_map('intval', explode('-', substr($date, 0, 7)));
  foreach (semaines_ouvrees($a, $m) as $n => $jours) if (in_array($date, $jours, true)) return $n;
  return 0; // dimanche
}

/**
 * Enregistre l'objectif mensuel de l'agence et génère automatiquement
 * les objectifs hebdomadaires et journaliers dans la table objectifs.
 */
function enregistrer_objectif_agence(PDO $db, int $annee, int $mois, float $hl, int $admin_id): void {
  $semaines = semaines_ouvrees($annee, $mois);
  $nb_jours = array_sum(array_map('count', $semaines));
  $jour_hl  = $nb_jours ? round($hl / $nb_jours, 2) : 0;

  $db->beginTransaction();
  try {
    $db->prepare("DELETE FROM objectifs WHERE commercial_id IS NULL AND annee=? AND mois=?")->execute([$annee, $mois]);
    $ins = $db->prepare("INSERT INTO objectifs (commercial_id, annee, mois, semaine, jour, objectif_hl, created_by)
                         VALUES (NULL, ?, ?, ?, ?, ?, ?)");
    $ins->execute([$annee, $mois, null, null, $hl, $admin_id]);                       // mensuel
    foreach ($semaines as $n => $jours) {
      $ins->execute([$annee, $mois, $n, null, round($jour_hl * count($jours), 2), $admin_id]); // hebdo
      foreach ($jours as $d) $ins->execute([$annee, $mois, $n, $d, $jour_hl, $admin_id]);     // journalier
    }
    $db->commit();
  } catch (Throwable $e) { $db->rollBack(); throw $e; }
}

/** Objectifs agence d'un mois : ['mois'=>hl, 'semaines'=>[n=>hl], 'jours'=>[date=>hl]] */
function objectifs_agence(PDO $db, int $annee, int $mois): array {
  $st = $db->prepare("SELECT semaine, jour, objectif_hl FROM objectifs WHERE commercial_id IS NULL AND annee=? AND mois=?");
  $st->execute([$annee, $mois]);
  $r = ['mois' => 0.0, 'semaines' => [], 'jours' => []];
  foreach ($st->fetchAll() as $o) {
    if ($o['jour'])          $r['jours'][$o['jour']] = (float)$o['objectif_hl'];
    elseif ($o['semaine'])   $r['semaines'][(int)$o['semaine']] = (float)$o['objectif_hl'];
    else                     $r['mois'] = (float)$o['objectif_hl'];
  }
  // Ancienne donnée (mensuel seul, sans découpage) : on calcule à la volée
  if ($r['mois'] > 0 && !$r['jours']) {
    $sem = semaines_ouvrees($annee, $mois); $nb = array_sum(array_map('count', $sem));
    $j = $nb ? round($r['mois'] / $nb, 2) : 0;
    foreach ($sem as $n => $jours) { $r['semaines'][$n] = round($j * count($jours), 2); foreach ($jours as $d) $r['jours'][$d] = $j; }
  }
  return $r;
}

/** Volume (HL) réalisé par l'agence entre deux dates incluses */
function realise_agence(PDO $db, string $debut, string $fin): float {
  $st = $db->prepare("SELECT COALESCE(SUM(total_hl),0) FROM commandes
                      WHERE type_commande='CLIENT_DIRECT' AND statut IN (" . STATUTS_PAYES . ")
                        AND DATE(date_commande) BETWEEN ? AND ?");
  $st->execute([$debut, $fin]);
  return (float)$st->fetchColumn();
}

/** Réalisé agence par jour sur un mois : [date => hl] */
function realise_agence_par_jour(PDO $db, int $annee, int $mois): array {
  $st = $db->prepare("SELECT DATE(date_commande) d, SUM(total_hl) hl FROM commandes
                      WHERE type_commande='CLIENT_DIRECT' AND statut IN (" . STATUTS_PAYES . ")
                        AND YEAR(date_commande)=? AND MONTH(date_commande)=? GROUP BY DATE(date_commande)");
  $st->execute([$annee, $mois]);
  return array_map('floatval', $st->fetchAll(PDO::FETCH_KEY_PAIR));
}

/** Synthèse jour / semaine / mois pour les tableaux de bord */
function synthese_objectif_agence(PDO $db, ?string $date = null): array {
  $date = $date ?: date('Y-m-d');
  [$a, $m] = array_map('intval', explode('-', substr($date, 0, 7)));
  $obj = objectifs_agence($db, $a, $m);
  $sem = semaines_ouvrees($a, $m);
  $n   = semaine_du_mois($date);
  $jours_sem = $sem[$n] ?? [];
  $r_jour = realise_agence($db, $date, $date);
  $r_sem  = $jours_sem ? realise_agence($db, $jours_sem[0], end($jours_sem)) : 0;
  $r_mois = realise_agence($db, sprintf('%04d-%02d-01', $a, $m), date('Y-m-t', strtotime($date)));
  $pct = fn($r, $o) => $o > 0 ? (int)round($r / $o * 100) : 0;
  return [
    'jour'    => ['objectif' => $obj['jours'][$date] ?? 0, 'realise' => $r_jour, 'pct' => $pct($r_jour, $obj['jours'][$date] ?? 0)],
    'semaine' => ['objectif' => $obj['semaines'][$n] ?? 0, 'realise' => $r_sem, 'pct' => $pct($r_sem, $obj['semaines'][$n] ?? 0), 'numero' => $n],
    'mois'    => ['objectif' => $obj['mois'], 'realise' => $r_mois, 'pct' => $pct($r_mois, $obj['mois'])],
  ];
}

/** Petit bloc HTML réutilisable : 3 barres jour / semaine / mois */
function bloc_objectif_agence(array $s): string {
  $h = '<div class="grid-3" style="margin-bottom:1.2rem">';
  $libelles = ['jour' => "Objectif agence · aujourd'hui", 'semaine' => 'Objectif agence · semaine ' . ($s['semaine']['numero'] ?: '—'), 'mois' => 'Objectif agence · mois'];
  foreach ($libelles as $k => $lib) {
    $o = $s[$k]; $w = min(100, $o['pct']);
    $col = $o['pct'] >= 100 ? '#00c864' : ($o['pct'] >= 70 ? '#ffa000' : 'var(--red)');
    $h .= '<div class="card card-top-line kpi-card"><div class="kpi-label">' . $lib . '</div>'
        . '<div class="kpi-value">' . number_format($o['realise'], 2, ',', ' ') . ' <span class="unit">/ '
        . ($o['objectif'] > 0 ? number_format($o['objectif'], 2, ',', ' ') . ' hl' : 'non défini') . '</span></div>'
        . '<div class="progress-bar"><div class="progress-fill" style="width:' . $w . '%;background:' . $col . '"></div></div>'
        . '<div class="kpi-trend neutral">' . $o['pct'] . ' % · clients achetant à l\'agence</div></div>';
  }
  return $h . '</div>';
}

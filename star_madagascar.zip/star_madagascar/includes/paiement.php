<?php
// ============================================================
// includes/paiement.php
// Confirmation d'un paiement (utilisé par le module Caissier)
// ============================================================

const MODES_PAIEMENT = [
  'MOBILE_MONEY' => 'Mobile Money (MVola / Orange / Airtel)',
  'VIREMENT'     => 'Virement / dépôt bancaire (bordereau)',
  'CASH'         => 'Espèces',
];

// Moyens de paiement proposés à la caisse (avec les vrais logos des opérateurs).
// Les trois opérateurs Mobile Money sont enregistrés en MOBILE_MONEY, le nom de
// l'opérateur est placé devant la référence (ex. « MVola 0341234567-889 »).
const MOYENS_PAIEMENT = [
  'MVOLA'    => ['mode' => 'MOBILE_MONEY', 'label' => 'MVola',          'logo' => 'mvola.jpg'],
  'ORANGE'   => ['mode' => 'MOBILE_MONEY', 'label' => 'Orange Money',   'logo' => 'orange_money.svg'],
  'AIRTEL'   => ['mode' => 'MOBILE_MONEY', 'label' => 'Airtel Money',   'logo' => 'airtel.svg'],
  'VIREMENT' => ['mode' => 'VIREMENT',     'label' => 'Virement / bordereau', 'logo' => null, 'icone' => 'landmark'],
  'CASH'     => ['mode' => 'CASH',         'label' => 'Espèces',        'logo' => null, 'icone' => 'banknote'],
];

/** Petit logo du moyen de paiement (d'après le mode et le préfixe de la référence) */
function logo_paiement(?string $mode, ?string $ref, string $root = '../../'): string {
  $cle = $mode === 'CASH' ? 'CASH' : ($mode === 'VIREMENT' ? 'VIREMENT' : null);
  if ($mode === 'MOBILE_MONEY') {
    $cle = 'MVOLA';
    if ($ref && stripos($ref, 'orange') === 0) $cle = 'ORANGE';
    elseif ($ref && stripos($ref, 'airtel') === 0) $cle = 'AIRTEL';
  }
  if (!$cle) return '—';
  $m = MOYENS_PAIEMENT[$cle];
  if ($m['logo']) return '<span class="pay-chip"><img src="' . $root . 'assets/images/logos/' . $m['logo'] . '" alt="">' . $m['label'] . '</span>';
  return '<span class="pay-chip">' . (function_exists('icone') ? icone($m['icone']) : '') . $m['label'] . '</span>';
}

/**
 * Confirme le paiement d'une commande EN_ATTENTE_PAIEMENT.
 * Retourne [true, message] ou [false, message d'erreur].
 */
function confirmer_paiement(PDO $db, int $cmd_id, string $mode, string $reference, float $montant_recu, int $caissier_id): array {
  if (!array_key_exists($mode, MODES_PAIEMENT)) return [false, 'Mode de paiement invalide.'];
  if ($mode !== 'CASH' && $reference === '') {
    return [false, 'La référence (N° de transaction ou N° de bordereau) est obligatoire pour ce mode de paiement.'];
  }
  try {
    $db->beginTransaction();
    $st = $db->prepare("SELECT id, code_commande, statut, montant_a_payer, commercial_id FROM commandes WHERE id=? FOR UPDATE");
    $st->execute([$cmd_id]);
    $cmd = $st->fetch();
    if (!$cmd) throw new Exception('Commande introuvable.');
    if ($cmd['statut'] !== 'EN_ATTENTE_PAIEMENT') throw new Exception("La commande {$cmd['code_commande']} n'est plus en attente de paiement.");
    if (round($montant_recu) !== round((float)$cmd['montant_a_payer'])) {
      throw new Exception('Montant reçu (' . number_format($montant_recu) . ' Ar) différent du montant à payer ('
        . number_format($cmd['montant_a_payer']) . ' Ar). Paiement non confirmé.');
    }
    if ($reference !== '') {
      $st = $db->prepare("SELECT code_commande FROM commandes WHERE reference_paiement=? AND id<>? LIMIT 1");
      $st->execute([$reference, $cmd_id]);
      if ($dup = $st->fetchColumn()) throw new Exception("Cette référence a déjà été utilisée pour la commande $dup.");
    }

    $db->prepare("UPDATE commandes SET statut='PAYEE', statut_paiement='CONFIRME', mode_paiement=?,
                  reference_paiement=?, caissier_id=?, date_paiement=NOW() WHERE id=?")
       ->execute([$mode, $reference ?: null, $caissier_id, $cmd_id]);

    // Notifier toute la logistique (et pas seulement le premier compte trouvé) + le commercial
    $notif = $db->prepare("INSERT INTO notifications (utilisateur_id,titre,message,type,reference_id) VALUES (?,?,?,'PAIEMENT_CONFIRME',?)");
    foreach ($db->query("SELECT id FROM utilisateurs WHERE role='LOGISTIQUE' AND actif=1")->fetchAll(PDO::FETCH_COLUMN) as $lid) {
      $notif->execute([$lid, 'Paiement confirmé — commande à préparer', "La commande {$cmd['code_commande']} est payée et peut être préparée.", $cmd_id]);
    }
    if ($cmd['commercial_id']) {
      $notif->execute([$cmd['commercial_id'], 'Paiement reçu', "Le paiement de la commande {$cmd['code_commande']} a été confirmé par la caisse.", $cmd_id]);
    }
    $db->commit();
    return [true, "Paiement de la commande {$cmd['code_commande']} confirmé."];
  } catch (Exception $e) {
    if ($db->inTransaction()) $db->rollBack();
    return [false, $e->getMessage()];
  }
}

/** Notifie les caissiers qu'une commande attend son paiement */
function notifier_caisse(PDO $db, int $cmd_id, string $code_cmd, float $montant): void {
  $notif = $db->prepare("INSERT INTO notifications (utilisateur_id,titre,message,type,reference_id) VALUES (?,?,?,'NOUVELLE_COMMANDE',?)");
  foreach ($db->query("SELECT id FROM utilisateurs WHERE role='CAISSIER' AND actif=1")->fetchAll(PDO::FETCH_COLUMN) as $cid) {
    $notif->execute([$cid, 'Paiement à encaisser', "Commande $code_cmd — " . number_format($montant) . " Ar à encaisser.", $cmd_id]);
  }
}

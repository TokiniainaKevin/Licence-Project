<?php
// ============================================================
// auth/login.php — Traitement de la connexion
// ============================================================

session_start();
require_once '../config/db.php';

// Déjà connecté → rediriger
if (!empty($_SESSION['user_id'])) {
  redirect_by_role($_SESSION['user_role']);
}

// POST uniquement
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ../index.php');
  exit;
}

$email    = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

// Validation basique
if (empty($email) || empty($password)) {
  header('Location: ../index.php?error=1');
  exit;
}

// Chercher l'utilisateur
$db = getDB();
$stmt = $db->prepare("
  SELECT id, nom, prenom, email, mot_de_passe, role, secteur_id, actif, photo
  FROM utilisateurs
  WHERE email = ?
  LIMIT 1
");
$stmt->execute([$email]);
$user = $stmt->fetch();

// Vérifier mot de passe : password_hash() (bcrypt, salé) pour les nouveaux mots
// de passe ; les anciens SHA-256 (comptes du fichier SQL) restent acceptés et
// sont convertis automatiquement en bcrypt à la première connexion réussie.
$ok = false;
if ($user) {
  if (password_verify($password, $user['mot_de_passe'])) {
    $ok = true;
  } elseif (hash_equals($user['mot_de_passe'], hash('sha256', $password))) {
    $ok = true;
    $db->prepare("UPDATE utilisateurs SET mot_de_passe=? WHERE id=?")
       ->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
  }
}
if (!$ok) {
  header('Location: ../index.php?error=1');
  exit;
}

// Compte désactivé
if (!$user['actif']) {
  header('Location: ../index.php?error=2');
  exit;
}

// ── Créer la session ──────────────────────────────────────
$_SESSION['user_id']     = $user['id'];
$_SESSION['user_nom']    = $user['prenom'] . ' ' . $user['nom'];
$_SESSION['user_email']  = $user['email'];
$_SESSION['user_role']   = $user['role'];
$_SESSION['user_secteur'] = $user['secteur_id'];
$_SESSION['login_time']  = time();
$_SESSION['user_photo']  = $user['photo'] ?? null;

// Régénérer l'ID de session (sécurité)
session_regenerate_id(true);

// ── Redirection selon le rôle ─────────────────────────────
redirect_by_role($user['role']);

function redirect_by_role(string $role): void {
  $routes = [
    'ADMIN'          => '../modules/admin/dashboard.php',
    'DIRECTEUR'      => '../modules/admin/dashboard.php',
    'MANAGER'        => '../modules/manager/dashboard.php',
    'MANAGER_INTERIM'=> '../modules/manager/dashboard.php',
    'COMMERCIAL'     => '../modules/commercial/dashboard.php',
    'LOGISTIQUE'     => '../modules/logistique/dashboard.php',
    'CAISSIER'       => '../modules/caissier/dashboard.php',
    'DISTRIBUTEUR'   => '../modules/distributeur/dashboard.php',
  ];
  $url = $routes[$role] ?? '../index.php?error=1';
  header("Location: $url");
  exit;
}

<?php
// ============================================================
// auth/logout.php — Déconnexion
// ============================================================

session_start();
$_SESSION = [];

if (ini_get('session.use_cookies')) {
  $p = session_get_cookie_params();
  setcookie(session_name(), '', time() - 3600,
    $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}

session_destroy();
header('Location: ../index.php?logout=1');
exit;

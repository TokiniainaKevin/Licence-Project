#!/usr/bin/env python3
# Génère la section "DONNÉES" de star_madagascar_base.sql :
# catalogue produits (tarif officiel STAR) + jeu de simulation complet.
import random, json, re
random.seed(2026)

def q(s):
    return "NULL" if s is None else "'" + str(s).replace("\\", "\\\\").replace("'", "\\'") + "'"

# ------------------------------------------------------------------
# 1. CATALOGUE — tarif officiel STAR (star.mg, « Événements privés »,
#    prix STAR NU TTC par casier/pack). Queen's et Racines : tarif agence
#    Fianarantsoa du 13/10/2025 (absents de la grille publique).
#    (code, description, famille, cl, emballage, kit, prix_casier_nu, source)
# ------------------------------------------------------------------
P = [
 ("THBP33V","THB Pilsener 33 cl VER","THB Pilsener",33,"VER",24,57600),
 ("THBP65V","THB Pilsener 65 cl VER","THB Pilsener",65,"VER",20,65400),
 ("THBP33C","THB Pilsener 33 cl CAN","THB Pilsener",33,"CAN",24,72000),
 ("THBP50C","THB Pilsener 50 cl CAN","THB Pilsener",50,"CAN",24,98496),
 ("THBF65V","THB Fresh 65 cl VER","THB Fresh",65,"VER",20,56040),
 ("THBF33V","THB Fresh 33 cl VER","THB Fresh",33,"VER",24,36000),
 ("QUE65V","Queen's 65 cl VER","Queen's",65,"VER",20,80000),
 ("GBL50V","Gold Blonde 50 cl VER","Gold",50,"VER",20,66000),
 ("GBL33V","Gold Blonde 33 cl VER","Gold",33,"VER",24,55296),
 ("GBL50C","Gold Blonde 50 cl CAN","Gold",50,"CAN",24,105696),
 ("GBA33V","Gold Blanche 33 cl VER","Gold",33,"VER",24,55296),
 ("GBA50C","Gold Blanche 50 cl CAN","Gold",50,"CAN",24,105696),
 ("G8_50V","Gold 8% 50 cl VER","Gold",50,"VER",20,66000),
 ("G8_50C","Gold 8% 50 cl CAN","Gold",50,"CAN",24,105696),
 ("BEA33V","Beaufort 33 cl VER","Beaufort",33,"VER",24,68400),
 ("BEA50V","Beaufort 50 cl VER","Beaufort",50,"VER",20,70080),
 ("BEA50C","Beaufort 50 cl CAN","Beaufort",50,"CAN",24,109872),
 ("BOOEX50V","Booster Exotique 50 cl VER","Booster",50,"VER",20,65040),
 ("BOOTO50V","Booster Tornado 50 cl VER","Booster",50,"VER",20,65040),
 ("BOOCL50V","Booster Cuba Libre 50 cl VER","Booster",50,"VER",20,65040),
 ("BOOAM50V","Booster Apple Mix 50 cl VER","Booster",50,"VER",20,65040),
 ("RAC33V","Racines 33 cl VER","Alcomix",33,"VER",24,72000),
]
for key, nom in [("BA","Bonbon Anglais"),("OR","Orange"),("GR","Grenadine"),("PO","Pomme"),("AN","Ananas")]:
    P += [(f"CAP{key}150P",f"Caprice {nom} 150 cl PET","Caprice",150,"PET",6,27324),
          (f"CAP{key}100V",f"Caprice {nom} 100 cl VER","Caprice",100,"VER",12,34200),
          (f"CAP{key}50P", f"Caprice {nom} 50 cl PET","Caprice",50,"PET",12,18000),
          (f"CAP{key}30V", f"Caprice {nom} 30 cl VER","Caprice",30,"VER",24,25200)]
for key, nom, fam in [("YOU","Youzou","Youzou"),("WCO","World Cola","World Cola")]:
    P += [(f"{key}150P",f"{nom} 150 cl PET",fam,150,"PET",6,27324),
          (f"{key}100V",f"{nom} 100 cl VER",fam,100,"VER",12,34200),
          (f"{key}50P", f"{nom} 50 cl PET",fam,50,"PET",12,18000),
          (f"{key}30V", f"{nom} 30 cl VER",fam,30,"VER",24,25200)]
P += [
 ("DJTR125P","D'jino Tropical 125 cl PET","D'jino",125,"PET",6,19260),
 ("DJTR35P","D'jino Tropical 35 cl PET","D'jino",35,"PET",12,15552),
 ("DJCO125P","D'jino Cola 125 cl PET","D'jino",125,"PET",6,19260),
 ("DJCO35P","D'jino Cola 35 cl PET","D'jino",35,"PET",12,15552),
 ("DJLI35P","D'jino Limonady 35 cl PET","D'jino",35,"PET",12,15552),
 ("TON100P","Tonic 100 cl PET","Tonic",100,"PET",12,34200),
 ("TON30P","Tonic 30 cl PET","Tonic",30,"PET",24,25200),
 ("XXL30V","XXL 30 cl VER","XXL",30,"VER",24,50400),
 ("XXL35P","XXL 35 cl PET","XXL",35,"PET",12,31176),
 ("CRI50V","Cristal 50 cl VER","Cristal",50,"VER",20,25929),
 ("CRI150P","Cristal 150 cl PET","Cristal",150,"PET",6,27324),
 ("CRL100P","Cristalline 100 cl PET","Cristalline",100,"PET",8,14016),
 ("CRL200P","Cristalline 200 cl PET","Cristalline",200,"PET",6,18540),
 ("EVI50P","Eau Vive 50 cl PET","Eau Vive",50,"PET",10,12888),
 ("EVI150P","Eau Vive 150 cl PET","Eau Vive",150,"PET",6,15912),
]

def csg_btl(cl, emb, fam=""):
    # Grille STAR (colonne « consigne unitaire ») : 30/33 cl 400, 50 cl 500
    # (Booster 400), 65 cl 500, 100 cl et plus 700 ; PET/canette 0
    if emb != "VER": return 0
    if cl >= 100: return 700
    if cl >= 65: return 500
    if cl >= 50: return 400 if fam == "Booster" else 500
    return 400

prod = []
for i, (code, desc, fam, cl, emb, kit, prix) in enumerate(P, 1):
    b = csg_btl(cl, emb, fam); c = 8000 if emb == "VER" else 0
    prod.append(dict(id=i, code=code, desc=desc, fam=fam, cl=cl, emb=emb, kit=kit,
                     vol=round(kit*cl/10000, 4), pag_nu=round(prix/kit), pag_kit=prix,
                     loge=prix+kit*b+c, cb=b, cc=c))
PC = {p["code"]: p for p in prod}

out = []
w = out.append
w("-- ============================================================")
w("-- CATALOGUE PRODUITS")
w("-- Source des prix : grille officielle STAR « Prix STAR NU TTC » par casier/pack")
w("-- (https://www.star.mg/evenements-prives/). Queen's 65 cl et Racines 33 cl :")
w("-- tarif agence Fianarantsoa du 13/10/2025 (absents de la grille publique).")
w("-- pag_nu = prix casier / kit ; volume_hl = kit x contenance / 10 000.")
w("-- Consigne (grille STAR, verre uniquement) : 400 Ar (30/33 cl, Booster 50 cl), 500 Ar (50 cl bières, 65 cl), 700 Ar (100 cl+),")
w("-- casier 8 000 Ar ; PAG kit logé = kit nu + kit x consigne bouteille + casier.")
w("-- ============================================================")
w("INSERT INTO `produits` (`id`,`code`,`description`,`famille`,`contenance_cl`,`type_emballage`,`kit`,`volume_hl`,`pag_nu`,`pag_kit_nu`,`pag_kit_loge`,`consigne_bouteille`,`consigne_casier`) VALUES")
w(",\n".join(f"({p['id']},{q(p['code'])},{q(p['desc'])},{q(p['fam'])},{p['cl']},'{p['emb']}',{p['kit']},{p['vol']},{p['pag_nu']},{p['pag_kit']},{p['loge']},{p['cb']},{p['cc']})" for p in prod) + ";")

# ------------------------------------------------------------------
# 2. SECTEURS & UTILISATEURS
# ------------------------------------------------------------------
secteurs = [(1,"Centre-ville","Fianarantsoa Centre","Tsaramandroso, Antarandolo, Ankidona, Anjoma"),
            (2,"Périphérie Nord","Fianarantsoa Nord","Andrainjato, Ivory, Isaha, Talatamaty"),
            (3,"Périphérie Sud","Fianarantsoa Sud / Ambalavao","Isorana, Ambalavao, Sahambavy")]
w("\n-- SECTEURS (un secteur = une équipe commerciale)")
w("INSERT INTO `secteurs` (`id`,`nom`,`zone`,`description`) VALUES\n" + ",\n".join(f"({i},{q(n)},{q(z)},{q(d)})" for i,n,z,d in secteurs) + ";")

PW_ADMIN = "SHA2('Admin@Star2025',256)"; PW = "SHA2('Test@2025',256)"
users = [  # id, nom, prenom, email, tel, role, secteur
 (1,"ADMIN","STAR","admin@star-madagascar.mg","0340000000","ADMIN",None),
 (2,"Rakoto","Jean","directeur@star-madagascar.mg","0341000001","DIRECTEUR",None),
 (3,"Rasoa","Marie","manager@star-madagascar.mg","0341000002","MANAGER",1),
 (4,"Andry","Paul","commercial1@star-madagascar.mg","0341000003","COMMERCIAL",1),
 (5,"Voahangy","Lucie","commercial2@star-madagascar.mg","0341000004","COMMERCIAL",2),
 (6,"Rabe","Hery","logistique@star-madagascar.mg","0341000005","LOGISTIQUE",None),
 (7,"Randria","Nirina","caissier@star-madagascar.mg","0341000008","CAISSIER",None),
 (8,"Tsaramandroso","Dépôt","distributeur1@star-madagascar.mg","0341000006","DISTRIBUTEUR",None),
 (9,"Isaha","Dépôt","distributeur2@star-madagascar.mg","0341000007","DISTRIBUTEUR",None),
 (10,"Ambalavao","Dépôt","distributeur3@star-madagascar.mg","0341000009","DISTRIBUTEUR",None),
 (11,"Razafy","Tiana","manager2@star-madagascar.mg","0341000010","MANAGER",2),
 (12,"Rakotomalala","Fidy","manager3@star-madagascar.mg","0341000011","MANAGER_INTERIM",3),
 (13,"Rasolofo","Mamy","commercial3@star-madagascar.mg","0341000012","COMMERCIAL",1),
 (14,"Randrianarisoa","Hanta","commercial4@star-madagascar.mg","0341000013","COMMERCIAL",2),
 (15,"Rajaonarison","Toky","commercial5@star-madagascar.mg","0341000014","COMMERCIAL",3),
 (16,"Ravelo","Soa","commercial6@star-madagascar.mg","0341000015","COMMERCIAL",3),
 (17,"Rafanomezantsoa","Njaka","logistique2@star-madagascar.mg","0341000016","LOGISTIQUE",None),
 (18,"Raharisoa","Onja","caissier2@star-madagascar.mg","0341000017","CAISSIER",None),
]
w("\n-- UTILISATEURS — mot de passe de test : Test@2025 (admin : Admin@Star2025)")
w("INSERT INTO `utilisateurs` (`id`,`nom`,`prenom`,`email`,`mot_de_passe`,`telephone`,`role`,`secteur_id`,`statut_presence`) VALUES\n" +
  ",\n".join(f"({u[0]},{q(u[1])},{q(u[2])},{q(u[3])},{PW_ADMIN if u[0]==1 else PW},{q(u[4])},'{u[5]}',{u[6] or 'NULL'},{q('CONGE' if u[0]==16 else 'EN_TRAVAIL')})" for u in users) + ";")
COMS = {1:[4,13], 2:[5,14], 3:[15,16]}
MANAGERS = {1:3, 2:11, 3:12}

# ------------------------------------------------------------------
# 3. CLIENTS (tous les types, 3 secteurs)
# ------------------------------------------------------------------
clients = []  # dict(id, code, nom, type, secteur, quartier, dist, user)
def cl(code, nom, typ, sec, quartier, adresse, dist=None, user=None, statut="ACTIF", demandeur=None, manager=None, motif=None):
    cid = len(clients) + 1
    clients.append(dict(id=cid, code=code, nom=nom, type=typ, sec=sec, quartier=quartier, adresse=adresse,
                        dist=dist, user=user, statut=statut, demandeur=demandeur, manager=manager, motif=motif))
    return cid
D1 = cl("DIST-001","Dépôt Tsaramandroso","DISTRIBUTEUR",1,"Tsaramandroso","Route Tsaramandroso",user=8)
D2 = cl("DIST-002","Dépôt Isaha","DISTRIBUTEUR",2,"Isaha","RN7 Isaha",user=9)
D3 = cl("DIST-003","Dépôt Ambalavao","DISTRIBUTEUR",3,"Ambalavao","Route d'Ambalavao",user=10)
DIST_OF = {1:D1, 2:D2, 3:D3}
data = {
 1: [("GMS","Leader Price Fianarantsoa","Antarandolo","Route Circulaire"),
     ("STATION","Station Jovenna Anjoma","Anjoma","Avenue de l'Indépendance"),
     ("DEMI_GROS","Grossiste Rakoto & Fils","Tsaramandroso","Rue du Marché"),
     ("EPICERIE","Épicerie Vola","Tsaramandroso","Rue Ratsimamanga"),
     ("EPICERIE","Épicerie Chez Bako","Ankidona","Lot IV B 12 Ankidona"),
     ("EPICERIE","Épicerie Tsiky","Anjoma","Rue Joffre"),
     ("BAR","Bar Le Zébu","Tsaramandroso","Avenue de France"),
     ("BAR","Bar Chez Nirina","Antarandolo","Rue Rabearivelo"),
     ("BAR","Snack Bar Tokana","Ankidona","Place du Zoma"),
     ("RESTAURANT","Restaurant Le Rossignol","Antarandolo","Rue Rondriantsilanizaka"),
     ("RESTAURANT","Hôtel-Restaurant Zomatel","Tsaramandroso","Avenue Lenine")],
 2: [("GMS","Supermarché Score Andrainjato","Andrainjato","RN7 Andrainjato"),
     ("STATION","Station Total Ivory","Ivory","RN7 Ivory"),
     ("DEMI_GROS","Grossiste Bekiraro","Talatamaty","Rue du Grand Marché"),
     ("EPICERIE","Épicerie Fleur","Isaha","Lot II A Isaha"),
     ("EPICERIE","Épicerie Mahafaly","Andrainjato","Route d'Andrainjato"),
     ("EPICERIE","Épicerie Soanirina","Talatamaty","Lot 45 Talatamaty"),
     ("BAR","Bar Tropical","Ivory","Rue de la Gare"),
     ("BAR","Bar Ny Havana","Isaha","RN7 Isaha"),
     ("BAR","Bar Le Baobab","Andrainjato","Carrefour Andrainjato"),
     ("RESTAURANT","Restaurant Chez Mimi","Ivory","Route d'Ivory"),
     ("RESTAURANT","Gargote Mahasoa","Talatamaty","Marché Talatamaty")],
 3: [("GMS","Supérette Ambalavao","Ambalavao","Centre-ville Ambalavao"),
     ("STATION","Station Galana Isorana","Isorana","RN7 Isorana"),
     ("DEMI_GROS","Grossiste Sahambavy","Sahambavy","Route du Thé"),
     ("EPICERIE","Épicerie Iarivo","Ambalavao","Rue principale"),
     ("EPICERIE","Épicerie Lalao","Isorana","Lot 12 Isorana"),
     ("BAR","Bar Le Tsiazotafo","Ambalavao","Place du marché aux zébus"),
     ("BAR","Bar Ny Ainga","Sahambavy","Gare de Sahambavy"),
     ("BAR","Bar Zina","Isorana","RN7 Isorana"),
     ("RESTAURANT","Restaurant Aux Bougainvillées","Ambalavao","RN7 Ambalavao"),
     ("RESTAURANT","Hôtel Lac Sahambavy","Sahambavy","Bord du lac")],
}
PREF = {"GMS":"GMS","STATION":"STA","DEMI_GROS":"DMG","EPICERIE":"EPI","BAR":"BAR","RESTAURANT":"RES"}
cnt = {}
for sec, lst in data.items():
    for typ, nom, qu, adr in lst:
        cnt[typ] = cnt.get(typ, 0) + 1
        petit = typ in ("EPICERIE","BAR","RESTAURANT")
        cl(f"{PREF[typ]}-{cnt[typ]:03d}", nom, typ, sec, qu, adr, dist=DIST_OF[sec] if petit else None)
# demandes de code client en cours (workflow)
cl(None,"Bar Fitiavana","BAR",1,"Anjoma","Rue Pasteur",dist=D1,statut="EN_ATTENTE",demandeur=4,manager=3)
cl(None,"Épicerie Rova","EPICERIE",2,"Isaha","Lot 8 Isaha",dist=D2,statut="VALIDE_MANAGER",demandeur=5,manager=11)
cl(None,"Station Jovenna Sahambavy","STATION",3,"Sahambavy","Route du Thé",statut="EN_ATTENTE",demandeur=15,manager=12)
cl(None,"Bar Sans Nom","BAR",2,"Ivory","—",dist=D2,statut="REJETE",demandeur=14,manager=11,motif="Adresse incomplète, client non trouvé sur place.")

def tp(c):
    if c["statut"] != "ACTIF": return None
    return "DISTRIBUTEUR" if c["type"] in ("EPICERIE","BAR","RESTAURANT") else "AGENCE"
tel0 = 340100000
w("\n-- CLIENTS : 2 à 3 de chaque type par secteur + 4 demandes de code en cours")
w("INSERT INTO `clients` (`id`,`code_client`,`nom`,`type`,`type_paiement`,`adresse`,`quartier`,`secteur_id`,`telephone`,`email`,`nif`,`stat`,`distributeur_id`,`utilisateur_id`,`demandeur_id`,`manager_id`,`motif_rejet`,`statut`) VALUES")
rows = []
for c in clients:
    email = next((u[3] for u in users if u[0] == c["user"]), None)
    direct = c["type"] in ("DISTRIBUTEUR","GMS","STATION","DEMI_GROS")
    nif = f"{3000000000 + c['id']*7919}" if direct else None
    stat = f"46101 21 2019 0 {c['id']:05d}" if direct else None
    rows.append(f"({c['id']},{q(c['code'])},{q(c['nom'])},'{c['type']}',{q(tp(c))},{q(c['adresse'])},{q(c['quartier'])},{c['sec']},'0{tel0+c['id']*37}',{q(email)},{q(nif)},{q(stat)},{c['dist'] or 'NULL'},{c['user'] or 'NULL'},{c['demandeur'] or 'NULL'},{c['manager'] or 'NULL'},{q(c['motif'])},'{c['statut']}')")
w(",\n".join(rows) + ";")
ACTIFS = [c for c in clients if c["statut"] == "ACTIF"]

# ------------------------------------------------------------------
# 4. COMMANDES / VISITES / MOUVEMENTS (45 derniers jours, dates relatives)
# ------------------------------------------------------------------
def dt(d, h, m=0):
    """Date relative à l'import, décalée au samedi si elle tombe un dimanche."""
    base = f"DATE_SUB(CURDATE(), INTERVAL {d} DAY)"
    return f"(IF(DAYOFWEEK({base})=1, DATE_SUB({base}, INTERVAL 1 DAY), {base}) + INTERVAL {h*60+m} MINUTE)"
def dd(d):
    base = f"DATE_SUB(CURDATE(), INTERVAL {d} DAY)"
    return f"IF(DAYOFWEEK({base})=1, DATE_SUB({base}, INTERVAL 1 DAY), {base})"

GAMME = {
 "BAR":        (["THBP65V","THBP65V","GBL50V","QUE65V","THBF65V","BEA50V","G8_50V","BOOTO50V","XXL30V"], (2, 8)),
 "RESTAURANT": (["THBP65V","GBL50V","GBA33V","CAPBA100V","CAPOR100V","EVI150P","CRL100P","WCO100V","TON30P"], (1, 6)),
 "EPICERIE":   (["THBP65V","THBP33V","CAPBA150P","CAPOR150P","YOU150P","DJTR35P","EVI150P","CRL200P","XXL35P"], (1, 5)),
 "GMS":        (["THBP50C","GBL50C","GBA50C","BEA50C","CAPBA150P","CRL200P","EVI150P","DJCO125P","THBP33C"], (6, 25)),
 "STATION":    (["THBP50C","GBL50C","EVI50P","CRL100P","DJTR35P","XXL35P","THBP33C"], (3, 12)),
 "DEMI_GROS":  (["THBP65V","GBL50V","QUE65V","CAPBA100V","EVI150P","THBF65V","CAPBA150P"], (15, 45)),
 "DISTRIBUTEUR":(["THBP65V","GBL50V","QUE65V","THBF65V","CAPBA100V","CAPOR100V","EVI150P","XXL30V"], (25, 70)),
}
commandes, lignes, mouvements, visites = [], [], [], []
sorties = {}   # produit -> bouteilles sorties
def add_cmd(d, h, client, commercial, prefix):
    typ = client["type"]
    direct = typ in ("DISTRIBUTEUR","GMS","STATION","DEMI_GROS")
    gamme, (qmin, qmax) = GAMME[typ]
    items = random.sample(gamme, k=random.randint(1, min(4, len(gamme))))
    cid = len(commandes) + 1
    tot_hl = tot_prod = tot_csg = 0
    lid0 = len(lignes)
    for code in items:
        p = PC[code]
        cas = random.randint(qmin, qmax) if len(items) == 1 else max(1, random.randint(qmin, qmax) // 2)
        btl = random.choice([0, 0, 0, random.randint(1, p["kit"]-1)]) if typ in ("BAR","EPICERIE","RESTAURANT") else 0
        vol = round(cas*p["vol"] + btl*p["vol"]/p["kit"], 4)
        prix = cas*p["pag_kit"] + btl*p["pag_nu"]
        csg = cas*(p["kit"]*p["cb"] + p["cc"]) + btl*p["cb"]
        lignes.append(dict(id=len(lignes)+1, cmd=cid, prod=p["id"], cas=cas, btl=btl, pag=p["pag_kit"], csg=csg, vol=vol, st=prix+csg, code=code))
        tot_hl += vol; tot_prod += prix; tot_csg += csg
    # statut selon l'ancienneté
    if direct:
        if d >= 2: statut = "LIVREE"
        elif d == 1: statut = random.choice(["PAYEE","EN_PREPARATION","LIVREE"])
        else: statut = random.choice(["EN_ATTENTE_PAIEMENT","EN_ATTENTE_PAIEMENT","PAYEE"])
    else:
        statut = "LIVREE" if d >= 2 else "VALIDEE"
    paye = statut in ("PAYEE","EN_PREPARATION","LIVREE") and direct
    mode = random.choice(["MOBILE_MONEY","MOBILE_MONEY","VIREMENT","CASH"]) if paye else None
    ref = None
    if paye and mode == "MOBILE_MONEY":
        op = random.choice(["MVola", "MVola", "Orange Money", "Airtel Money"])
        ref = f"{op} {random.randint(10**9, 10**10-1)}"
    elif paye and mode == "VIREMENT": ref = f"BOA-BRD-{random.randint(100000, 999999)}"
    code = f"{prefix}-SIM-{cid:04d}"
    commandes.append(dict(id=cid, code=code, com=commercial, client=client["id"],
        dist=client["dist"] if not direct else None, type="CLIENT_DIRECT" if direct else "PETIT_CLIENT",
        d=d, h=h, hl=round(tot_hl,4), prod=tot_prod, csg=tot_csg, statut=statut,
        sp="CONFIRME" if paye else "EN_ATTENTE", mode=mode, ref=ref, caissier=random.choice([7,18]) if paye else None))
    if direct and statut == "LIVREE":
        for l in lignes[lid0:]:
            mouvements.append((l["prod"], "SORTIE", l["cas"], l["btl"], cid, None, random.choice([6,17]), None, dt(d, h+3)))
            sorties[l["prod"]] = sorties.get(l["prod"], 0) + l["cas"]*PC[l["code"]]["kit"] + l["btl"]
    return cid

vis_id = 0
for d in range(44, -1, -1):
    for sec, coms in COMS.items():
        sec_clients = [c for c in ACTIFS if c["sec"] == sec and c["type"] != "DISTRIBUTEUR"]
        for com in coms:
            if com == 16 and d < 6: continue           # commerciale en congé depuis 6 jours
            if d == 0:
                todo = random.sample(sec_clients, 5)
                for k, c in enumerate(todo):
                    vis_id += 1
                    if k < 2:   # déjà visités ce matin
                        h = 8 + k
                        stock = {str(PC[x]["id"]): {"casiers": random.randint(0, 6), "bouteilles": random.randint(0, 10)} for x in random.sample(GAMME[c["type"]][0], 3)}
                        visites.append((vis_id, com, c["id"], dt(0, h, vis_id % 60), 'VISITE', "Relevé fait, client satisfait.", json.dumps(stock)))
                        add_cmd(0, h, c, com, "CMD")
                    else:       # encore à faire (planning du jour)
                        visites.append((vis_id, com, c["id"], dd(0), 'PLANIFIE', None, None))
                continue
            nb = random.randint(3, 6)
            for k, c in enumerate(random.sample(sec_clients, nb)):
                vis_id += 1
                h = 8 + k
                stock = {str(PC[x]["id"]): {"casiers": random.randint(0, 8), "bouteilles": random.randint(0, 12)} for x in random.sample(GAMME[c["type"]][0], 3)}
                rem = random.choice([None, None, "Client satisfait.", "Rupture sur THB 65 cl, commande passée.", "Demande de PLV / parasols.", "Client absent, repasser demain.", "Stock encore correct."])
                visites.append((vis_id, com, c["id"], dt(d, h, vis_id % 60), 'VISITE', rem, json.dumps(stock)))
                if random.random() < 0.7:
                    add_cmd(d, h, c, com, "CMD")
    # commandes passées directement par les distributeurs (2 à 3 par semaine chacun)
    for sec, did in DIST_OF.items():
        if random.random() < 0.4:
            add_cmd(d, 7, next(c for c in clients if c["id"] == did), None, "DIST")
# visites planifiées pour les jours à venir
for dplus in range(1, 6):
    for sec, coms in COMS.items():
        sec_clients = [c for c in ACTIFS if c["sec"] == sec and c["type"] != "DISTRIBUTEUR"]
        for com in coms:
            if com == 16: continue
            for c in random.sample(sec_clients, 4):
                vis_id += 1
                base = f"DATE_ADD(CURDATE(), INTERVAL {dplus} DAY)"
                visites.append((vis_id, com, c["id"], f"IF(DAYOFWEEK({base})=1, DATE_ADD({base}, INTERVAL 1 DAY), {base})", 'PLANIFIE', None, None))

# ------------------------------------------------------------------
# 5. STOCK : réceptions suffisantes pour couvrir les sorties
# ------------------------------------------------------------------
entrees = []
alerte = {"G8_50C", "TON100P", "BOOCL50V"}   # produits volontairement en rupture (alertes)
for p in prod:
    if p["code"] in alerte: continue
    besoin = sorties.get(p["id"], 0)
    cas_total = besoin // p["kit"] + random.randint(40, 160)
    first = int(cas_total * 0.6); second = cas_total - first
    entrees.append((p["id"], "ENTREE", first, 0, None, None, 6, "Stock initial (inventaire)", dt(45, 7)))
    entrees.append((p["id"], "ENTREE", second, 0, None, None, 17, "Réception camion usine Antananarivo", dt(random.randint(10, 25), 7)))
mouvements = entrees + mouvements

# retours de consigne (vides) + défauts
retours = []
elig = [c for c in ACTIFS if c["type"] in ("DISTRIBUTEUR","GMS","STATION","DEMI_GROS")]
solde = {}
for i in range(14):
    c = random.choice(elig); p = PC[random.choice(["THBP65V","GBL50V","QUE65V","CAPBA100V","THBF65V","XXL30V"])]
    nc = random.randint(2, 15); nb = nc * p["kit"]
    cb, cc = nb*p["cb"], nc*p["cc"]
    d = random.randint(1, 40)
    retours.append((i+1, c["id"], random.choice([6,17]), p["id"], nb, nc, cb, cc, cb+cc, dt(d, 15)))
    solde[c["id"]] = solde.get(c["id"], 0) + cb + cc
    mouvements.append((p["id"], "RETOUR_CONSIGNE", nc, nb, None, i+1, 6, "Retour de vides", dt(d, 15)))
# une partie du crédit a été utilisée
solde = {k: max(0, v - random.choice([0, v//3, v//2])) for k, v in solde.items()}

livrees = [c for c in commandes if c["statut"] == "LIVREE" and c["com"]]
defauts = []
for i, (st, qte) in enumerate([("SIGNALE",3),("SIGNALE",1),("VALIDE_MANAGER",2),("REMPLACEMENT_CONFIRME",4),("REMPLACEMENT_CONFIRME",2),("REJETE",6)]):
    c = random.choice([x for x in livrees if x["d"] <= 12])
    l = next(l for l in lignes if l["cmd"] == c["id"])
    sec = next(u[6] for u in users if u[0] == c["com"])
    desc = random.choice(["Bouteilles cassées à la livraison","Capsules défectueuses / produit éventé","Étiquettes abîmées, produit trouble","Fuite sur plusieurs bouteilles"])
    defauts.append((i+1, c["id"], l["prod"], c["com"], MANAGERS[sec], 6 if st == "REMPLACEMENT_CONFIRME" else None, desc, qte, st,
                    "Casse imputable au client (hors garantie)." if st == "REJETE" else None, dt(max(0, c["d"]-1), 11)))
    if st == "REMPLACEMENT_CONFIRME":
        mouvements.append((l["prod"], "RETOUR_DEFAUT", 0, qte, c["id"], None, 6, "Remplacement produit défectueux (sortie de produit neuf)", dt(max(0, c["d"]-1), 16)))
for dfa in defauts:
    if dfa[8] in ("SIGNALE","VALIDE_MANAGER","REMPLACEMENT_CONFIRME"):
        for c in commandes:
            if c["id"] == dfa[1]: c["statut"] = "DEFAUT_SIGNALE"

# ------------------------------------------------------------------
# 6. ÉCRITURE SQL
# ------------------------------------------------------------------
def chunks(lst, n=200):
    for i in range(0, len(lst), n): yield lst[i:i+n]

w("\n-- COMMANDES SIMULÉES sur les 45 derniers jours (dates relatives à la date d'import,")
w("-- dimanches ramenés au samedi). CMD-SIM = prise par un commercial, DIST-SIM = passée")
w("-- par un distributeur. Statuts selon l'ancienneté : livrées, payées, en préparation,")
w("-- en attente de caisse (aujourd'hui) ; petits clients validés -> livrés par le distributeur.")
for ch in chunks(commandes):
    w("INSERT INTO `commandes` (`id`,`code_commande`,`commercial_id`,`client_id`,`distributeur_id`,`type_commande`,`date_commande`,`date_livraison`,`total_hl`,`montant_ht`,`montant_consigne`,`montant_total`,`credit_consigne_utilise`,`montant_a_payer`,`statut`,`statut_paiement`,`mode_paiement`,`reference_paiement`,`caissier_id`,`date_paiement`) VALUES")
    w(",\n".join(
      f"({c['id']},{q(c['code'])},{c['com'] or 'NULL'},{c['client']},{c['dist'] or 'NULL'},'{c['type']}',{dt(c['d'],c['h'],c['id']%60)},"
      f"DATE({dt(c['d'],c['h'])} + INTERVAL 1 DAY),{c['hl']},{c['prod']},{c['csg']},{c['prod']+c['csg']},0,{c['prod']+c['csg']},"
      f"'{c['statut']}','{c['sp']}',{q(c['mode'])},{q(c['ref'])},{c['caissier'] or 'NULL'},"
      + (f"{dt(c['d'],c['h']+1,c['id']%60)}" if c['sp']=='CONFIRME' else "NULL") + ")" for c in ch) + ";")
for ch in chunks(lignes, 300):
    w("INSERT INTO `lignes_commande` (`id`,`commande_id`,`produit_id`,`quantite_casiers`,`quantite_bouteilles`,`prix_pag_kit`,`prix_consigne`,`volume_hl`,`sous_total`) VALUES")
    w(",\n".join(f"({l['id']},{l['cmd']},{l['prod']},{l['cas']},{l['btl']},{l['pag']},{l['csg']},{l['vol']},{l['st']})" for l in ch) + ";")

w("\n-- VISITES : réalisées (avec relevé de stock JSON), planning du jour et des 5 prochains jours")
for ch in chunks(visites, 300):
    w("INSERT INTO `visites` (`id`,`commercial_id`,`client_id`,`date_visite`,`statut`,`remarque`,`stock_releve`) VALUES")
    w(",\n".join(f"({v[0]},{v[1]},{v[2]},{v[3]},'{v[4]}',{q(v[5])},{q(v[6])})" for v in ch) + ";")
w("UPDATE `visites` SET `semaine` = FLOOR((DAYOFMONTH(`date_visite`)-1)/7)+1;")

w("\n-- RETOURS DE CONSIGNE (vides rendus par les clients directs) + solde de crédit")
w("INSERT INTO `retours_consigne` (`id`,`client_id`,`logistique_id`,`produit_id`,`nb_bouteilles`,`nb_casiers`,`credit_bouteilles`,`credit_casiers`,`credit_total`,`statut`,`created_at`,`validated_at`) VALUES")
w(",\n".join(f"({r[0]},{r[1]},{r[2]},{r[3]},{r[4]},{r[5]},{r[6]},{r[7]},{r[8]},'VALIDE',{r[9]},{r[9]})" for r in retours) + ";")
w("INSERT INTO `solde_consigne` (`client_id`,`solde_ariary`) VALUES\n" + ",\n".join(f"({k},{v})" for k, v in solde.items()) + ";")

w("\n-- MOUVEMENTS DE STOCK : réceptions, sorties des commandes livrées, vides, remplacements")
w("-- (3 produits volontairement sans stock pour tester les alertes)")
for ch in chunks(mouvements, 300):
    w("INSERT INTO `mouvements_stock` (`produit_id`,`type`,`quantite_casiers`,`quantite_bouteilles`,`commande_id`,`retour_consigne_id`,`logistique_id`,`remarque`,`created_at`) VALUES")
    w(",\n".join(f"({m[0]},'{m[1]}',{m[2]},{m[3]},{m[4] or 'NULL'},{m[5] or 'NULL'},{m[6]},{q(m[7])},{m[8]})" for m in ch) + ";")

w("\n-- DÉFAUTS PRODUITS à chaque étape du circuit (signalé, validé, remplacé, rejeté)")
w("INSERT INTO `defauts_produits` (`id`,`commande_id`,`produit_id`,`commercial_id`,`manager_id`,`logistique_id`,`description`,`quantite`,`statut`,`motif_rejet`,`created_at`) VALUES")
w(",\n".join(f"({x[0]},{x[1]},{x[2]},{x[3]},{x[4]},{x[5] or 'NULL'},{q(x[6])},{x[7]},'{x[8]}',{q(x[9])},{x[10]})" for x in defauts) + ";")
w("UPDATE `commandes` SET `statut`='DEFAUT_SIGNALE' WHERE `id` IN (" + ",".join(str(x[1]) for x in defauts if x[8] != 'REJETE') + ");")

# objectifs : agence (mensuel -> découpé automatiquement par l'application) + visites
direct_30 = sum(c["hl"] for c in commandes if c["type"] == "CLIENT_DIRECT" and c["d"] <= 26)
obj = round(direct_30 * 1.12 / 10) * 10
w("\n-- OBJECTIFS : agence en HL (mois en cours et précédent ; l'application répartit")
w("-- automatiquement par semaine et par jour ouvré) + objectif de visites par commercial")
w("INSERT INTO `objectifs` (`commercial_id`,`annee`,`mois`,`objectif_hl`,`objectif_clients`,`created_by`) VALUES")
rows = [f"(NULL, YEAR(CURDATE()), MONTH(CURDATE()), {obj}, NULL, 1)",
        f"(NULL, YEAR(CURDATE() - INTERVAL 1 MONTH), MONTH(CURDATE() - INTERVAL 1 MONTH), {obj - 20}, NULL, 1)"]
for sec, coms in COMS.items():
    for com in coms:
        n = random.choice([130, 140, 150])
        rows.append(f"({com}, YEAR(CURDATE()), MONTH(CURDATE()), 0, {n}, 1)")
        rows.append(f"({com}, YEAR(CURDATE() - INTERVAL 1 MONTH), MONTH(CURDATE() - INTERVAL 1 MONTH), 0, {n-10}, 1)")
w(",\n".join(rows) + ";")

w("\n-- NOTIFICATIONS d'exemple")
notifs = [(1,"Bienvenue","Le projet est prêt avec un jeu de données de simulation complet.","RAPPORT"),
          (7,"Paiements à encaisser","Des commandes du jour attendent la confirmation de paiement.","NOUVELLE_COMMANDE"),
          (18,"Paiements à encaisser","Des commandes du jour attendent la confirmation de paiement.","NOUVELLE_COMMANDE"),
          (6,"Alerte stock","Gold 8% 50 cl CAN, Tonic 100 cl et Booster Cuba Libre sont en rupture.","STOCK_ALERTE"),
          (3,"Défaut produit signalé","Un défaut attend votre validation.","DEFAUT_PRODUIT"),
          (1,"Demande de code client","Épicerie Rova : validée par le manager, code à attribuer.","CODE_CLIENT")]
w("INSERT INTO `notifications` (`utilisateur_id`,`titre`,`message`,`type`) VALUES\n" + ",\n".join(f"({a},{q(b)},{q(c)},'{d}')" for a,b,c,d in notifs) + ";")

open("donnees_generees.sql", "w").write("\n".join(out) + "\n")
print("produits", len(prod), "clients", len(clients), "commandes", len(commandes), "lignes", len(lignes),
      "visites", len(visites), "mouvements", len(mouvements), "objectif", obj)

<?php
// ============================================================
// modules/logistique/a_preparer.php
// Préparation des commandes payées
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/stock.php';

$ctx  = include_layout('Commandes à préparer', ['LOGISTIQUE','ADMIN']);
$user = $ctx['user'];
$db   = getDB();

// Traitement validation sortie
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $commande_id = (int)($_POST['commande_id'] ?? 0);
  $action      = $_POST['action'] ?? '';

  if ($commande_id && $action === 'valider_sortie') {
    try {
      $db->beginTransaction();

      // Verrouiller la commande et vérifier son statut : empêche une double
      // sortie de stock (double clic, rafraîchissement F5, deux onglets).
      $stmt = $db->prepare("SELECT statut FROM commandes WHERE id=? FOR UPDATE");
      $stmt->execute([$commande_id]);
      $statut_actuel = $stmt->fetchColumn();
      if (!in_array($statut_actuel, ['PAYEE','EN_PREPARATION'], true)) {
        throw new Exception("Cette commande n'est plus à préparer (déjà livrée ?).");
      }

      // Récupérer lignes de commande
      $stmt = $db->prepare("
        SELECT lc.*, p.volume_hl, p.kit
        FROM lignes_commande lc
        JOIN produits p ON lc.produit_id = p.id
        WHERE lc.commande_id = ?
      ");
      $stmt->execute([$commande_id]);
      $lignes = $stmt->fetchAll();

      // Vérifier le stock disponible avant toute sortie
      foreach ($lignes as $l) {
        $besoin = (int)$l['quantite_casiers'] * (int)$l['kit'] + (int)$l['quantite_bouteilles'];
        $dispo  = stock_disponible_btl($db, (int)$l['produit_id']);
        if ($besoin > $dispo) {
          $stmt = $db->prepare("SELECT description FROM produits WHERE id=?");
          $stmt->execute([$l['produit_id']]);
          throw new Exception("Stock insuffisant pour « " . $stmt->fetchColumn() . " » : "
            . intdiv($dispo, (int)$l['kit']) . " casier(s) + " . ($dispo % (int)$l['kit']) . " bouteille(s) disponibles.");
        }
      }

      foreach ($lignes as $l) {
        // Enregistrer mouvement (source unique de vérité pour le stock,
        // déjà utilisée par admin/stock.php et logistique/stock.php)
        $stmt = $db->prepare("
          INSERT INTO mouvements_stock
            (produit_id, type, quantite_casiers, quantite_bouteilles, commande_id, logistique_id)
          VALUES (?, 'SORTIE', ?, ?, ?, ?)
        ");
        $stmt->execute([
          $l['produit_id'],
          $l['quantite_casiers'],
          $l['quantite_bouteilles'],
          $commande_id,
          $user['id']
        ]);
      }

      // Mettre à jour statut commande
      $stmt = $db->prepare("UPDATE commandes SET statut='LIVREE' WHERE id=?");
      $stmt->execute([$commande_id]);

      $db->commit();
      $success_msg = "Sortie validée ! Stock mis à jour.";
    } catch (Exception $e) {
      $db->rollBack();
      $error_msg = "Erreur : " . $e->getMessage();
    }
  } elseif ($commande_id && $action === 'demarrer') {
    $stmt = $db->prepare("UPDATE commandes SET statut='EN_PREPARATION' WHERE id=? AND statut='PAYEE'");
    $stmt->execute([$commande_id]);
  }

  // Message conservé en session : sinon il était perdu par la redirection
  if (!empty($success_msg)) $_SESSION['flash_ok']  = $success_msg;
  if (!empty($error_msg))   $_SESSION['flash_err'] = $error_msg;
  header('Location: a_preparer.php');
  exit;
}
$success_msg = $_SESSION['flash_ok']  ?? ''; unset($_SESSION['flash_ok']);
$error_msg   = $_SESSION['flash_err'] ?? ''; unset($_SESSION['flash_err']);

// Commandes à préparer
$commandes = $db->query("
  SELECT c.*, cl.nom AS client_nom, cl.code_client, cl.type AS client_type,
         cl.adresse, cl.telephone AS client_tel,
         CONCAT(u.prenom,' ',u.nom) AS commercial_nom,
         -- Distributeur
         dc.nom AS dist_nom, dc.telephone AS dist_tel
  FROM commandes c
  JOIN clients cl ON c.client_id = cl.id
  LEFT JOIN utilisateurs u ON c.commercial_id = u.id
  LEFT JOIN clients dc ON c.distributeur_id = dc.id
  WHERE c.statut IN ('PAYEE','EN_PREPARATION')
  ORDER BY c.statut DESC, c.date_commande ASC
")->fetchAll();
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Commandes à préparer</div>
      <div class="page-subtitle"><?= count($commandes) ?> commande(s) en attente</div>
    </div>
    <a href="dashboard.php" class="btn btn-secondary">← Retour</a>
  </div>
</div>

<?php if (!empty($success_msg)): ?>
<div class="alert alert-success">✅ <?= htmlspecialchars($success_msg) ?></div>
<?php endif; ?>
<?php if (!empty($error_msg)): ?>
<div class="alert alert-error">❌ <?= htmlspecialchars($error_msg) ?></div>
<?php endif; ?>

<?php if (empty($commandes)): ?>
<div class="card" style="text-align:center;padding:3rem">
  <div style="font-size:2rem;margin-bottom:.8rem">✅</div>
  <div style="font-weight:600;margin-bottom:.3rem">Aucune commande à préparer</div>
  <div style="font-size:.82rem;color:var(--text-mute)">Toutes les commandes ont été traitées.</div>
</div>
<?php else: ?>

<?php foreach ($commandes as $c):
  // Lignes de la commande
  $stmt = $db->prepare("
    SELECT lc.*, p.description, p.code, p.type_emballage
    FROM lignes_commande lc
    JOIN produits p ON lc.produit_id = p.id
    WHERE lc.commande_id = ?
  ");
  $stmt->execute([$c['id']]);
  $lignes = $stmt->fetchAll();
?>
<div class="card" style="margin-bottom:1rem;padding:0;overflow:hidden;
  border-color:<?= $c['statut'] === 'EN_PREPARATION' ? 'var(--red)' : 'var(--border)' ?>">

  <!-- Header commande -->
  <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);
              background:<?= $c['statut'] === 'EN_PREPARATION' ? 'rgba(232,0,28,.06)' : 'var(--bg3)' ?>;
              display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem">
    <div>
      <div style="font-family:monospace;font-size:.78rem;color:var(--text-mute)">
        <?= htmlspecialchars($c['code_commande']) ?>
        <?= $c['statut'] === 'EN_PREPARATION'
          ? "<span class='badge badge-red' style='margin-left:.5rem'>En préparation</span>"
          : "<span class='badge badge-orange' style='margin-left:.5rem'>Payée</span>" ?>
      </div>
      <div style="font-size:.95rem;font-weight:700;margin-top:.2rem">
        <?= htmlspecialchars($c['client_nom']) ?>
        <span style="font-size:.72rem;font-weight:400;color:var(--text-mute)">(<?= htmlspecialchars($c['code_client']) ?>)</span>
      </div>
      <div style="font-size:.72rem;color:var(--text-mute);margin-top:.2rem">
        <?= htmlspecialchars($c['adresse'] ?? '') ?>
        <?php if ($c['client_tel']): ?> · Tél: <?= htmlspecialchars($c['client_tel']) ?><?php endif; ?>
        <?php if ($c['dist_nom']): ?> · Dist: <strong><?= htmlspecialchars($c['dist_nom']) ?></strong><?php endif; ?>
      </div>
    </div>
    <div style="text-align:right">
      <div style="font-size:.72rem;color:var(--text-mute)">Montant payé</div>
      <div style="font-size:1rem;font-weight:700;color:var(--red)"><?= number_format($c['montant_a_payer']) ?> Ar</div>
      <div style="font-size:.68rem;color:var(--text-mute)"><?= number_format($c['total_hl'],4) ?> hl · <?= $c['mode_paiement'] ?? '—' ?></div>
    </div>
  </div>

  <!-- Lignes produits -->
  <div style="overflow-x:auto">
    <table style="width:100%;border-collapse:collapse;font-size:.78rem">
      <thead>
        <tr style="background:var(--bg3)">
          <th style="padding:.5rem .8rem;text-align:left;color:var(--text-mute);font-size:.65rem;font-weight:600;text-transform:uppercase">Produit</th>
          <th style="padding:.5rem .8rem;text-align:center;color:var(--text-mute);font-size:.65rem;font-weight:600">Casiers</th>
          <th style="padding:.5rem .8rem;text-align:center;color:var(--text-mute);font-size:.65rem;font-weight:600">Bouteilles</th>
          <th style="padding:.5rem .8rem;text-align:right;color:var(--text-mute);font-size:.65rem;font-weight:600">Volume</th>
          <th style="padding:.5rem .8rem;text-align:center;color:var(--text-mute);font-size:.65rem;font-weight:600">✓</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($lignes as $l): ?>
        <tr style="border-bottom:1px solid var(--bg3)">
          <td style="padding:.55rem .8rem">
            <div style="font-weight:500"><?= htmlspecialchars($l['description']) ?></div>
            <div style="font-size:.65rem;color:var(--text-mute)"><?= $l['code'] ?> · <?= $l['type_emballage'] ?></div>
          </td>
          <td style="padding:.55rem .8rem;text-align:center;font-size:1rem;font-weight:700;color:var(--red)">
            <?= $l['quantite_casiers'] ?: '—' ?>
          </td>
          <td style="padding:.55rem .8rem;text-align:center">
            <?= $l['quantite_bouteilles'] ?: '—' ?>
          </td>
          <td style="padding:.55rem .8rem;text-align:right;font-size:.75rem;color:var(--text-mute)">
            <?= number_format($l['volume_hl'],4) ?> hl
          </td>
          <td style="padding:.55rem .8rem;text-align:center">
            <input type="checkbox" onclick="verifierLigne(this, <?= $c['id'] ?>)"
              style="width:18px;height:18px;accent-color:var(--red);cursor:pointer">
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Actions -->
  <div style="padding:.8rem 1.2rem;border-top:1px solid var(--border);display:flex;gap:.6rem;justify-content:flex-end">
    <?php if ($c['statut'] === 'PAYEE'): ?>
    <form method="POST" style="margin:0">
      <input type="hidden" name="commande_id" value="<?= $c['id'] ?>">
      <input type="hidden" name="action" value="demarrer">
      <button type="submit" class="btn btn-secondary btn-sm">▶ Démarrer la préparation</button>
    </form>
    <?php endif; ?>
    <form method="POST" id="form_valider_<?= $c['id'] ?>" style="margin:0">
      <input type="hidden" name="commande_id" value="<?= $c['id'] ?>">
      <input type="hidden" name="action" value="valider_sortie">
      <button type="button"
        onclick="validerSortie(<?= $c['id'] ?>, '<?= addslashes($c['code_commande']) ?>')"
        id="btn_valider_<?= $c['id'] ?>"
        class="btn btn-primary btn-sm"
        <?= $c['statut'] === 'PAYEE' ? 'style="opacity:.5;pointer-events:none"' : '' ?>>
        ✅ Valider la sortie
      </button>
    </form>
  </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<!-- Modal confirmation -->
<div id="modalValider" style="display:none;position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.7);backdrop-filter:blur(4px);align-items:center;justify-content:center">
  <div class="modal-box" style="border:1px solid var(--border);border-radius:16px;
              padding:1.6rem;max-width:380px;width:90%;text-align:center">
    <div style="font-size:2rem;margin-bottom:.8rem">📦</div>
    <div style="font-weight:700;font-size:1rem;margin-bottom:.5rem">Confirmer la sortie ?</div>
    <div style="font-size:.8rem;color:var(--text-mute);margin-bottom:1.4rem" id="modalValiderTxt"></div>
    <div style="display:flex;gap:.7rem">
      <button onclick="document.getElementById('modalValider').style.display='none'"
        class="btn btn-secondary" style="flex:1;justify-content:center">Annuler</button>
      <button id="btnConfirmerSortie" class="btn btn-primary" style="flex:1;justify-content:center">
        ✅ Confirmer
      </button>
    </div>
  </div>
</div>

<script>
let cmdIdCourant = null;

function verifierLigne(cb, cmdId) {
  // Vérifier si toutes les cases sont cochées pour cette commande
  const lignes = document.querySelectorAll(`[onclick*="${cmdId}"]`);
  const toutCoche = [...lignes].every(l => l.checked);
  const btn = document.getElementById('btn_valider_' + cmdId);
  if (btn) {
    btn.style.opacity = toutCoche ? '1' : '.5';
    btn.style.pointerEvents = toutCoche ? 'auto' : 'none';
  }
}

function validerSortie(cmdId, code) {
  cmdIdCourant = cmdId;
  document.getElementById('modalValiderTxt').textContent =
    `Commande ${code} — Le stock entrepôt sera mis à jour automatiquement.`;
  document.getElementById('modalValider').style.display = 'flex';
  document.getElementById('btnConfirmerSortie').onclick = function() {
    document.getElementById('form_valider_' + cmdIdCourant).submit();
  };
}
</script>

<?php close_layout(); ?>

<?php
// ============================================================
// modules/logistique/defauts.php
// Traitement remplacement produits défectueux
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Défauts produits', ['LOGISTIQUE','ADMIN']);
$user = $ctx['user'];
$db   = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $defaut_id = (int)($_POST['defaut_id'] ?? 0);
  $action    = $_POST['action'] ?? '';

  if ($defaut_id && $action === 'confirmer') {
    try {
      $db->beginTransaction();

      // Infos défaut
      $stmt = $db->prepare("SELECT * FROM defauts_produits WHERE id=? AND statut='VALIDE_MANAGER' FOR UPDATE");
      $stmt->execute([$defaut_id]);
      $defaut = $stmt->fetch();

      if ($defaut) {
        // Mettre à jour stock (retour + ressortie)
        $stmt = $db->prepare("
          INSERT INTO mouvements_stock
            (produit_id, type, quantite_casiers, quantite_bouteilles, commande_id, logistique_id, remarque)
          VALUES (?, 'RETOUR_DEFAUT', 0, ?, ?, ?, 'Remplacement produit défectueux (sortie de produit neuf)')
        ");
        // La quantité d'un défaut est saisie en unités (bouteilles) par le commercial :
        // on l'enregistre donc en bouteilles (et non en casiers), et ce mouvement est
        // compté comme une SORTIE dans le calcul du stock (includes/stock.php).
        $stmt->execute([$defaut['produit_id'], $defaut['quantite'], $defaut['commande_id'], $user['id']]);

        // Statut défaut
        $stmt = $db->prepare("
          UPDATE defauts_produits SET statut='REMPLACEMENT_CONFIRME', logistique_id=?
          WHERE id=?
        ");
        $stmt->execute([$user['id'], $defaut_id]);

        // Notifier commercial
        $stmt = $db->prepare("
          INSERT INTO notifications (utilisateur_id, titre, message, type, reference_id)
          VALUES (?,?,?,'DEFAUT_PRODUIT',?)
        ");
        $stmt->execute([
          $defaut['commercial_id'],
          'Remplacement confirmé',
          'Le remplacement du produit défectueux a été confirmé par la logistique.',
          $defaut_id
        ]);
      }

      $db->commit();
      $success = "Remplacement confirmé.";
    } catch (Exception $e) {
      $db->rollBack();
      $error = "Erreur : " . $e->getMessage();
    }
  }
  header('Location: defauts.php');
  exit;
}

$defauts = $db->query("
  SELECT d.*, p.description AS produit_nom, p.code,
         c.code_commande, cl.nom AS client_nom,
         CONCAT(u.prenom,' ',u.nom) AS commercial_nom
  FROM defauts_produits d
  JOIN produits p ON d.produit_id = p.id
  JOIN commandes c ON d.commande_id = c.id
  JOIN clients cl ON c.client_id = cl.id
  JOIN utilisateurs u ON d.commercial_id = u.id
  ORDER BY FIELD(d.statut,'VALIDE_MANAGER','REMPLACEMENT_CONFIRME','REJETE'), d.created_at DESC
")->fetchAll();

$a_traiter = array_filter($defauts, fn($d) => $d['statut'] === 'VALIDE_MANAGER');
$traites   = array_filter($defauts, fn($d) => $d['statut'] !== 'VALIDE_MANAGER');
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Défauts produits</div>
      <div class="page-subtitle"><?= count($a_traiter) ?> remplacement(s) à effectuer</div>
    </div>
    <a href="dashboard.php" class="btn btn-secondary">← Retour</a>
  </div>
</div>

<?php if (!empty($success)): ?><div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if (!empty($error)): ?><div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if (empty($a_traiter)): ?>
<div class="card" style="text-align:center;padding:3rem;margin-bottom:1rem">
  <div style="font-size:2rem;margin-bottom:.8rem">✅</div>
  <div style="font-weight:600">Aucun remplacement à effectuer</div>
</div>
<?php else: ?>
<?php foreach ($a_traiter as $d): ?>
<div class="card" style="margin-bottom:.8rem;border-color:rgba(232,0,28,.3)">
  <div style="display:grid;grid-template-columns:1fr auto;gap:1rem;align-items:start">
    <div>
      <div style="display:flex;align-items:center;gap:.6rem;margin-bottom:.4rem">
        <span style="font-weight:700"><?= htmlspecialchars($d['produit_nom']) ?></span>
        <span class="badge badge-orange"><?= $d['quantite'] ?> unité(s)</span>
        <span class="badge badge-blue">Validé manager</span>
      </div>
      <div style="font-size:.75rem;color:var(--text-mute);margin-bottom:.4rem">
        Commande : <?= $d['code_commande'] ?> · Client : <?= htmlspecialchars($d['client_nom']) ?>
      </div>
      <div style="font-size:.78rem;padding:.5rem .7rem;background:var(--bg3);border-radius:6px">
        <?= htmlspecialchars($d['description']) ?>
      </div>
      <div style="font-size:.7rem;color:var(--text-mute);margin-top:.4rem">
        Signalé par <?= htmlspecialchars($d['commercial_nom']) ?>
        le <?= date('d/m/Y', strtotime($d['created_at'])) ?>
      </div>
    </div>
    <form method="POST">
      <input type="hidden" name="defaut_id" value="<?= $d['id'] ?>">
      <input type="hidden" name="action" value="confirmer">
      <button type="submit" class="btn btn-primary btn-sm">
        ✅ Confirmer remplacement
      </button>
    </form>
  </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<!-- Historique -->
<?php if (!empty($traites)): ?>
<div class="card" style="padding:0;overflow:hidden;margin-top:1rem">
  <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:.85rem;font-weight:600">
    Historique
  </div>
  <table class="data-table">
    <thead>
      <tr><th>Produit</th><th>Client</th><th>Qté</th><th>Statut</th><th>Date</th></tr>
    </thead>
    <tbody>
      <?php foreach ($traites as $d): ?>
      <tr>
        <td><?= htmlspecialchars($d['produit_nom']) ?></td>
        <td><?= htmlspecialchars($d['client_nom']) ?></td>
        <td><?= $d['quantite'] ?></td>
        <td><?= match($d['statut']) {
          'REMPLACEMENT_CONFIRME' => "<span class='badge badge-green'>Remplacé</span>",
          'REJETE'                => "<span class='badge badge-red'>Rejeté</span>",
          default                 => "<span class='badge badge-mute'>{$d['statut']}</span>",
        } ?></td>
        <td style="font-size:.72rem"><?= date('d/m/Y', strtotime($d['created_at'])) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<?php close_layout(); ?>

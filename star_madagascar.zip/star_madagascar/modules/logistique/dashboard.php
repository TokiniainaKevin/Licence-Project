<?php
// ============================================================
// modules/logistique/dashboard.php
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/stock.php';

$ctx  = include_layout('Logistique', ['LOGISTIQUE','ADMIN']);
$user = $ctx['user'];
$db   = getDB();

// Commandes payées à préparer aujourd'hui
$stmt = $db->query("
  SELECT COUNT(*) FROM commandes
  WHERE statut = 'PAYEE' OR statut = 'EN_PREPARATION'
");
$nb_a_preparer = $stmt->fetchColumn();

// Stock en alerte (sous seuil)
$stmt = $db->query("
  SELECT COUNT(*) FROM produits p
  " . stock_join_sql() . "
  WHERE COALESCE(se.total_btl,0) <= 0 AND p.actif = 1
");
$nb_alertes = $stmt->fetchColumn();

// Retours consigne en attente
// Les retours sont validés dès leur saisie : on affiche donc ceux du jour
$stmt = $db->query("SELECT COUNT(*) FROM retours_consigne WHERE DATE(created_at)=CURDATE()");
$nb_retours = $stmt->fetchColumn();

// Défauts validés à traiter
$stmt = $db->query("SELECT COUNT(*) FROM defauts_produits WHERE statut='VALIDE_MANAGER'");
$nb_defauts = $stmt->fetchColumn();

// Commandes à préparer (détail)
$commandes = $db->query("
  SELECT c.*, cl.nom AS client_nom, cl.code_client, cl.type AS client_type,
         cl.adresse,
         CONCAT(u.prenom,' ',u.nom) AS commercial_nom,
         (SELECT SUM(lc.quantite_casiers) FROM lignes_commande lc WHERE lc.commande_id=c.id) AS total_casiers
  FROM commandes c
  JOIN clients cl ON c.client_id = cl.id
  LEFT JOIN utilisateurs u ON c.commercial_id = u.id
  WHERE c.statut IN ('PAYEE','EN_PREPARATION')
  ORDER BY c.date_commande ASC
  LIMIT 20
")->fetchAll();

// Mouvements récents (entrées/sorties)
$mouvements = $db->query("
  SELECT m.*, p.description AS produit_nom, p.code AS produit_code,
         CONCAT(u.prenom,' ',u.nom) AS agent_nom
  FROM mouvements_stock m
  JOIN produits p ON m.produit_id = p.id
  JOIN utilisateurs u ON m.logistique_id = u.id
  ORDER BY m.created_at DESC LIMIT 8
")->fetchAll();
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Tableau de bord Logistique</div>
      <div class="page-subtitle"><?= date('d/m/Y') ?> — Entrepôt Star Madagascar Fianarantsoa</div>
    </div>
    <div style="display:flex;gap:.6rem">
      <a href="stock.php" class="btn btn-secondary">📦 Voir le stock</a>
      <a href="a_preparer.php" class="btn btn-primary">🚛 Préparer les commandes</a>
    </div>
  </div>
</div>

<!-- Alertes -->
<?php if ($nb_alertes > 0): ?>
<div class="alert alert-error" style="margin-bottom:1.2rem">
  ⚠️ <?= $nb_alertes ?> produit(s) sous le seuil d'alerte de stock.
  <a href="stock.php?filtre=alerte" style="color:inherit;text-decoration:underline;margin-left:.5rem">Voir →</a>
</div>
<?php endif; ?>

<!-- KPI -->
<div class="grid-4" style="margin-bottom:1.2rem">
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Commandes à préparer</div>
    <div class="kpi-value" style="color:<?= $nb_a_preparer > 0 ? 'var(--red)' : 'var(--text)' ?>">
      <?= $nb_a_preparer ?> <span class="unit">cmd</span>
    </div>
    <a href="a_preparer.php" style="font-size:.72rem;color:var(--red);display:block;margin-top:.4rem">
      Voir les commandes →
    </a>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Alertes stock</div>
    <div class="kpi-value" style="color:<?= $nb_alertes > 0 ? '#ffa000' : 'var(--text)' ?>">
      <?= $nb_alertes ?> <span class="unit">produits</span>
    </div>
    <a href="stock.php" style="font-size:.72rem;color:#ffa000;display:block;margin-top:.4rem">
      Gérer le stock →
    </a>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Retours consigne enregistrés</div>
    <div class="kpi-value"><?= $nb_retours ?> <span class="unit">aujourd'hui</span></div>
    <a href="consignes.php" style="font-size:.72rem;color:var(--text-mute);display:block;margin-top:.4rem">
      Enregistrer un retour →
    </a>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Défauts à traiter</div>
    <div class="kpi-value" style="color:<?= $nb_defauts > 0 ? 'var(--red)' : 'var(--text)' ?>">
      <?= $nb_defauts ?> <span class="unit">signalements</span>
    </div>
    <a href="defauts.php" style="font-size:.72rem;color:var(--red);display:block;margin-top:.4rem">
      Traiter →
    </a>
  </div>
</div>

<div class="grid-2">

  <!-- Commandes à préparer -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.85rem;font-weight:600">🚛 Commandes à préparer</div>
      <a href="a_preparer.php" class="btn btn-secondary btn-sm">Tout voir</a>
    </div>
    <?php if (empty($commandes)): ?>
    <div style="padding:2rem;text-align:center;color:var(--text-mute);font-size:.82rem">
      ✅ Aucune commande en attente de préparation.
    </div>
    <?php else: ?>
    <table class="data-table">
      <thead>
        <tr>
          <th>N° Commande</th>
          <th>Client</th>
          <th style="text-align:right">Hl</th>
          <th>Statut</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($commandes as $c): ?>
        <tr>
          <td style="font-family:monospace;font-size:.72rem;color:var(--text-mute)">
            <?= htmlspecialchars($c['code_commande']) ?>
          </td>
          <td>
            <div style="font-weight:500;color:var(--text)"><?= htmlspecialchars($c['client_nom']) ?></div>
            <div style="font-size:.65rem;color:var(--text-mute)"><?= htmlspecialchars($c['code_client']) ?></div>
          </td>
          <td style="text-align:right;font-weight:700;color:var(--red)">
            <?= number_format($c['total_hl'],2) ?>
          </td>
          <td>
            <?= $c['statut'] === 'EN_PREPARATION'
              ? "<span class='badge badge-blue'>En préparation</span>"
              : "<span class='badge badge-orange'>Payée</span>" ?>
          </td>
          <td>
            <a href="a_preparer.php?cmd_id=<?= $c['id'] ?>"
               class="btn btn-primary btn-sm">Préparer</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

  <!-- Mouvements récents -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.85rem;font-weight:600">🔄 Mouvements récents</div>
      <a href="mouvements.php" class="btn btn-secondary btn-sm">Historique</a>
    </div>
    <?php if (empty($mouvements)): ?>
    <div style="padding:2rem;text-align:center;color:var(--text-mute);font-size:.82rem">
      Aucun mouvement enregistré.
    </div>
    <?php else: ?>
    <table class="data-table">
      <thead>
        <tr>
          <th>Produit</th>
          <th>Type</th>
          <th style="text-align:right">Casiers</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($mouvements as $m): ?>
        <tr>
          <td>
            <div style="font-size:.78rem;font-weight:500"><?= htmlspecialchars($m['produit_nom']) ?></div>
            <div style="font-size:.65rem;color:var(--text-mute)"><?= $m['produit_code'] ?></div>
          </td>
          <td>
            <?= match($m['type']) {
              'ENTREE'         => "<span class='badge badge-green'>Entrée</span>",
              'SORTIE'         => "<span class='badge badge-red'>Sortie</span>",
              'RETOUR_DEFAUT'  => "<span class='badge badge-orange'>Retour défaut</span>",
              'RETOUR_CONSIGNE'=> "<span class='badge badge-blue'>Retour consigne</span>",
              default          => "<span class='badge badge-mute'>{$m['type']}</span>",
            } ?>
          </td>
          <td style="text-align:right;font-weight:600">
            <?= trim(($m['quantite_casiers'] > 0 ? $m['quantite_casiers'].' cas.' : '').' '.($m['quantite_bouteilles'] > 0 ? $m['quantite_bouteilles'].' btl' : '')) ?: '—' ?>
          </td>
          <td style="font-size:.7rem;color:var(--text-mute)">
            <?= date('d/m H:i', strtotime($m['created_at'])) ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>

<?php ?>
<!-- ── Graphiques ─────────────────────────────────────────── -->
<?php
$j14 = jours_periode(14);
$mv = function(string $type) use ($db, $j14) {
  $st = $db->prepare("SELECT DATE(created_at) d, SUM(quantite_casiers + quantite_bouteilles / (SELECT kit FROM produits p WHERE p.id=m.produit_id)) v
                      FROM mouvements_stock m WHERE type=? AND created_at >= DATE_SUB(CURDATE(), INTERVAL 14 DAY) GROUP BY DATE(created_at)");
  $st->execute([$type]); return array_values(serie($j14, $st->fetchAll()));
};
$stock_fam = $db->query("SELECT p.famille l, ROUND(SUM(" . "CAST(COALESCE(se.total_btl,0) AS SIGNED)" . " / p.kit),0) v FROM produits p " . stock_join_sql() . " WHERE p.actif=1 GROUP BY p.famille ORDER BY v DESC")->fetchAll();
?>
<div class="grid-2" style="margin-top:1rem">
<?= graphique('gMouv', 'Entrées et sorties de stock (14 derniers jours)', ['type'=>'bar','unite'=>'casiers','data'=>['labels'=>etiquettes_jours($j14),'datasets'=>[
  ['label'=>'Entrées','data'=>$mv('ENTREE'),'backgroundColor'=>'rgba(31,157,85,.8)','borderRadius'=>3],
  ['label'=>'Sorties (livraisons)','data'=>$mv('SORTIE'),'backgroundColor'=>'rgba(232,0,28,.75)','borderRadius'=>3],
]],'options'=>['scales'=>['y'=>['beginAtZero'=>true,'title'=>['display'=>true,'text'=>'casiers']]]]], 280) ?>
<?= graphique('gStockFam', 'Stock disponible par famille', ['type'=>'bar','unite'=>'casiers','data'=>['labels'=>array_column($stock_fam,'l'),'datasets'=>[
  ['label'=>'Casiers','data'=>array_map('floatval',array_column($stock_fam,'v')),'backgroundColor'=>'rgba(232,175,52,.8)','borderRadius'=>4]]],
  'options'=>['indexAxis'=>'y','plugins'=>['legend'=>['display'=>false]]]], max(280, 22*count($stock_fam)+40)) ?>
</div>

<?php close_layout(); ?>

<?php
// ============================================================
// modules/logistique/mouvements.php
// Historique complet des mouvements de stock
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Mouvements stock', ['LOGISTIQUE','ADMIN','DIRECTEUR']);
$user = $ctx['user'];
$db   = getDB();

$date_debut = $_GET['debut'] ?? date('Y-m-d', strtotime('-7 days'));
$date_fin   = $_GET['fin']   ?? date('Y-m-d');
$type_f     = $_GET['type']  ?? '';

$where  = "WHERE DATE(m.created_at) BETWEEN ? AND ?";
$params = [$date_debut, $date_fin];
if ($type_f) { $where .= " AND m.type=?"; $params[] = $type_f; }

$stmt = $db->prepare("
  SELECT m.*, p.description AS produit_nom, p.code AS produit_code, p.volume_hl, p.kit,
         CONCAT(u.prenom,' ',u.nom) AS agent_nom,
         c.code_commande, cl.nom AS client_nom
  FROM mouvements_stock m
  JOIN produits p ON m.produit_id = p.id
  JOIN utilisateurs u ON m.logistique_id = u.id
  LEFT JOIN commandes c ON m.commande_id = c.id
  LEFT JOIN clients cl ON c.client_id = cl.id
  $where
  ORDER BY m.created_at DESC
  LIMIT 500
");
$stmt->execute($params);
$mouvements = $stmt->fetchAll();

$nb_entrees = count(array_filter($mouvements, fn($m) => $m['type']==='ENTREE'));
$nb_sorties = count(array_filter($mouvements, fn($m) => $m['type']==='SORTIE'));
$hl_sortis  = array_sum(array_map(fn($m) => in_array($m['type'],['SORTIE','RETOUR_DEFAUT'],true) ? ($m['quantite_casiers'] + $m['quantite_bouteilles'] / max(1,(int)$m['kit'])) * $m['volume_hl'] : 0, $mouvements));
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Mouvements de stock</div>
      <div class="page-subtitle">
        <?= count($mouvements) ?> mouvement(s) ·
        <?= $nb_entrees ?> entrée(s) · <?= $nb_sorties ?> sortie(s)
      </div>
    </div>
    <a href="dashboard.php" class="btn btn-secondary">← Retour</a>
  </div>
</div>

<!-- Filtres -->
<div class="card" style="padding:.7rem 1rem;margin-bottom:1rem">
  <form method="GET" style="display:flex;gap:.6rem;flex-wrap:wrap;align-items:center">
    <input type="date" name="debut" value="<?= $date_debut ?>"
      style="background:var(--bg3);border:1px solid var(--border);border-radius:8px;
             padding:.5rem .8rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
    <input type="date" name="fin" value="<?= $date_fin ?>"
      style="background:var(--bg3);border:1px solid var(--border);border-radius:8px;
             padding:.5rem .8rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
    <select name="type"
      style="background:var(--bg3);border:1px solid var(--border);border-radius:8px;
             padding:.5rem .8rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
      <option value="">Tous types</option>
      <option value="ENTREE" <?= $type_f==='ENTREE'?'selected':'' ?>>Entrées</option>
      <option value="SORTIE" <?= $type_f==='SORTIE'?'selected':'' ?>>Sorties</option>
      <option value="RETOUR_DEFAUT" <?= $type_f==='RETOUR_DEFAUT'?'selected':'' ?>>Retours défaut</option>
      <option value="RETOUR_CONSIGNE" <?= $type_f==='RETOUR_CONSIGNE'?'selected':'' ?>>Retours consigne</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filtrer</button>
  </form>
</div>

<div class="card" style="padding:0;overflow:hidden">
  <table class="data-table">
    <thead>
      <tr>
        <th>Produit</th><th>Type</th>
        <th style="text-align:center">Casiers</th>
        <th style="text-align:center">Bouteilles</th>
        <th>Commande / Client</th>
        <th>Agent</th><th>Date/Heure</th>
        <th>Remarque</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($mouvements as $m): ?>
      <tr>
        <td>
          <div style="font-weight:500;font-size:.8rem"><?= htmlspecialchars($m['produit_nom']) ?></div>
          <div style="font-size:.63rem;color:var(--text-mute)"><?= $m['produit_code'] ?></div>
        </td>
        <td><?= match($m['type']) {
          'ENTREE'          => "<span class='badge badge-green'>Entrée</span>",
          'SORTIE'          => "<span class='badge badge-red'>Sortie</span>",
          'RETOUR_DEFAUT'   => "<span class='badge badge-orange'>Retour défaut</span>",
          'RETOUR_CONSIGNE' => "<span class='badge badge-blue'>Retour consigne</span>",
          default           => "<span class='badge badge-mute'>{$m['type']}</span>",
        } ?></td>
        <td style="text-align:center;font-weight:700">
          <?= $m['quantite_casiers'] > 0 ? $m['quantite_casiers'] : '—' ?>
        </td>
        <td style="text-align:center">
          <?= $m['quantite_bouteilles'] > 0 ? $m['quantite_bouteilles'] : '—' ?>
        </td>
        <td style="font-size:.72rem">
          <?php if ($m['code_commande']): ?>
          <div style="font-family:monospace;color:var(--red)"><?= htmlspecialchars($m['code_commande']) ?></div>
          <div style="color:var(--text-mute)"><?= htmlspecialchars($m['client_nom'] ?? '') ?></div>
          <?php else: ?>
          <span style="color:var(--text-mute)">—</span>
          <?php endif; ?>
        </td>
        <td style="font-size:.72rem"><?= htmlspecialchars($m['agent_nom']) ?></td>
        <td style="font-size:.7rem;color:var(--text-mute);white-space:nowrap">
          <?= date('d/m/Y H:i', strtotime($m['created_at'])) ?>
        </td>
        <td style="font-size:.7rem;color:var(--text-mute);max-width:120px">
          <?= htmlspecialchars($m['remarque'] ?? '—') ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php close_layout(); ?>

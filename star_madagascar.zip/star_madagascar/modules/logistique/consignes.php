<?php
// ============================================================
// modules/logistique/consignes.php
// Retours de consigne (bouteilles/casiers)
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Retours consigne', ['LOGISTIQUE','ADMIN']);
$user = $ctx['user'];
$db   = getDB();

// Traitement
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action     = $_POST['action'] ?? '';
  $retour_id  = (int)($_POST['retour_id'] ?? 0);
  $client_id  = (int)($_POST['client_id'] ?? 0);
  $produit_id = (int)($_POST['produit_id'] ?? 0);
  $nb_btl     = (int)($_POST['nb_bouteilles'] ?? 0);
  $nb_cas     = (int)($_POST['nb_casiers'] ?? 0);

  if ($action === 'enregistrer' && $client_id && $produit_id) {
    // Récupérer prix consigne
    $stmt = $db->prepare("SELECT consigne_bouteille, consigne_casier FROM produits WHERE id=?");
    $stmt->execute([$produit_id]);
    $prod = $stmt->fetch();

    if ($prod) {
      $credit_b   = $nb_btl * $prod['consigne_bouteille'];
      $credit_c   = $nb_cas * $prod['consigne_casier'];
      $credit_tot = $credit_b + $credit_c;

      try {
        $db->beginTransaction();

        // Enregistrer retour
        $stmt = $db->prepare("
          INSERT INTO retours_consigne
            (client_id, logistique_id, produit_id, nb_bouteilles, nb_casiers,
             credit_bouteilles, credit_casiers, credit_total, statut)
          VALUES (?,?,?,?,?,?,?,?,'VALIDE')
        ");
        $stmt->execute([
          $client_id, $user['id'], $produit_id,
          $nb_btl, $nb_cas, $credit_b, $credit_c, $credit_tot
        ]);
        $retour_id = $db->lastInsertId();

        // Ajouter au solde consigne du client
        $stmt = $db->prepare("
          INSERT INTO solde_consigne (client_id, solde_ariary)
          VALUES (?, ?)
          ON DUPLICATE KEY UPDATE solde_ariary = solde_ariary + VALUES(solde_ariary)
        ");
        $stmt->execute([$client_id, $credit_tot]);

        // Mouvement stock
        $stmt = $db->prepare("
          INSERT INTO mouvements_stock
            (produit_id, type, quantite_casiers, quantite_bouteilles, retour_consigne_id, logistique_id)
          VALUES (?, 'RETOUR_CONSIGNE', ?, ?, ?, ?)
        ");
        $stmt->execute([$produit_id, $nb_cas, $nb_btl, $retour_id, $user['id']]);

        $db->commit();
        $success = "Retour enregistré ! Crédit de " . number_format($credit_tot) . " Ar ajouté au solde du client.";
      } catch (Exception $e) {
        $db->rollBack();
        $error = "Erreur : " . $e->getMessage();
      }
    }
  }
}

// Clients directs avec solde consigne
// Seuls les DEMI_GROS, DISTRIBUTEUR, STATION et GMS ont un compte consigne :
// les épiceries, bars et restaurants s'approvisionnent auprès d'un distributeur/demi-gros
// et ne retournent donc jamais de consigne directement à l'agence.
$clients = $db->query("
  SELECT c.id, c.nom, c.code_client, c.type,
         COALESCE(sc.solde_ariary, 0) AS solde
  FROM clients c
  LEFT JOIN solde_consigne sc ON sc.client_id = c.id
  WHERE c.type IN ('DEMI_GROS','DISTRIBUTEUR','STATION','GMS') AND c.statut = 'ACTIF'
  ORDER BY c.nom ASC
")->fetchAll();

// Produits avec consigne — seules les bouteilles en verre (consignées) sont retournables.
$produits = $db->query("
  SELECT id, description, code, consigne_bouteille, consigne_casier
  FROM produits
  WHERE actif=1 AND type_emballage='VER' AND (consigne_bouteille > 0 OR consigne_casier > 0)
  ORDER BY description ASC
")->fetchAll();

// Historique retours
$historique = $db->query("
  SELECT r.*, c.nom AS client_nom, c.code_client, p.description AS produit_nom,
         CONCAT(u.prenom,' ',u.nom) AS agent_nom
  FROM retours_consigne r
  JOIN clients c ON r.client_id = c.id
  JOIN produits p ON r.produit_id = p.id
  JOIN utilisateurs u ON r.logistique_id = u.id
  ORDER BY r.created_at DESC LIMIT 20
")->fetchAll();
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Retours de consigne</div>
      <div class="page-subtitle">Bouteilles et casiers en verre uniquement · clients directs (Demi-gros, Distributeur, Station, GMS)</div>
    </div>
  </div>
</div>

<?php if (!empty($success)): ?><div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if (!empty($error)): ?><div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;align-items:start;margin-bottom:1.2rem">

  <!-- Formulaire retour -->
  <div class="card card-top-line">
    <div style="font-size:.85rem;font-weight:600;margin-bottom:1.2rem">Enregistrer un retour</div>
    <form method="POST" style="display:flex;flex-direction:column;gap:.9rem">
      <input type="hidden" name="action" value="enregistrer">

      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Client *</label>
        <select name="client_id" id="selectClient" required
          onchange="afficherSolde(this)"
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.7rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
          <option value="">Sélectionner un client...</option>
          <?php foreach ($clients as $c): ?>
          <option value="<?= $c['id'] ?>" data-solde="<?= $c['solde'] ?>">
            <?= htmlspecialchars($c['nom']) ?> (<?= $c['code_client'] ?>) · Solde: <?= number_format($c['solde']) ?> Ar
          </option>
          <?php endforeach; ?>
        </select>
        <div id="soldeInfo" style="font-size:.72rem;color:#4d94ff;margin-top:.3rem;display:none">
          Solde consigne actuel : <strong id="soldeVal"></strong> Ar
        </div>
      </div>

      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Produit *</label>
        <select name="produit_id" id="selectProduit" required
          onchange="calculerCredit()"
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.7rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
          <option value="">Sélectionner un produit...</option>
          <?php foreach ($produits as $p): ?>
          <option value="<?= $p['id'] ?>"
            data-btl="<?= $p['consigne_bouteille'] ?>"
            data-cas="<?= $p['consigne_casier'] ?>">
            <?= htmlspecialchars($p['description']) ?> (<?= $p['code'] ?>)
            — <?= number_format($p['consigne_bouteille']) ?> Ar/btl
            <?= $p['consigne_casier'] > 0 ? '· '.number_format($p['consigne_casier']).' Ar/casier' : '' ?>
          </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem">
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Bouteilles rendues</label>
          <input type="number" name="nb_bouteilles" id="nbBtl" value="0" min="0"
            onchange="calculerCredit()"
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.65rem .9rem;color:var(--text);font-size:.9rem;font-family:Inter,sans-serif;text-align:center">
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Casiers rendus</label>
          <input type="number" name="nb_casiers" id="nbCas" value="0" min="0"
            onchange="calculerCredit()"
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.65rem .9rem;color:var(--text);font-size:.9rem;font-family:Inter,sans-serif;text-align:center">
        </div>
      </div>

      <!-- Calcul crédit -->
      <div id="creditCalc" style="display:none;background:rgba(0,200,100,.06);
        border:1px solid rgba(0,200,100,.2);border-radius:8px;padding:.8rem;font-size:.78rem">
        <div style="display:flex;justify-content:space-between;margin-bottom:.3rem">
          <span style="color:var(--text-mute)">Crédit bouteilles</span>
          <span id="creditBtl">0 Ar</span>
        </div>
        <div style="display:flex;justify-content:space-between;margin-bottom:.3rem">
          <span style="color:var(--text-mute)">Crédit casiers</span>
          <span id="creditCas">0 Ar</span>
        </div>
        <div style="display:flex;justify-content:space-between;font-weight:700;border-top:1px solid rgba(0,200,100,.2);padding-top:.3rem">
          <span>Total crédit</span>
          <span id="creditTotal" style="color:#00c864">0 Ar</span>
        </div>
      </div>

      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">
        🍾 Enregistrer le retour
      </button>
    </form>
  </div>

  <!-- Soldes consigne -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:.85rem;font-weight:600">
      Soldes consigne clients
    </div>
    <table class="data-table">
      <thead>
        <tr><th>Client</th><th>Type</th><th style="text-align:right">Solde</th></tr>
      </thead>
      <tbody>
        <?php foreach ($clients as $c): ?>
        <tr>
          <td>
            <div style="font-weight:500"><?= htmlspecialchars($c['nom']) ?></div>
            <div style="font-size:.65rem;color:var(--text-mute)"><?= $c['code_client'] ?></div>
          </td>
          <td style="font-size:.72rem"><?= $c['type'] ?></td>
          <td style="text-align:right;font-weight:700;color:<?= $c['solde'] > 0 ? '#00c864' : 'var(--text-mute)' ?>">
            <?= number_format($c['solde']) ?> Ar
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

</div>

<!-- Historique retours -->
<div class="card" style="padding:0;overflow:hidden">
  <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:.85rem;font-weight:600">
    Historique des retours
  </div>
  <table class="data-table">
    <thead>
      <tr>
        <th>Client</th><th>Produit</th>
        <th style="text-align:center">Bouteilles</th>
        <th style="text-align:center">Casiers</th>
        <th style="text-align:right">Crédit</th>
        <th>Agent</th><th>Date</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($historique as $h): ?>
      <tr>
        <td><?= htmlspecialchars($h['client_nom']) ?></td>
        <td style="font-size:.75rem"><?= htmlspecialchars($h['produit_nom']) ?></td>
        <td style="text-align:center"><?= $h['nb_bouteilles'] ?: '—' ?></td>
        <td style="text-align:center"><?= $h['nb_casiers'] ?: '—' ?></td>
        <td style="text-align:right;font-weight:600;color:#00c864">
          +<?= number_format($h['credit_total']) ?> Ar
        </td>
        <td style="font-size:.72rem"><?= htmlspecialchars($h['agent_nom']) ?></td>
        <td style="font-size:.7rem"><?= date('d/m/Y H:i', strtotime($h['created_at'])) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<script>
function afficherSolde(sel) {
  const opt = sel.options[sel.selectedIndex];
  const solde = parseInt(opt.dataset.solde || 0);
  document.getElementById('soldeInfo').style.display = solde > 0 ? '' : 'none';
  document.getElementById('soldeVal').textContent = solde.toLocaleString('fr-FR');
}

function calculerCredit() {
  const sel = document.getElementById('selectProduit');
  const opt = sel.options[sel.selectedIndex];
  if (!opt.value) return;

  const prixBtl = parseFloat(opt.dataset.btl || 0);
  const prixCas = parseFloat(opt.dataset.cas || 0);
  const nbBtl   = parseInt(document.getElementById('nbBtl').value || 0);
  const nbCas   = parseInt(document.getElementById('nbCas').value || 0);

  const cb = nbBtl * prixBtl;
  const cc = nbCas * prixCas;
  const ct = cb + cc;

  document.getElementById('creditBtl').textContent   = cb.toLocaleString('fr-FR') + ' Ar';
  document.getElementById('creditCas').textContent   = cc.toLocaleString('fr-FR') + ' Ar';
  document.getElementById('creditTotal').textContent = ct.toLocaleString('fr-FR') + ' Ar';
  document.getElementById('creditCalc').style.display = ct > 0 ? '' : 'none';
}
</script>

<?php close_layout(); ?>

<?php
// ============================================================
// modules/logistique/stock.php
// Gestion du stock entrepôt
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/stock.php';

$ctx  = include_layout('Stock entrepôt', ['LOGISTIQUE','ADMIN','DIRECTEUR','MANAGER']);
$user = $ctx['user'];
$db   = getDB();

$filtre   = $_GET['filtre'] ?? 'tous';
$editable = in_array($user['role'], ['LOGISTIQUE','ADMIN']);

// Traitement entrée stock
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $editable) {
  $produit_id = (int)($_POST['produit_id'] ?? 0);
  $casiers    = (int)($_POST['casiers'] ?? 0);
  $bouteilles = (int)($_POST['bouteilles'] ?? 0);
  $remarque   = trim($_POST['remarque'] ?? '');

  if ($produit_id && ($casiers > 0 || $bouteilles > 0)) {
    try {
      // Mouvement (le stock courant est calculé à partir des mouvements, plus de table séparée à synchroniser)
      $stmt = $db->prepare("
        INSERT INTO mouvements_stock
          (produit_id, type, quantite_casiers, quantite_bouteilles, logistique_id, remarque)
        VALUES (?, 'ENTREE', ?, ?, ?, ?)
      ");
      $stmt->execute([$produit_id, $casiers, $bouteilles, $user['id'], $remarque ?: null]);

      $success = "Entrée de stock enregistrée.";
    } catch (Exception $e) {
      $error = "Erreur : " . $e->getMessage();
    }
  }
}

// Récupérer stock
$where = '';
if ($filtre === 'alerte') {
  $where = "";
}

$stockSql = "
  SELECT p.id AS produit_id,
         " . stock_cols_sql() . ",
         p.description, p.code, p.type_emballage, p.kit,
         p.volume_hl, p.famille
  FROM produits p
  " . stock_join_sql() . "
  WHERE p.actif = 1
";
if ($filtre === 'alerte') $stockSql .= " AND COALESCE(se.total_btl,0) <= 0 ";
$stockSql .= " ORDER BY p.famille ASC, p.description ASC";
$stocks = $db->query($stockSql)->fetchAll();

// Produits pour le formulaire d'entrée
$produits = $db->query("
  SELECT id, description, code FROM produits WHERE actif=1 ORDER BY description ASC
")->fetchAll();

// Stats globales
$total_casiers = array_sum(array_column($stocks, 'quantite_casiers'));
$total_hl      = array_sum(array_column($stocks, 'volume_total_hl'));
$nb_alertes    = count(array_filter($stocks, fn($s) => (int)$s['total_bouteilles'] <= 0));
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Stock entrepôt</div>
      <div class="page-subtitle">
        <?= $total_casiers ?> casiers · <?= number_format($total_hl,2) ?> hl total
        <?php if ($nb_alertes > 0): ?>
          · <span style="color:#ffa000">⚠️ <?= $nb_alertes ?> alerte(s)</span>
        <?php endif; ?>
      </div>
    </div>
    <div style="display:flex;gap:.6rem">
      <a href="?filtre=tous" class="btn <?= $filtre === 'tous' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">Tous</a>
      <a href="?filtre=alerte" class="btn <?= $filtre === 'alerte' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">
        ⚠️ Alertes (<?= $nb_alertes ?>)
      </a>
      <?php if ($editable): ?>
      <button onclick="document.getElementById('modalEntree').style.display='flex'"
        class="btn btn-primary">+ Entrée stock</button>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php if (!empty($success)): ?><div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if (!empty($error)): ?><div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div><?php endif; ?>

<!-- Table stock -->
<div class="card" style="padding:0;overflow:hidden">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Produit</th>
          <th>Famille</th>
          <th style="text-align:center">Casiers</th>
          <th style="text-align:center">Bouteilles</th>
          <th style="text-align:right">Volume Hl</th>
          <th style="text-align:center">Seuil</th>
          <th style="text-align:center">Statut</th>
          <?php if ($editable): ?><th></th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($stocks as $s):
          $en_alerte = (int)$s['total_bouteilles'] <= 0;
          if ($filtre === 'alerte' && !$en_alerte) continue;
        ?>
        <tr style="background:<?= $en_alerte ? 'rgba(255,160,0,.05)' : '' ?>">
          <td>
            <div style="font-weight:500;color:var(--text)"><?= htmlspecialchars($s['description']) ?></div>
            <div style="font-size:.65rem;color:var(--text-mute)"><?= $s['code'] ?> · <?= $s['type_emballage'] ?> · Kit <?= $s['kit'] ?></div>
          </td>
          <td style="font-size:.75rem;color:var(--text-mute)"><?= htmlspecialchars($s['famille']) ?></td>
          <td style="text-align:center;font-weight:700;font-size:1rem;color:<?= $en_alerte ? '#ffa000' : 'var(--text)' ?>">
            <?= $s['quantite_casiers'] ?>
          </td>
          <td style="text-align:center"><?= $s['quantite_bouteilles'] ?: '—' ?></td>
          <td style="text-align:right;color:var(--red);font-weight:600">
            <?= number_format($s['volume_total_hl'],4) ?>
          </td>
          <td style="text-align:center;color:var(--text-mute)">0</td>
          <td style="text-align:center">
            <?= $en_alerte
              ? "<span class='badge badge-orange'>⚠️ Alerte</span>"
              : "<span class='badge badge-green'>OK</span>" ?>
          </td>
          <?php if ($editable): ?>
          <td>
            <button onclick="entreeRapide(<?= $s['produit_id'] ?>, '<?= addslashes($s['description']) ?>')"
              class="btn btn-secondary btn-sm">+</button>
          </td>
          <?php endif; ?>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal entrée stock -->
<?php if ($editable): ?>
<div id="modalEntree" style="display:none;position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.7);backdrop-filter:blur(4px);align-items:center;justify-content:center">
  <div class="modal-box" style="border:1px solid var(--border);border-radius:16px;
              padding:1.6rem;max-width:420px;width:90%">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.2rem">
      <div style="font-weight:700">Entrée de stock</div>
      <button onclick="document.getElementById('modalEntree').style.display='none'"
        style="background:none;border:none;color:var(--text-mute);cursor:pointer;font-size:1.2rem">✕</button>
    </div>
    <form method="POST" style="display:flex;flex-direction:column;gap:.9rem">
      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Produit *</label>
        <select name="produit_id" id="selectProduit" required
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.7rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
          <option value="">Sélectionner...</option>
          <?php foreach ($produits as $p): ?>
          <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['description']) ?> (<?= $p['code'] ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem">
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Casiers *</label>
          <input type="number" name="casiers" id="inputCasiers" value="0" min="0"
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.65rem .9rem;color:var(--text);font-size:.9rem;font-family:Inter,sans-serif;text-align:center">
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Bouteilles</label>
          <input type="number" name="bouteilles" value="0" min="0"
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.65rem .9rem;color:var(--text);font-size:.9rem;font-family:Inter,sans-serif;text-align:center">
        </div>
      </div>
      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Remarque</label>
        <input type="text" name="remarque" placeholder="Ex: livraison siège, référence BL..."
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.65rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
      </div>
      <div style="display:flex;gap:.6rem">
        <button type="button" onclick="document.getElementById('modalEntree').style.display='none'"
          class="btn btn-secondary" style="flex:1;justify-content:center">Annuler</button>
        <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center">
          ✅ Enregistrer l'entrée
        </button>
      </div>
    </form>
  </div>
</div>

<script>
function entreeRapide(produitId, nom) {
  document.getElementById('selectProduit').value = produitId;
  document.getElementById('inputCasiers').focus();
  document.getElementById('modalEntree').style.display = 'flex';
}
</script>
<?php endif; ?>

<?php close_layout(); ?>

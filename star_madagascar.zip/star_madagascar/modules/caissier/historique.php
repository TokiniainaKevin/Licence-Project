<?php
// ============================================================
// modules/caissier/historique.php
// Historique des paiements confirmés (journal de caisse)
// ============================================================
require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/paiement.php';

$ctx  = include_layout('Historique des encaissements', ['CAISSIER','ADMIN','DIRECTEUR']);
$db   = getDB();

$debut = $_GET['debut'] ?? date('Y-m-d');
$fin   = $_GET['fin']   ?? date('Y-m-d');
$mode  = $_GET['mode']  ?? '';

$sql = "SELECT c.code_commande, c.montant_a_payer, c.mode_paiement, c.reference_paiement, c.date_paiement,
               cl.nom client_nom, CONCAT(u.prenom,' ',u.nom) caissier_nom
        FROM commandes c
        JOIN clients cl ON cl.id=c.client_id
        LEFT JOIN utilisateurs u ON u.id=c.caissier_id
        WHERE c.statut_paiement='CONFIRME' AND DATE(COALESCE(c.date_paiement,c.updated_at,c.date_commande)) BETWEEN ? AND ?";
$params = [$debut, $fin];
if ($mode) { $sql .= " AND c.mode_paiement=?"; $params[] = $mode; }
$sql .= " ORDER BY c.date_paiement DESC LIMIT 500";
$st = $db->prepare($sql); $st->execute($params); $rows = $st->fetchAll();
$total = array_sum(array_column($rows, 'montant_a_payer'));
$labels = ['MOBILE_MONEY'=>'Mobile Money','VIREMENT'=>'Virement / bordereau','CASH'=>'Espèces'];
?>
<div class="page-header">
  <div class="page-title">Historique des encaissements</div>
  <div class="page-subtitle"><?= count($rows) ?> paiement(s) · <?= number_format($total) ?> Ar</div>
</div>
<div class="card" style="padding:.8rem 1rem;margin-bottom:1rem">
  <form method="GET" style="display:flex;gap:.6rem;flex-wrap:wrap;align-items:center">
    <input type="date" name="debut" value="<?= htmlspecialchars($debut) ?>" class="form-input">
    <input type="date" name="fin" value="<?= htmlspecialchars($fin) ?>" class="form-input">
    <select name="mode" class="form-input">
      <option value="">Tous modes</option>
      <?php foreach ($labels as $k => $l): ?><option value="<?= $k ?>" <?= $mode===$k?'selected':'' ?>><?= $l ?></option><?php endforeach; ?>
    </select>
    <button class="btn btn-primary btn-sm">Filtrer</button>
  </form>
</div>
<div class="card" style="padding:0;overflow:hidden">
  <table class="data-table">
    <thead><tr><th>Date</th><th>N° Commande</th><th>Client</th><th>Mode</th><th>Référence / bordereau</th><th>Caissier</th><th style="text-align:right">Montant</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td style="font-size:.72rem"><?= $r['date_paiement'] ? date('d/m/Y H:i', strtotime($r['date_paiement'])) : '—' ?></td>
        <td style="font-family:monospace;font-size:.72rem"><?= htmlspecialchars($r['code_commande']) ?></td>
        <td><?= htmlspecialchars($r['client_nom']) ?></td>
        <td><?= logo_paiement($r['mode_paiement'], $r['reference_paiement']) ?></td>
        <td style="font-size:.75rem"><?= htmlspecialchars($r['reference_paiement'] ?? '—') ?></td>
        <td style="font-size:.75rem"><?= htmlspecialchars($r['caissier_nom'] ?? '—') ?></td>
        <td style="text-align:right;font-weight:700"><?= number_format($r['montant_a_payer']) ?> Ar</td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="7" style="text-align:center;color:var(--text-mute);padding:2rem">Aucun paiement sur la période.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php close_layout(); ?>

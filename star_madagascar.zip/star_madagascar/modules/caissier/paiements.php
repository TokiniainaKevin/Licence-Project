<?php
// ============================================================
// modules/caissier/paiements.php
// Réception des bordereaux / références et confirmation des paiements
// ============================================================
require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/paiement.php';

$ctx  = include_layout('Paiements à encaisser', ['CAISSIER']);
$user = $ctx['user'];
$db   = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'confirmer_paiement') {
  $moyen = MOYENS_PAIEMENT[$_POST['moyen'] ?? ''] ?? null;
  $ref   = trim($_POST['reference'] ?? '');
  if ($moyen && $moyen['mode'] === 'MOBILE_MONEY' && $ref !== '') $ref = $moyen['label'] . ' ' . $ref;
  [$ok, $msg] = confirmer_paiement(
    $db,
    (int)($_POST['cmd_id'] ?? 0),
    $moyen['mode'] ?? '',
    $ref,
    (float)str_replace([' ', ','], ['', '.'], $_POST['montant_recu'] ?? '0'),
    (int)$user['id']
  );
  $_SESSION[$ok ? 'flash_ok' : 'flash_err'] = $msg;
  header('Location: paiements.php');
  exit;
}
$flash_ok  = $_SESSION['flash_ok']  ?? ''; unset($_SESSION['flash_ok']);
$flash_err = $_SESSION['flash_err'] ?? ''; unset($_SESSION['flash_err']);

$q = trim($_GET['q'] ?? '');
$sql = "
  SELECT c.*, cl.nom client_nom, cl.code_client, cl.type client_type, cl.telephone client_tel,
         CONCAT(u.prenom,' ',u.nom) commercial_nom
  FROM commandes c
  JOIN clients cl ON cl.id=c.client_id
  LEFT JOIN utilisateurs u ON u.id=c.commercial_id
  WHERE c.statut='EN_ATTENTE_PAIEMENT'";
$params = [];
if ($q !== '') { $sql .= " AND (c.code_commande LIKE ? OR cl.nom LIKE ? OR cl.code_client LIKE ?)"; $params = ["%$q%","%$q%","%$q%"]; }
$sql .= " ORDER BY c.date_commande ASC";
$st = $db->prepare($sql); $st->execute($params); $commandes = $st->fetchAll();
$total = array_sum(array_column($commandes, 'montant_a_payer'));
?>
<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Paiements à encaisser</div>
      <div class="page-subtitle"><?= count($commandes) ?> commande(s) · <?= number_format($total) ?> Ar en attente</div>
    </div>
    <a href="historique.php" class="btn btn-secondary">📂 Historique</a>
  </div>
</div>

<?php if ($flash_ok): ?><div class="alert alert-success">✅ <?= htmlspecialchars($flash_ok) ?></div><?php endif; ?>
<?php if ($flash_err): ?><div class="alert alert-error">❌ <?= htmlspecialchars($flash_err) ?></div><?php endif; ?>

<div class="card" style="padding:.8rem 1rem;margin-bottom:1rem">
  <form method="GET" style="display:flex;gap:.6rem">
    <input type="text" name="q" value="<?= htmlspecialchars($q) ?>" class="form-input" placeholder="🔍 N° commande, client ou code client..." style="flex:1">
    <button class="btn btn-primary btn-sm">Rechercher</button>
  </form>
</div>

<div class="card" style="padding:0;overflow:hidden">
  <?php if (!$commandes): ?>
    <div style="padding:2.5rem;text-align:center;color:var(--text-mute)">✅ Aucun paiement en attente.</div>
  <?php else: ?>
  <table class="data-table">
    <thead><tr><th>N° Commande</th><th>Client</th><th>Commercial</th>
      <th style="text-align:right">Produits</th><th style="text-align:right">Consigne</th>
      <th style="text-align:right">Crédit csg</th><th style="text-align:right">À payer</th><th>Date</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($commandes as $c): ?>
      <tr>
        <td style="font-family:monospace;font-size:.72rem"><?= htmlspecialchars($c['code_commande']) ?></td>
        <td><div style="font-weight:500"><?= htmlspecialchars($c['client_nom']) ?></div>
            <div style="font-size:.65rem;color:var(--text-mute)"><?= htmlspecialchars($c['code_client'] ?? '') ?> · <?= htmlspecialchars($c['client_tel'] ?? '') ?></div></td>
        <td style="font-size:.75rem"><?= htmlspecialchars($c['commercial_nom'] ?? 'Commande distributeur') ?></td>
        <td style="text-align:right;font-size:.75rem"><?= number_format($c['montant_ht']) ?></td>
        <td style="text-align:right;font-size:.75rem"><?= number_format($c['montant_consigne']) ?></td>
        <td style="text-align:right;font-size:.75rem"><?= $c['credit_consigne_utilise'] > 0 ? '−'.number_format($c['credit_consigne_utilise']) : '—' ?></td>
        <td style="text-align:right;font-weight:700;color:var(--red)"><?= number_format($c['montant_a_payer']) ?> Ar</td>
        <td style="font-size:.7rem;color:var(--text-mute)"><?= date('d/m H:i', strtotime($c['date_commande'])) ?></td>
        <td><button class="btn btn-primary btn-sm"
              onclick='ouvrirPaiement(<?= json_encode(["id"=>(int)$c["id"],"code"=>$c["code_commande"],"client"=>$c["client_nom"],"montant"=>(float)$c["montant_a_payer"]], JSON_HEX_APOS|JSON_HEX_QUOT) ?>)'>💳 Encaisser</button></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>

<style>
.pay-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:.4rem}
.pay-opt input{position:absolute;opacity:0;pointer-events:none}
.pay-box{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.3rem;height:74px;padding:.35rem;
  border:1px solid var(--border);border-radius:10px;cursor:pointer;background:var(--bg3);text-align:center}
.pay-box img{height:28px;max-width:100%;object-fit:contain;background:#fff;border-radius:4px;padding:2px}
.pay-box .i-svg{width:26px;height:26px}
.pay-box small{font-size:.6rem;line-height:1.1;color:var(--text-dim)}
.pay-opt input:checked + .pay-box{border-color:var(--red);box-shadow:0 0 0 2px rgba(232,0,28,.35);background:rgba(232,0,28,.08)}
</style>
<div id="modalPaiement" style="display:none;position:fixed;inset:0;z-index:200;background:rgba(0,0,0,.7);align-items:center;justify-content:center">
  <div class="modal-box" style="border:1px solid var(--border);border-radius:16px;padding:1.6rem;max-width:440px;width:92%">
    <div style="font-weight:700;margin-bottom:.4rem">Confirmer le paiement</div>
    <div style="font-size:.82rem;color:var(--text-mute);margin-bottom:1rem" id="paiInfo"></div>
    <form method="POST" style="display:flex;flex-direction:column;gap:.8rem" onsubmit="return verifierMontant()">
      <input type="hidden" name="action" value="confirmer_paiement">
      <input type="hidden" name="cmd_id" id="paiId">
      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Moyen de paiement</label>
        <div class="pay-grid">
          <?php $first = true; foreach (MOYENS_PAIEMENT as $k => $m): ?>
          <label class="pay-opt">
            <input type="radio" name="moyen" value="<?= $k ?>" <?= $first ? 'checked' : '' ?> onchange="majRef()">
            <span class="pay-box">
              <?php if ($m['logo']): ?><img src="../../assets/images/logos/<?= $m['logo'] ?>" alt="<?= $m['label'] ?>"><?php else: ?><?= icone($m['icone']) ?><?php endif; ?>
              <small><?= $m['label'] ?></small>
            </span>
          </label>
          <?php $first = false; endforeach; ?>
        </div>
      </div>
      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem" id="paiRefLabel">N° de transaction / N° de bordereau *</label>
        <input type="text" name="reference" id="paiRef" class="form-input" style="width:100%" placeholder="N° de transaction Mobile Money ou N° de bordereau">
      </div>
      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Montant reçu (Ar) *</label>
        <input type="number" name="montant_recu" id="paiMontant" class="form-input" style="width:100%" min="0" step="1" required>
        <div id="paiEcart" style="font-size:.7rem;color:#ffa000;margin-top:.3rem;display:none"></div>
      </div>
      <div style="display:flex;gap:.6rem">
        <button type="button" class="btn btn-secondary" style="flex:1;justify-content:center" onclick="document.getElementById('modalPaiement').style.display='none'">Annuler</button>
        <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center">✅ Confirmer</button>
      </div>
    </form>
  </div>
</div>

<script>
let montantAttendu = 0;
function ouvrirPaiement(c) {
  montantAttendu = Math.round(c.montant);
  document.getElementById('paiId').value = c.id;
  document.getElementById('paiInfo').textContent = c.code + ' — ' + c.client + ' — à payer : ' + montantAttendu.toLocaleString('fr-FR') + ' Ar';
  document.getElementById('paiMontant').value = '';
  document.getElementById('paiRef').value = '';
  document.getElementById('paiEcart').style.display = 'none';
  majRef();
  document.getElementById('modalPaiement').style.display = 'flex';
}
function majRef() {
  const cash = (document.querySelector('input[name=moyen]:checked') || {}).value === 'CASH';
  document.getElementById('paiRef').required = !cash;
  document.getElementById('paiRefLabel').textContent = cash ? 'Référence (facultatif pour les espèces)' : 'N° de transaction / N° de bordereau *';
}
function verifierMontant() {
  const m = Math.round(parseFloat(document.getElementById('paiMontant').value) || 0);
  if (m !== montantAttendu) {
    const e = document.getElementById('paiEcart');
    e.textContent = 'Écart de ' + (m - montantAttendu).toLocaleString('fr-FR') + ' Ar : le montant reçu doit être exactement ' + montantAttendu.toLocaleString('fr-FR') + ' Ar.';
    e.style.display = 'block';
    return false;
  }
  return true;
}
document.getElementById('modalPaiement').addEventListener('click', function(e){ if (e.target === this) this.style.display = 'none'; });
</script>
<?php close_layout(); ?>

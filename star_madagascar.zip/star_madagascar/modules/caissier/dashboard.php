<?php
// ============================================================
// modules/caissier/dashboard.php
// Tableau de bord Caisse : paiements à encaisser + encaissements du jour
// ============================================================
require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Caisse', ['CAISSIER']);
$user = $ctx['user'];
$db   = getDB();

$k = $db->query("
  SELECT
    (SELECT COUNT(*) FROM commandes WHERE statut='EN_ATTENTE_PAIEMENT') AS nb_attente,
    (SELECT COALESCE(SUM(montant_a_payer),0) FROM commandes WHERE statut='EN_ATTENTE_PAIEMENT') AS mt_attente,
    (SELECT COUNT(*) FROM commandes WHERE statut_paiement='CONFIRME' AND DATE(date_paiement)=CURDATE()) AS nb_jour,
    (SELECT COALESCE(SUM(montant_a_payer),0) FROM commandes WHERE statut_paiement='CONFIRME' AND DATE(date_paiement)=CURDATE()) AS mt_jour
")->fetch();

$par_mode = $db->query("
  SELECT mode_paiement, COUNT(*) nb, COALESCE(SUM(montant_a_payer),0) mt
  FROM commandes WHERE statut_paiement='CONFIRME' AND DATE(date_paiement)=CURDATE()
  GROUP BY mode_paiement
")->fetchAll();

$attente = $db->query("
  SELECT c.id, c.code_commande, c.montant_a_payer, c.date_commande, cl.nom client_nom, cl.code_client
  FROM commandes c JOIN clients cl ON cl.id=c.client_id
  WHERE c.statut='EN_ATTENTE_PAIEMENT' ORDER BY c.date_commande ASC LIMIT 8
")->fetchAll();
$labels = ['MOBILE_MONEY'=>'Mobile Money','VIREMENT'=>'Virement / bordereau','CASH'=>'Espèces'];
?>
<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Tableau de bord Caisse</div>
      <div class="page-subtitle"><?= date('d/m/Y') ?> — Réception des bordereaux et confirmation des paiements</div>
    </div>
    <a href="paiements.php" class="btn btn-primary">💳 Encaisser</a>
  </div>
</div>

<div class="grid-4" style="margin-bottom:1.2rem">
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Paiements à encaisser</div>
    <div class="kpi-value" style="color:<?= $k['nb_attente'] ? 'var(--red)' : 'var(--text)' ?>"><?= $k['nb_attente'] ?> <span class="unit">cmd</span></div>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Montant en attente</div>
    <div class="kpi-value"><?= number_format($k['mt_attente']) ?> <span class="unit">Ar</span></div>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Encaissés aujourd'hui</div>
    <div class="kpi-value"><?= $k['nb_jour'] ?> <span class="unit">paiements</span></div>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Total encaissé aujourd'hui</div>
    <div class="kpi-value" style="color:#00c864"><?= number_format($k['mt_jour']) ?> <span class="unit">Ar</span></div>
  </div>
</div>

<div class="grid-2">
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.85rem;font-weight:600">⏳ Les plus anciens en attente</div>
      <a href="paiements.php" class="btn btn-secondary btn-sm">Tout voir</a>
    </div>
    <?php if (!$attente): ?>
      <div style="padding:2rem;text-align:center;color:var(--text-mute);font-size:.82rem">✅ Aucun paiement en attente.</div>
    <?php else: ?>
    <table class="data-table"><thead><tr><th>N°</th><th>Client</th><th style="text-align:right">À payer</th><th>Depuis</th></tr></thead><tbody>
      <?php foreach ($attente as $c): ?>
      <tr>
        <td style="font-family:monospace;font-size:.72rem"><?= htmlspecialchars($c['code_commande']) ?></td>
        <td><?= htmlspecialchars($c['client_nom']) ?></td>
        <td style="text-align:right;font-weight:700;color:var(--red)"><?= number_format($c['montant_a_payer']) ?> Ar</td>
        <td style="font-size:.7rem;color:var(--text-mute)"><?= date('d/m H:i', strtotime($c['date_commande'])) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody></table>
    <?php endif; ?>
  </div>

  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:.85rem;font-weight:600">💰 Encaissements du jour par mode</div>
    <?php if (!$par_mode): ?>
      <div style="padding:2rem;text-align:center;color:var(--text-mute);font-size:.82rem">Aucun encaissement aujourd'hui.</div>
    <?php else: ?>
    <table class="data-table"><thead><tr><th>Mode</th><th style="text-align:center">Nb</th><th style="text-align:right">Montant</th></tr></thead><tbody>
      <?php foreach ($par_mode as $m): ?>
      <tr><td><?= $labels[$m['mode_paiement']] ?? '—' ?></td><td style="text-align:center"><?= $m['nb'] ?></td>
          <td style="text-align:right;font-weight:700"><?= number_format($m['mt']) ?> Ar</td></tr>
      <?php endforeach; ?>
    </tbody></table>
    <?php endif; ?>
  </div>
</div>
<?php ?>
<!-- ── Graphiques ─────────────────────────────────────────── -->
<?php
$j14 = jours_periode(14);
$enc = serie($j14, $db->query("SELECT DATE(date_paiement) d, SUM(montant_a_payer) v FROM commandes WHERE statut_paiement='CONFIRME' AND date_paiement >= DATE_SUB(CURDATE(), INTERVAL 14 DAY) GROUP BY DATE(date_paiement)")->fetchAll());
$modes = $db->query("SELECT CASE WHEN mode_paiement='MOBILE_MONEY' AND reference_paiement LIKE 'Orange%' THEN 'Orange Money'
    WHEN mode_paiement='MOBILE_MONEY' AND reference_paiement LIKE 'Airtel%' THEN 'Airtel Money'
    WHEN mode_paiement='MOBILE_MONEY' THEN 'MVola' WHEN mode_paiement='VIREMENT' THEN 'Virement / bordereau' ELSE 'Espèces' END l,
    SUM(montant_a_payer) v FROM commandes WHERE statut_paiement='CONFIRME' AND date_paiement >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY l ORDER BY v DESC")->fetchAll();
$coul = ['MVola'=>'#F7D117','Orange Money'=>'#FF7900','Airtel Money'=>'#E40000','Virement / bordereau'=>'#5591C7','Espèces'=>'#1f9d55'];
?>
<div class="grid-2" style="margin-top:1rem">
<?= graphique('gEnc', 'Encaissements par jour (14 derniers jours)', ['type'=>'bar','unite'=>'Ar','data'=>['labels'=>etiquettes_jours($j14),'datasets'=>[
  ['label'=>'Montant encaissé','data'=>array_values($enc),'backgroundColor'=>'rgba(31,157,85,.8)','borderRadius'=>4]]],
  'options'=>['plugins'=>['legend'=>['display'=>false]],'scales'=>['y'=>['beginAtZero'=>true]]]], 280) ?>
<?= graphique('gModes', 'Encaissements par moyen de paiement (30 jours)', ['type'=>'bar','unite'=>'Ar','data'=>['labels'=>array_column($modes,'l'),'datasets'=>[
  ['label'=>'Montant','data'=>array_map('floatval',array_column($modes,'v')),'backgroundColor'=>array_map(fn($l)=>$coul[$l]??'#999',array_column($modes,'l')),'borderRadius'=>4]]],
  'options'=>['indexAxis'=>'y','plugins'=>['legend'=>['display'=>false]]]], 280) ?>
</div>

<?php close_layout(); ?>

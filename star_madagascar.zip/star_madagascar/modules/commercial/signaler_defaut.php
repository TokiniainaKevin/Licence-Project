<?php
// ============================================================
// modules/commercial/signaler_defaut.php
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Signaler un défaut', ['COMMERCIAL','MANAGER','MANAGER_INTERIM']);
$user = $ctx['user'];
$db   = getDB();

$client_id = (int)($_GET['client_id'] ?? 0);

// Commandes récentes du commercial (7 derniers jours)
$stmt = $db->prepare("
  SELECT c.id, c.code_commande, c.date_commande, cl.nom AS client_nom
  FROM commandes c
  JOIN clients cl ON c.client_id = cl.id
  WHERE c.commercial_id = ?
    AND c.date_commande >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    -- un défaut ne concerne qu'une commande déjà livrée au client
    AND c.statut IN ('LIVREE','TERMINEE','DEFAUT_SIGNALE')
  ORDER BY c.date_commande DESC
  LIMIT 20
");
$stmt->execute([$user['id']]);
$commandes = $stmt->fetchAll();

// Produits
$produits = $db->query("
  SELECT id, description, code FROM produits WHERE actif=1 ORDER BY description ASC
")->fetchAll();

// Traitement POST
$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $commande_id = (int)($_POST['commande_id'] ?? 0);
  $produit_id  = (int)($_POST['produit_id'] ?? 0);
  $description = trim($_POST['description'] ?? '');
  $quantite    = max(1, (int)($_POST['quantite'] ?? 1));

  // La commande doit appartenir au commercial, être livrée, et contenir ce produit
  $chk = $db->prepare("SELECT COUNT(*) FROM commandes c JOIN lignes_commande lc ON lc.commande_id=c.id
                       WHERE c.id=? AND c.commercial_id=? AND lc.produit_id=? AND c.statut IN ('LIVREE','TERMINEE','DEFAUT_SIGNALE')");
  $chk->execute([$commande_id, $user['id'], $produit_id]);
  if ($commande_id && $produit_id && !$chk->fetchColumn()) {
    $error = "Ce produit ne fait pas partie de cette commande livrée.";
  } elseif ($commande_id && $produit_id && $description) {
    // Trouver le manager du même secteur
    $stmt = $db->prepare("
      SELECT u.id FROM utilisateurs u
      JOIN utilisateurs com ON com.secteur_id = u.secteur_id
      WHERE com.id = ? AND u.role IN ('MANAGER','MANAGER_INTERIM')
      LIMIT 1
    ");
    $stmt->execute([$user['id']]);
    $manager = $stmt->fetch();
    $manager_id = $manager ? $manager['id'] : null;

    try {
      $db->beginTransaction();

      $stmt = $db->prepare("
        INSERT INTO defauts_produits
          (commande_id, produit_id, commercial_id, manager_id, description, quantite)
        VALUES (?,?,?,?,?,?)
      ");
      $stmt->execute([$commande_id, $produit_id, $user['id'], $manager_id, $description, $quantite]);
      $defaut_id = $db->lastInsertId();

      // Mettre à jour statut commande
      $stmt = $db->prepare("UPDATE commandes SET statut='DEFAUT_SIGNALE' WHERE id=? AND statut IN ('LIVREE','TERMINEE')");
      $stmt->execute([$commande_id]);

      // Notifier manager
      if ($manager_id) {
        $stmt = $db->prepare("
          INSERT INTO notifications (utilisateur_id, titre, message, type, reference_id)
          VALUES (?,?,?,'DEFAUT_PRODUIT',?)
        ");
        $stmt->execute([
          $manager_id,
          'Défaut produit signalé',
          "Défaut signalé par {$user['nom']} — $quantite bouteille(s) — $description",
          $defaut_id
        ]);
      }

      $db->commit();
      $success = 'Défaut signalé avec succès. Votre manager a été notifié.';
    } catch (Exception $e) {
      $db->rollBack();
      $error = 'Erreur lors de l\'enregistrement.';
    }
  } else {
    $error = 'Veuillez remplir tous les champs obligatoires.';
  }
}
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Signaler un défaut produit</div>
      <div class="page-subtitle">Le signalement sera transmis à votre manager pour validation</div>
    </div>
    <a href="dashboard.php" class="btn btn-secondary">← Retour</a>
  </div>
</div>

<?php if ($success): ?>
<div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div style="max-width:600px">
  <div class="card">
    <form method="POST">
      <div style="display:flex;flex-direction:column;gap:1rem">

        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem;font-weight:500">
            Commande concernée *
          </label>
          <select name="commande_id" required
            style="width:100%;background:var(--bg3);border:1px solid var(--border);
                   border-radius:8px;padding:.7rem .9rem;color:var(--text);
                   font-size:.85rem;font-family:Inter,sans-serif">
            <option value="">Sélectionner une commande...</option>
            <?php foreach ($commandes as $c): ?>
            <option value="<?= $c['id'] ?>">
              <?= htmlspecialchars($c['code_commande']) ?> —
              <?= htmlspecialchars($c['client_nom']) ?> —
              <?= date('d/m/Y', strtotime($c['date_commande'])) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem;font-weight:500">
            Produit défectueux *
          </label>
          <select name="produit_id" required
            style="width:100%;background:var(--bg3);border:1px solid var(--border);
                   border-radius:8px;padding:.7rem .9rem;color:var(--text);
                   font-size:.85rem;font-family:Inter,sans-serif">
            <option value="">Sélectionner un produit...</option>
            <?php foreach ($produits as $p): ?>
            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['description']) ?> (<?= $p['code'] ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem;font-weight:500">
            Quantité concernée (en bouteilles) *
          </label>
          <input type="number" name="quantite" value="1" min="1"
            style="width:120px;background:var(--bg3);border:1px solid var(--border);
                   border-radius:8px;padding:.65rem .9rem;color:var(--text);
                   font-size:.85rem;font-family:Inter,sans-serif"
            onfocus="this.style.borderColor='var(--red)'"
            onblur="this.style.borderColor='var(--border)'">
        </div>

        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem;font-weight:500">
            Description du défaut *
          </label>
          <textarea name="description" rows="4" required
            placeholder="Ex: bouteille mal fermée, étiquette décollée, produit manquant dans le casier scellé..."
            style="width:100%;background:var(--bg3);border:1px solid var(--border);
                   border-radius:8px;padding:.7rem .9rem;color:var(--text);
                   font-size:.85rem;font-family:Inter,sans-serif;resize:vertical;line-height:1.5"
            onfocus="this.style.borderColor='var(--red)'"
            onblur="this.style.borderColor='var(--border)'"></textarea>
        </div>

        <div style="background:rgba(255,160,0,.06);border:1px solid rgba(255,160,0,.2);
                    border-radius:8px;padding:.8rem;font-size:.75rem;color:#ffa000">
          ℹ️ Votre manager devra valider ce signalement avant que le remplacement soit effectué par la logistique.
        </div>

        <div style="display:flex;gap:.6rem">
          <a href="dashboard.php" class="btn btn-secondary" style="flex:1;justify-content:center">Annuler</a>
          <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center">
            ⚠️ Envoyer le signalement
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<?php close_layout(); ?>

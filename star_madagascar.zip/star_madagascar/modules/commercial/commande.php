<?php
// ============================================================
// modules/commercial/commande.php
// Prise de commande — Étape 1 : Sélection client
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Nouvelle commande', ['COMMERCIAL','MANAGER','MANAGER_INTERIM']);
$user = $ctx['user'];
$db   = getDB();

// Vérifier heure limite
$heure = date('H:i');
if ($heure >= '20:00') {
  echo '<div class="alert alert-error">
    ⏰ Heure limite dépassée (20h00). Vous ne pouvez plus prendre de commandes aujourd\'hui.
  </div>';
  close_layout();
  exit;
}

// Récupérer clients du secteur du commercial
$stmt = $db->prepare("
  SELECT c.id, c.code_client, c.nom, c.type, c.adresse, c.quartier,
         c.type_paiement,
         -- Stock de la dernière visite (JSON, sommé côté PHP)
         (SELECT vc.stock_releve
          FROM visites vc
          WHERE vc.client_id = c.id AND vc.statut = 'VISITE' AND vc.stock_releve IS NOT NULL
          ORDER BY vc.date_visite DESC LIMIT 1) AS dernier_stock_json,
         -- Dernière visite
         (SELECT DATE(vc2.date_visite)
          FROM visites vc2
          WHERE vc2.client_id = c.id AND vc2.commercial_id = ? AND vc2.statut = 'VISITE'
          ORDER BY vc2.date_visite DESC LIMIT 1) AS derniere_visite
  FROM clients c
  JOIN visites pv ON pv.client_id = c.id
  WHERE pv.commercial_id = ?
    AND DATE(pv.date_visite) = CURDATE()
    AND c.statut = 'ACTIF'
  ORDER BY c.nom ASC
");
$stmt->execute([$user['id'], $user['id']]);
$clients_planning = $stmt->fetchAll();
foreach ($clients_planning as &$cp) {
  $stock = $cp['dernier_stock_json'] ? json_decode($cp['dernier_stock_json'], true) : [];
  $cp['dernier_stock_casiers'] = array_sum(array_column($stock, 'casiers'));
}
unset($cp);

// Tous les clients actifs du commercial (hors planning du jour aussi)
$stmt = $db->prepare("
  SELECT c.id, c.code_client, c.nom, c.type, c.quartier, c.type_paiement
  FROM clients c
  JOIN utilisateurs u ON u.secteur_id = c.secteur_id
  WHERE u.id = ?
    AND c.statut = 'ACTIF'
  ORDER BY c.nom ASC
");
$stmt->execute([$user['id']]);
$tous_clients = $stmt->fetchAll();
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Nouvelle commande</div>
      <div class="page-subtitle">Sélectionnez un client pour commencer</div>
    </div>
    <div style="display:flex;gap:.6rem;align-items:center">
      <div style="font-size:.75rem;color:var(--text-mute)">⏰ Limite : 20h00</div>
      <a href="dashboard.php" class="btn btn-secondary">← Retour</a>
    </div>
  </div>
</div>

<!-- Étapes -->
<div style="display:flex;align-items:center;gap:0;margin-bottom:1.6rem">
  <?php
  $steps = ['Sélection client', 'Saisie commande', 'Vérification', 'Confirmation'];
  foreach ($steps as $i => $s):
    $active = $i === 0;
    $done   = false;
  ?>
  <div style="display:flex;align-items:center;flex:1">
    <div style="display:flex;align-items:center;gap:.5rem;flex:1">
      <div style="
        width:28px;height:28px;border-radius:50%;
        background:<?= $active ? 'var(--red)' : ($done ? 'rgba(0,200,100,.2)' : 'var(--bg3)') ?>;
        border:1px solid <?= $active ? 'var(--red)' : ($done ? '#00c864' : 'var(--border)') ?>;
        display:flex;align-items:center;justify-content:center;
        font-size:.7rem;font-weight:700;flex-shrink:0;
        color:<?= $active ? '#fff' : ($done ? '#00c864' : 'var(--text-mute)') ?>
      "><?= $done ? '✓' : ($i+1) ?></div>
      <span style="font-size:.75rem;font-weight:<?= $active ? '600' : '400' ?>;color:<?= $active ? 'var(--text)' : 'var(--text-mute)' ?>"><?= $s ?></span>
    </div>
    <?php if ($i < count($steps)-1): ?>
      <div style="height:1px;flex:1;background:var(--border);margin:0 .5rem"></div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<!-- Recherche client -->
<div class="card" style="margin-bottom:1rem;padding:1rem 1.2rem">
  <div style="display:flex;gap:.8rem;align-items:center">
    <div style="flex:1;position:relative">
      <input type="text" id="searchClient"
        placeholder="🔍  Rechercher par nom, code client ou quartier..."
        style="width:100%;background:var(--bg3);border:1px solid var(--border);
               border-radius:8px;padding:.7rem 1rem;color:var(--text);
               font-size:.85rem;font-family:Inter,sans-serif;outline:none"
        oninput="filterClients(this.value)"
        onfocus="this.style.borderColor='var(--red)'"
        onblur="this.style.borderColor='var(--border)'">
    </div>
    <button onclick="toggleAll()" class="btn btn-secondary btn-sm" id="toggleBtn">
      Voir tous les clients
    </button>
  </div>
</div>

<!-- Clients du planning -->
<div id="planningSection">
  <div style="font-size:.72rem;color:var(--text-mute);margin-bottom:.6rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase">
    📅 Planning du jour (<?= count($clients_planning) ?> clients)
  </div>
  <div id="clientsPlanning" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:.7rem;margin-bottom:1.4rem">
    <?php foreach ($clients_planning as $c): ?>
    <div class="client-card" data-search="<?= strtolower($c['nom'].' '.$c['code_client'].' '.$c['quartier']) ?>"
      onclick="selectClient(<?= $c['id'] ?>, '<?= addslashes($c['nom']) ?>', '<?= $c['code_client'] ?>', '<?= $c['type'] ?>', '<?= $c['type_paiement'] ?>')"
      style="background:var(--bg2);border:1px solid var(--border);border-radius:10px;
             padding:.9rem 1rem;cursor:pointer;transition:all .15s;position:relative">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.5rem">
        <div>
          <div style="font-weight:600;font-size:.85rem;color:var(--text)"><?= htmlspecialchars($c['nom']) ?></div>
          <div style="font-size:.68rem;color:var(--text-mute);margin-top:.1rem"><?= htmlspecialchars($c['code_client']) ?> · <?= htmlspecialchars($c['quartier'] ?? '') ?></div>
        </div>
        <?= client_type_badge($c['type']) ?>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div style="font-size:.7rem;color:var(--text-mute)">
          <?php if ($c['derniere_visite']): ?>
            Dernière visite : <?= date('d/m/Y', strtotime($c['derniere_visite'])) ?>
          <?php else: ?>
            Jamais visité
          <?php endif; ?>
        </div>
        <div style="font-size:.7rem;color:<?= $c['type_paiement'] === 'AGENCE' ? '#4d94ff' : '#00c864' ?>">
          <?= $c['type_paiement'] === 'AGENCE' ? '🏦 Agence' : '💵 Distributeur' ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($clients_planning)): ?>
    <div style="grid-column:1/-1;padding:2rem;text-align:center;color:var(--text-mute);font-size:.82rem;background:var(--bg2);border:1px dashed var(--border);border-radius:10px">
      Aucun client planifié pour aujourd'hui.<br>
      <span style="color:var(--red);cursor:pointer" onclick="toggleAll()">Voir tous les clients →</span>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Tous les clients (masqué par défaut) -->
<div id="allSection" style="display:none">
  <div style="font-size:.72rem;color:var(--text-mute);margin-bottom:.6rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase">
    👥 Tous mes clients (<?= count($tous_clients) ?>)
  </div>
  <div id="clientsAll" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:.7rem">
    <?php foreach ($tous_clients as $c): ?>
    <div class="client-card" data-search="<?= strtolower($c['nom'].' '.$c['code_client'].' '.$c['quartier']) ?>"
      onclick="selectClient(<?= $c['id'] ?>, '<?= addslashes($c['nom']) ?>', '<?= $c['code_client'] ?>', '<?= $c['type'] ?>', '<?= $c['type_paiement'] ?>')"
      style="background:var(--bg2);border:1px solid var(--border);border-radius:10px;
             padding:.9rem 1rem;cursor:pointer;transition:all .15s">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <div style="font-weight:600;font-size:.85rem;color:var(--text)"><?= htmlspecialchars($c['nom']) ?></div>
          <div style="font-size:.68rem;color:var(--text-mute);margin-top:.1rem"><?= htmlspecialchars($c['code_client']) ?> · <?= htmlspecialchars($c['quartier'] ?? '') ?></div>
        </div>
        <?= client_type_badge($c['type']) ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Nouveau client -->
<div style="margin-top:1.4rem;padding:1rem 1.2rem;background:var(--bg2);border:1px dashed var(--border);border-radius:10px;display:flex;justify-content:space-between;align-items:center">
  <div>
    <div style="font-size:.82rem;font-weight:500;color:var(--text)">Client sans code ?</div>
    <div style="font-size:.72rem;color:var(--text-mute)">Demandez l'attribution d'un code client à votre manager.</div>
  </div>
  <a href="demande_code.php" class="btn btn-secondary btn-sm">🆔 Demander un code</a>
</div>

<!-- Modal confirmation client sélectionné -->
<div id="modalClient" style="display:none;position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.7);backdrop-filter:blur(4px);
  align-items:center;justify-content:center">
  <div class="modal-box" style="border:1px solid var(--border);border-radius:16px;
              padding:1.6rem;max-width:400px;width:90%;position:relative">
    <div style="font-size:.75rem;color:var(--red);font-weight:600;margin-bottom:.4rem">CLIENT SÉLECTIONNÉ</div>
    <div style="font-family:'Space Grotesk',sans-serif;font-size:1.3rem;font-weight:700;margin-bottom:.3rem" id="modalNom"></div>
    <div style="font-size:.78rem;color:var(--text-mute);margin-bottom:1.2rem" id="modalInfo"></div>
    <div style="display:flex;gap:.7rem">
      <button onclick="closeModal()" class="btn btn-secondary" style="flex:1">← Annuler</button>
      <button onclick="goToCommande()" class="btn btn-primary" style="flex:1">Continuer →</button>
    </div>
  </div>
</div>

<script>
let selectedClient = null;
let showAll = false;

function selectClient(id, nom, code, type, paiement) {
  selectedClient = {id, nom, code, type, paiement};

  // Highlight
  document.querySelectorAll('.client-card').forEach(c => {
    c.style.borderColor = 'var(--border)';
    c.style.background = 'var(--bg2)';
  });
  event.currentTarget.style.borderColor = 'var(--red)';
  event.currentTarget.style.background = 'rgba(232,0,28,.06)';

  // Modal
  document.getElementById('modalNom').textContent = nom;
  document.getElementById('modalInfo').textContent =
    code + ' · ' + typeLabel(type) + ' · ' +
    (paiement === 'AGENCE' ? 'Paiement à l\'agence' : 'Paiement au distributeur');
  document.getElementById('modalClient').style.display = 'flex';
}

function closeModal() {
  document.getElementById('modalClient').style.display = 'none';
  selectedClient = null;
  document.querySelectorAll('.client-card').forEach(c => {
    c.style.borderColor = 'var(--border)';
    c.style.background = 'var(--bg2)';
  });
}

function goToCommande() {
  if (!selectedClient) return;
  const params = new URLSearchParams({
    client_id:      selectedClient.id,
    client_nom:     selectedClient.nom,
    client_code:    selectedClient.code,
    client_type:    selectedClient.type,
    client_paiement:selectedClient.paiement,
  });
  window.location.href = 'commande_produits.php?' + params.toString();
}

function typeLabel(t) {
  const map = {
    DISTRIBUTEUR:'Distributeur',GMS:'GMS',STATION:'Station',
    DEMI_GROS:'Demi-gros',EPICERIE:'Épicerie',BAR:'Bar',RESTAURANT:'Restaurant'
  };
  return map[t] || t;
}

function filterClients(q) {
  q = q.toLowerCase().trim();
  document.querySelectorAll('.client-card').forEach(c => {
    const match = !q || c.dataset.search.includes(q);
    c.style.display = match ? '' : 'none';
  });
  // Si on cherche, montrer tous
  if (q) {
    document.getElementById('planningSection').style.display = '';
    document.getElementById('allSection').style.display = '';
  }
}

function toggleAll() {
  showAll = !showAll;
  document.getElementById('allSection').style.display = showAll ? '' : 'none';
  document.getElementById('toggleBtn').textContent = showAll ? 'Voir planning seulement' : 'Voir tous les clients';
}

// Fermer modal en cliquant dehors
document.getElementById('modalClient').addEventListener('click', function(e) {
  if (e.target === this) closeModal();
});
</script>

<?php
function client_type_badge(string $type): string {
  $map = [
    'DISTRIBUTEUR' => ['badge-blue',   'Dist.'],
    'GMS'          => ['badge-orange', 'GMS'],
    'STATION'      => ['badge-orange', 'Station'],
    'DEMI_GROS'    => ['badge-blue',   'D-Gros'],
    'EPICERIE'     => ['badge-mute',   'Épicerie'],
    'BAR'          => ['badge-mute',   'Bar'],
    'RESTAURANT'   => ['badge-mute',   'Resto'],
  ];
  [$cls, $label] = $map[$type] ?? ['badge-mute', $type];
  return "<span class='badge $cls'>$label</span>";
}

close_layout();
?>

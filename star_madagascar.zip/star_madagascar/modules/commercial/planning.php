<?php
// ============================================================
// modules/commercial/planning.php
// Planning mensuel des visites
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Mon planning', ['COMMERCIAL','MANAGER','MANAGER_INTERIM']);
$user = $ctx['user'];
$db   = getDB();

$mois  = (int)($_GET['mois'] ?? date('m'));
$annee = (int)($_GET['annee'] ?? date('Y'));

// Navigation mois
$mois_prev = $mois === 1 ? 12 : $mois - 1;
$annee_prev = $mois === 1 ? $annee - 1 : $annee;
$mois_next = $mois === 12 ? 1 : $mois + 1;
$annee_next = $mois === 12 ? $annee + 1 : $annee;

$noms_mois = ['','Janvier','Février','Mars','Avril','Mai','Juin',
              'Juillet','Août','Septembre','Octobre','Novembre','Décembre'];
$noms_jours = ['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'];

// Récupérer visites du mois (planifiées, réalisées ou annulées)
$stmt = $db->prepare("
  SELECT pv.*, c.nom AS client_nom, c.code_client, c.type AS client_type, c.quartier
  FROM visites pv
  JOIN clients c ON pv.client_id = c.id
  WHERE pv.commercial_id = ?
    AND MONTH(pv.date_visite) = ?
    AND YEAR(pv.date_visite) = ?
  ORDER BY pv.date_visite ASC
");
$stmt->execute([$user['id'], $mois, $annee]);
$visites = $stmt->fetchAll();

// Grouper par date
$par_date = [];
foreach ($visites as $v) {
  $par_date[substr($v['date_visite'], 0, 10)][] = $v;
}

// Récupérer clients disponibles pour ajout
$stmt = $db->prepare("
  SELECT c.id, c.nom, c.code_client, c.type, c.quartier
  FROM clients c
  JOIN utilisateurs u ON u.secteur_id = c.secteur_id
  WHERE u.id = ? AND c.statut = 'ACTIF'
  ORDER BY c.nom ASC
");
$stmt->execute([$user['id']]);
$mes_clients = $stmt->fetchAll();

// Stats du mois
$total_visites  = count($visites);
$visites_faites = count(array_filter($visites, fn($v) => $v['statut'] === 'VISITE'));
$clients_uniques = count(array_unique(array_column($visites, 'client_id')));

// Construire calendrier
$premier_jour = mktime(0,0,0,$mois,1,$annee);
$nb_jours     = (int)date('t', $premier_jour);
$debut_semaine= (int)date('w', $premier_jour); // 0=dim
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Mon planning</div>
      <div class="page-subtitle">Gérez vos visites clients mois par mois</div>
    </div>
    <button onclick="document.getElementById('modalAjout').style.display='flex'"
      class="btn btn-primary">+ Ajouter une visite</button>
  </div>
</div>

<!-- Stats rapides -->
<div class="grid-3" style="margin-bottom:1.2rem">
  <div class="card kpi-card card-top-line">
    <div class="kpi-label">Visites planifiées</div>
    <div class="kpi-value"><?= $total_visites ?> <span class="unit">ce mois</span></div>
    <div class="kpi-trend neutral"><?= $clients_uniques ?> clients différents</div>
  </div>
  <div class="card kpi-card card-top-line">
    <div class="kpi-label">Visites effectuées</div>
    <div class="kpi-value"><?= $visites_faites ?> <span class="unit">/ <?= $total_visites ?></span></div>
    <div class="progress-bar"><div class="progress-fill" style="width:<?= $total_visites > 0 ? round($visites_faites/$total_visites*100) : 0 ?>%"></div></div>
  </div>
  <div class="card kpi-card card-top-line">
    <div class="kpi-label">Restant</div>
    <div class="kpi-value"><?= $total_visites - $visites_faites ?> <span class="unit">visites</span></div>
    <div class="kpi-trend neutral">jusqu'à fin <?= $noms_mois[$mois] ?></div>
  </div>
</div>

<!-- Navigation mois + Calendrier -->
<div class="card" style="padding:0;overflow:hidden">

  <!-- Header navigation -->
  <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);
              display:flex;align-items:center;justify-content:space-between">
    <a href="?mois=<?= $mois_prev ?>&annee=<?= $annee_prev ?>" class="btn btn-secondary btn-sm">← <?= $noms_mois[$mois_prev] ?></a>
    <div style="font-family:'Space Grotesk',sans-serif;font-size:1rem;font-weight:700">
      <?= $noms_mois[$mois] ?> <?= $annee ?>
    </div>
    <a href="?mois=<?= $mois_next ?>&annee=<?= $annee_next ?>" class="btn btn-secondary btn-sm"><?= $noms_mois[$mois_next] ?> →</a>
  </div>

  <!-- Jours de la semaine -->
  <div style="display:grid;grid-template-columns:repeat(7,1fr);border-bottom:1px solid var(--border)">
    <?php foreach ($noms_jours as $j): ?>
    <div style="padding:.5rem;text-align:center;font-size:.68rem;font-weight:600;
                color:var(--text-mute);letter-spacing:.06em;text-transform:uppercase">
      <?= $j ?>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Grille calendrier -->
  <div style="display:grid;grid-template-columns:repeat(7,1fr)">
    <?php
    // Cases vides avant le 1er
    for ($i = 0; $i < $debut_semaine; $i++):
    ?>
    <div style="min-height:80px;border-right:1px solid var(--border);border-bottom:1px solid var(--border);background:var(--bg3)"></div>
    <?php endfor; ?>

    <?php for ($jour = 1; $jour <= $nb_jours; $jour++):
      $date_str  = sprintf('%04d-%02d-%02d', $annee, $mois, $jour);
      $est_auj   = $date_str === date('Y-m-d');
      $est_passe = $date_str < date('Y-m-d');
      $visites_j = $par_date[$date_str] ?? [];
      $col       = ($debut_semaine + $jour - 1) % 7;
      $est_we    = $col === 0 || $col === 6;
    ?>
    <div style="min-height:80px;border-right:1px solid var(--border);border-bottom:1px solid var(--border);
                padding:.4rem;background:<?= $est_auj ? 'rgba(232,0,28,.06)' : ($est_we ? 'var(--bg3)' : 'var(--bg2)') ?>;
                vertical-align:top;position:relative;cursor:pointer"
         onclick="ouvrirJour('<?= $date_str ?>', '<?= $jour ?> <?= $noms_mois[$mois] ?>')">
      <div style="font-size:.75rem;font-weight:<?= $est_auj ? '700' : '500' ?>;
                  color:<?= $est_auj ? 'var(--red)' : ($est_passe ? 'var(--text-mute)' : 'var(--text)') ?>;
                  margin-bottom:.3rem">
        <?= $est_auj ? "● $jour" : $jour ?>
      </div>
      <?php foreach (array_slice($visites_j, 0, 2) as $v): ?>
      <div style="font-size:.6rem;padding:.15rem .35rem;border-radius:3px;margin-bottom:.15rem;
                  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
                  background:<?= $v['statut'] === 'VISITE' ? 'rgba(0,200,100,.15)' : ($v['statut'] === 'ANNULE' ? 'rgba(232,0,28,.15)' : 'rgba(0,120,255,.15)') ?>;
                  color:<?= $v['statut'] === 'VISITE' ? '#00c864' : ($v['statut'] === 'ANNULE' ? 'var(--red)' : '#4d94ff') ?>">
        <?= htmlspecialchars($v['client_nom']) ?>
      </div>
      <?php endforeach; ?>
      <?php if (count($visites_j) > 2): ?>
      <div style="font-size:.58rem;color:var(--text-mute)">+<?= count($visites_j)-2 ?> autres</div>
      <?php endif; ?>
    </div>
    <?php endfor; ?>

    <?php
    // Cases vides après le dernier jour
    $fin = ($debut_semaine + $nb_jours) % 7;
    if ($fin > 0) for ($i = $fin; $i < 7; $i++):
    ?>
    <div style="min-height:80px;border-right:1px solid var(--border);border-bottom:1px solid var(--border);background:var(--bg3)"></div>
    <?php endfor; ?>
  </div>
</div>

<!-- Légende -->
<div style="display:flex;gap:1rem;margin-top:.8rem;flex-wrap:wrap">
  <div style="display:flex;align-items:center;gap:.4rem;font-size:.72rem;color:var(--text-mute)">
    <div style="width:12px;height:12px;border-radius:2px;background:rgba(0,120,255,.2)"></div> Planifiée
  </div>
  <div style="display:flex;align-items:center;gap:.4rem;font-size:.72rem;color:var(--text-mute)">
    <div style="width:12px;height:12px;border-radius:2px;background:rgba(0,200,100,.2)"></div> Effectuée
  </div>
  <div style="display:flex;align-items:center;gap:.4rem;font-size:.72rem;color:var(--text-mute)">
    <div style="width:12px;height:12px;border-radius:2px;background:rgba(232,0,28,.15)"></div> Annulée
  </div>
</div>

<!-- Modal détail jour -->
<div id="modalJour" style="display:none;position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.7);backdrop-filter:blur(4px);align-items:flex-start;
  justify-content:center;padding-top:80px">
  <div class="modal-box" style="border:1px solid var(--border);border-radius:16px;
              width:90%;max-width:480px;overflow:hidden">
    <div style="padding:1rem 1.2rem;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center">
      <div style="font-weight:700" id="modalJourTitre">Visites du jour</div>
      <button onclick="document.getElementById('modalJour').style.display='none'"
        style="background:none;border:none;color:var(--text-mute);cursor:pointer;font-size:1.2rem">✕</button>
    </div>
    <div id="modalJourContenu" style="padding:1rem;max-height:60vh;overflow-y:auto"></div>
    <div style="padding:.8rem 1.2rem;border-top:1px solid var(--border);display:flex;gap:.5rem">
      <button id="btnAjoutJour" class="btn btn-primary btn-sm">+ Ajouter une visite ce jour</button>
      <button onclick="document.getElementById('modalJour').style.display='none'"
        class="btn btn-secondary btn-sm">Fermer</button>
    </div>
  </div>
</div>

<!-- Modal ajout visite -->
<div id="modalAjout" style="display:none;position:fixed;inset:0;z-index:300;
  background:rgba(0,0,0,.7);backdrop-filter:blur(4px);align-items:center;justify-content:center">
  <div class="modal-box" style="border:1px solid var(--border);border-radius:16px;
              width:90%;max-width:420px;overflow:hidden">
    <div style="padding:1rem 1.2rem;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center">
      <div style="font-weight:700">Ajouter une visite</div>
      <button onclick="document.getElementById('modalAjout').style.display='none'"
        style="background:none;border:none;color:var(--text-mute);cursor:pointer;font-size:1.2rem">✕</button>
    </div>
    <form method="POST" action="planning_action.php" style="padding:1.2rem;display:flex;flex-direction:column;gap:.9rem">
      <input type="hidden" name="action" value="ajouter">
      <input type="hidden" name="mois" value="<?= $mois ?>">
      <input type="hidden" name="annee" value="<?= $annee ?>">
      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Client</label>
        <select name="client_id" required
          style="width:100%;background:var(--bg3);border:1px solid var(--border);
                 border-radius:8px;padding:.65rem .9rem;color:var(--text);
                 font-size:.85rem;font-family:Inter,sans-serif">
          <option value="">Sélectionner un client...</option>
          <?php foreach ($mes_clients as $c): ?>
          <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nom']) ?> (<?= $c['code_client'] ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Date de visite</label>
        <input type="date" name="date_visite" id="inputDate"
          min="<?= date('Y-m-d') ?>"
          max="<?= date('Y-m-t', mktime(0,0,0,$mois,1,$annee)) ?>"
          required
          style="width:100%;background:var(--bg3);border:1px solid var(--border);
                 border-radius:8px;padding:.65rem .9rem;color:var(--text);
                 font-size:.85rem;font-family:Inter,sans-serif">
      </div>
      <div style="display:flex;gap:.6rem">
        <button type="button" onclick="document.getElementById('modalAjout').style.display='none'"
          class="btn btn-secondary" style="flex:1;justify-content:center">Annuler</button>
        <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center">Ajouter</button>
      </div>
    </form>
  </div>
</div>

<script>
const visitesPar = <?= json_encode($par_date) ?>;

function ouvrirJour(date, label) {
  document.getElementById('modalJourTitre').textContent = 'Visites du ' + label;
  const contenu = document.getElementById('modalJourContenu');
  const visites = visitesPar[date] || [];

  if (visites.length === 0) {
    contenu.innerHTML = '<div style="text-align:center;color:var(--text-mute);font-size:.82rem;padding:1rem">Aucune visite planifiée ce jour.</div>';
  } else {
    contenu.innerHTML = visites.map(v => `
      <div style="padding:.7rem;background:var(--bg3);border-radius:8px;margin-bottom:.5rem;
                  display:flex;justify-content:space-between;align-items:center">
        <div>
          <div style="font-weight:600;font-size:.82rem">${v.client_nom}</div>
          <div style="font-size:.68rem;color:var(--text-mute)">${v.code_client} · ${v.quartier || ''}</div>
        </div>
        <div style="display:flex;align-items:center;gap:.5rem">
          <span class="badge ${v.statut === 'VISITE' ? 'badge-green' : v.statut === 'ANNULE' ? 'badge-red' : 'badge-blue'}" style="font-size:.62rem">
            ${v.statut}
          </span>
          ${v.statut === 'PLANIFIE' ? `
            <a href="visite.php?client_id=${v.client_id}" class="btn btn-primary btn-sm">Visiter</a>
            <form method="POST" action="planning_action.php" style="margin:0">
              <input type="hidden" name="action" value="annuler">
              <input type="hidden" name="id" value="${v.id}">
              <input type="hidden" name="mois" value="<?= $mois ?>">
              <input type="hidden" name="annee" value="<?= $annee ?>">
              <button class="btn btn-secondary btn-sm" style="color:var(--red)">✕</button>
            </form>
          ` : ''}
        </div>
      </div>
    `).join('');
  }

  document.getElementById('btnAjoutJour').onclick = function() {
    document.getElementById('inputDate').value = date;
    document.getElementById('modalJour').style.display = 'none';
    document.getElementById('modalAjout').style.display = 'flex';
  };

  document.getElementById('modalJour').style.display = 'flex';
}
</script>

<?php close_layout(); ?>

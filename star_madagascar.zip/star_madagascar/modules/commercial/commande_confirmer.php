<?php
// ============================================================
// modules/commercial/commande_confirmer.php
// Prise de commande — Étape 4 : Enregistrement + Ticket PDF
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/tarifs.php';
require_once '../../includes/paiement.php';
require_once '../../includes/recu.php';

$ctx  = include_layout('Commande confirmée', ['COMMERCIAL','MANAGER','MANAGER_INTERIM']);
$user = $ctx['user'];
$db   = getDB();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: commande.php');
  exit;
}

$client_id   = (int)($_POST['client_id'] ?? 0);
$panier_json = $_POST['panier_json'] ?? '[]';

$panier = json_decode($panier_json, true) ?? [];
$panier = array_filter($panier, fn($p) => (int)($p['casiers'] ?? 0) > 0 || (int)($p['bouteilles'] ?? 0) > 0);

// Le client (type, mode de paiement, nom) est relu en base : on ne fait plus
// confiance aux champs cachés du formulaire, modifiables depuis le navigateur.
$stmt = $db->prepare("SELECT * FROM clients WHERE id=? AND statut='ACTIF' AND (secteur_id=? OR ? IS NULL)"); // client du secteur uniquement
$stmt->execute([$client_id, $user['secteur'], $user['secteur']]);
$client_db = $stmt->fetch();

if (empty($panier) || !$client_db) {
  header('Location: commande.php');
  exit;
}
$client_nom      = $client_db['nom'];
$client_code     = $client_db['code_client'];
$client_type     = $client_db['type'];
$client_paiement = $client_db['type_paiement']
  ?: (in_array($client_type, ['DISTRIBUTEUR','GMS','STATION','DEMI_GROS'], true) ? 'AGENCE' : 'DISTRIBUTEUR');

// Totaux recalculés côté serveur (les montants envoyés par le navigateur sont ignorés)
$total_hl = $total_prod = $total_csg = 0;
foreach ($panier as &$ligne) {
  $stmt = $db->prepare("SELECT * FROM produits WHERE id=? AND actif=1");
  $stmt->execute([(int)$ligne['produit_id']]);
  $prod = $stmt->fetch();
  if (!$prod) { $ligne = null; continue; }
  $ligne['prod'] = $prod;
  $ligne['calc'] = calcul_ligne($prod, max(0,(int)($ligne['casiers'] ?? 0)), max(0,(int)($ligne['bouteilles'] ?? 0)));
  $total_hl   += $ligne['calc']['vol'];
  $total_prod += $ligne['calc']['prix'];
  $total_csg  += $ligne['calc']['csg'];
}
unset($ligne);
$panier = array_filter($panier);

$consigne_eligible = in_array($client_type, ['DEMI_GROS','DISTRIBUTEUR','STATION','GMS'], true);
$solde_dispo = 0;
if ($consigne_eligible) {
  $stmt = $db->prepare("SELECT solde_ariary FROM solde_consigne WHERE client_id=?");
  $stmt->execute([$client_id]);
  $solde_dispo = (float)($stmt->fetchColumn() ?: 0);
}
$credit_csg    = $consigne_eligible ? min($solde_dispo, $total_csg) : 0;
$total_montant = $total_prod + $total_csg - $credit_csg;

// Vérifier heure limite
if (date('H:i') >= '20:00') {
  echo '<div class="alert alert-error">⏰ Heure limite dépassée. Commande non enregistrée.</div>';
  close_layout();
  exit;
}

// ── Enregistrer en BD (transaction) ──────────────────────
try {
  $db->beginTransaction();

  // Générer code commande unique
  $code_cmd = 'CMD-' . date('Ymd') . '-' . str_pad(
    $db->query("SELECT COUNT(*)+1 FROM commandes WHERE DATE(date_commande)=CURDATE()")->fetchColumn(),
    4, '0', STR_PAD_LEFT
  );

  // Déterminer statut selon type de paiement
  $statut = $client_paiement === 'AGENCE' ? 'EN_ATTENTE_PAIEMENT' : 'VALIDEE';
  $type_cmd = in_array($client_type, ['DISTRIBUTEUR','GMS','STATION','DEMI_GROS']) ? 'CLIENT_DIRECT' : 'PETIT_CLIENT';
  $date_livraison = date('Y-m-d', strtotime('+1 day'));

  // Trouver distributeur assigné (pour petits clients)
  $distributeur_id = null;
  if ($type_cmd === 'PETIT_CLIENT') {
    $stmt = $db->prepare("SELECT distributeur_id FROM clients WHERE id = ?");
    $stmt->execute([$client_id]);
    $cl = $stmt->fetch();
    $distributeur_id = $cl['distributeur_id'] ?? null;
  }

  // Insérer commande
  $stmt = $db->prepare("
    INSERT INTO commandes
      (code_commande, commercial_id, client_id, distributeur_id,
       type_commande, date_livraison, total_hl,
       montant_ht, montant_consigne, montant_total,
       credit_consigne_utilise, montant_a_payer, statut)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
  ");
  $stmt->execute([
    $code_cmd, $user['id'], $client_id, $distributeur_id,
    $type_cmd, $date_livraison, $total_hl,
    $total_prod, $total_csg, $total_prod + $total_csg,
    $credit_csg, $total_montant, $statut
  ]);
  $commande_id = $db->lastInsertId();

  // Insérer lignes commande (prix et consigne déjà recalculés depuis la base)
  foreach ($panier as $ligne) {
    $prod = $ligne['prod']; $k = $ligne['calc'];
    $stmt = $db->prepare("
      INSERT INTO lignes_commande
        (commande_id, produit_id, quantite_casiers, quantite_bouteilles,
         prix_pag_kit, prix_consigne, volume_hl, sous_total)
      VALUES (?,?,?,?,?,?,?,?)
    ");
    $stmt->execute([
      $commande_id, $prod['id'], (int)($ligne['casiers'] ?? 0), (int)($ligne['bouteilles'] ?? 0),
      $prod['pag_kit_nu'], $k['csg'], $k['vol'], $k['total']
    ]);
  }

  // Déduire crédit consigne si applicable (DEMI_GROS, DISTRIBUTEUR, STATION, GMS uniquement)
  if ($credit_csg > 0 && in_array($client_type, ['DEMI_GROS','DISTRIBUTEUR','STATION','GMS'], true)) {
    $stmt = $db->prepare("
      UPDATE solde_consigne
      SET solde_ariary = GREATEST(0, solde_ariary - ?)
      WHERE client_id = ?
    ");
    $stmt->execute([$credit_csg, $client_id]);
  }

  // Marquer visite comme effectuée dans le planning
  $stmt = $db->prepare("
    UPDATE visites
    SET statut = 'VISITE', date_visite = NOW()
    WHERE commercial_id = ? AND client_id = ? AND DATE(date_visite) = CURDATE() AND statut = 'PLANIFIE'
  ");
  $stmt->execute([$user['id'], $client_id]);

  // Notifier le distributeur si petit client
  if ($distributeur_id) {
    // Récupérer utilisateur du distributeur
    $stmt = $db->prepare("SELECT utilisateur_id FROM clients WHERE id=?");
    $stmt->execute([$distributeur_id]);
    $dist = $stmt->fetch();
    if ($dist && $dist['utilisateur_id']) {
      $stmt = $db->prepare("
        INSERT INTO notifications (utilisateur_id, titre, message, type, reference_id)
        VALUES (?, ?, ?, 'NOUVELLE_COMMANDE', ?)
      ");
      $stmt->execute([
        $dist['utilisateur_id'],
        'Nouvelle commande à livrer',
        "Commande $code_cmd pour $client_nom — " . number_format($total_hl,2) . " hl — Livraison le $date_livraison",
        $commande_id
      ]);
    }
  }

  if ($statut === 'EN_ATTENTE_PAIEMENT') notifier_caisse($db, (int)$commande_id, $code_cmd, $total_montant);

  $db->commit();
  $success = true;

} catch (Exception $e) {
  $db->rollBack();
  $success = false;
  $error_msg = $e->getMessage();
}
?>

<?php if (!$success): ?>
<div class="alert alert-error">
  ❌ Erreur lors de l'enregistrement : <?= htmlspecialchars($error_msg ?? 'Erreur inconnue') ?>.
  <a href="commande.php" style="color:inherit;text-decoration:underline">Réessayer</a>
</div>
<?php else: ?>

<!-- Étapes -->
<div style="display:flex;align-items:center;gap:0;margin-bottom:1.6rem">
  <?php
  $steps = ['Sélection client', 'Saisie commande', 'Vérification', 'Confirmation'];
  foreach ($steps as $i => $s):
  ?>
  <div style="display:flex;align-items:center;flex:1">
    <div style="display:flex;align-items:center;gap:.5rem;flex:1">
      <div style="
        width:28px;height:28px;border-radius:50%;
        background:rgba(0,200,100,.2);border:1px solid #00c864;
        display:flex;align-items:center;justify-content:center;
        font-size:.7rem;font-weight:700;flex-shrink:0;color:#00c864
      ">✓</div>
      <span style="font-size:.75rem;color:#00c864"><?= $s ?></span>
    </div>
    <?php if ($i < count($steps)-1): ?>
      <div style="height:1px;flex:1;background:#00c864;opacity:.3;margin:0 .5rem"></div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<!-- Succès -->
<div style="text-align:center;padding:2rem 1rem;margin-bottom:1.4rem">
  <div style="font-size:3rem;margin-bottom:.8rem">✅</div>
  <div style="font-family:'Space Grotesk',sans-serif;font-size:1.6rem;font-weight:700;margin-bottom:.4rem">
    Commande enregistrée !
  </div>
  <div style="font-size:.85rem;color:var(--text-mute)">
    N° <strong style="color:var(--red)"><?= $code_cmd ?></strong>
    · <?= htmlspecialchars($client_nom) ?>
    · <?= number_format($total_hl,4) ?> hl
  </div>
  <?php if ($client_paiement !== 'AGENCE'): ?>
  <div style="margin-top:.6rem;font-size:.78rem;color:#4d94ff">
    📢 Le distributeur a été notifié. Livraison prévue le <?= date('d/m/Y', strtotime('+1 day')) ?>.
  </div>
  <?php else: ?>
  <div style="margin-top:.6rem;font-size:.78rem;color:#ffa000">
    🏦 En attente de paiement à l'agence.
  </div>
  <?php endif; ?>
</div>

<!-- Reçu (lignes et volumes relus en base, HL par ligne à droite) -->
<?= render_recu($db, (int)$commande_id, $user['nom']) ?>
<div style="max-width:420px;margin:0 auto">
  <!-- Actions -->
  <div style="display:flex;gap:.6rem;margin-top:1rem">
    <a href="commande.php" class="btn btn-primary" style="flex:1;justify-content:center;text-align:center">
      + Nouvelle commande
    </a>
  </div>
  <div style="margin-top:.6rem">
    <a href="dashboard.php" class="btn btn-secondary" style="width:100%;justify-content:center">
      ← Retour au tableau de bord
    </a>
  </div>
</div>



<?php endif; ?>

<?php close_layout(); ?>

<?php
// ============================================================
// modules/commercial/visite_enregistrer.php
// ============================================================

require_once '../../includes/auth_guard.php';
require_once '../../config/db.php';

auth_guard(['COMMERCIAL','MANAGER','MANAGER_INTERIM']);
$user = current_user();
$db   = getDB();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: dashboard.php');
  exit;
}

$client_id = (int)($_POST['client_id'] ?? 0);
$remarque  = trim($_POST['remarque'] ?? '');
$action    = $_POST['action'] ?? 'enregistrer_seulement';

// Client actif du secteur du commercial uniquement
$stmt = $db->prepare("SELECT id FROM clients WHERE id=? AND statut='ACTIF' AND (secteur_id=? OR ? IS NULL)");
$stmt->execute([$client_id, $user['secteur'], $user['secteur']]);
if (!$client_id || !$stmt->fetchColumn()) {
  header('Location: visite.php');
  exit;
}

try {
  // Construire le relevé de stock en JSON
  $stock_releve = [];
  foreach ($_POST as $key => $val) {
    if (str_starts_with($key, 'stock_c_')) {
      $prod_id    = (int)substr($key, 8);
      $casiers    = max(0, (int)$val);
      $bouteilles = max(0, (int)($_POST['stock_b_' . $prod_id] ?? 0));
      $stock_releve[$prod_id] = ['casiers' => $casiers, 'bouteilles' => $bouteilles];
    }
  }
  $stock_json = json_encode($stock_releve, JSON_FORCE_OBJECT);

  // Si une visite était planifiée aujourd'hui pour ce client, on la transforme
  // en visite réalisée ; sinon on enregistre une visite directe (non planifiée).
  $stmt = $db->prepare("
    SELECT id FROM visites
    WHERE commercial_id = ? AND client_id = ? AND DATE(date_visite) = CURDATE() AND statut = 'PLANIFIE'
    LIMIT 1
  ");
  $stmt->execute([$user['id'], $client_id]);
  $planifiee = $stmt->fetch();

  if ($planifiee) {
    $stmt = $db->prepare("
      UPDATE visites SET date_visite = NOW(), statut = 'VISITE', remarque = ?, stock_releve = ?
      WHERE id = ?
    ");
    $stmt->execute([$remarque ?: null, $stock_json, $planifiee['id']]);
  } else {
    $stmt = $db->prepare("
      INSERT INTO visites (commercial_id, client_id, date_visite, statut, remarque, stock_releve)
      VALUES (?, ?, NOW(), 'VISITE', ?, ?)
    ");
    $stmt->execute([$user['id'], $client_id, $remarque ?: null, $stock_json]);
  }

  // Redirection selon action
  if ($action === 'enregistrer_et_commander') {
    // Récupérer infos client pour la commande
    $stmt = $db->prepare("SELECT nom, code_client, type, type_paiement FROM clients WHERE id=?");
    $stmt->execute([$client_id]);
    $cl = $stmt->fetch();
    $params = http_build_query(['client_id' => $client_id]);
    header("Location: commande_produits.php?$params");
  } else {
    header("Location: visite.php?client_id=$client_id&success=1");
  }

} catch (Exception $e) {
  header("Location: visite.php?client_id=$client_id&error=1");
}
exit;

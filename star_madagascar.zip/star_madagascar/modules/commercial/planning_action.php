<?php
// ============================================================
// modules/commercial/planning_action.php
// ============================================================

session_start();
require_once '../../includes/auth_guard.php';
require_once '../../config/db.php';

auth_guard(['COMMERCIAL','MANAGER','MANAGER_INTERIM']);
$user = current_user();
$db   = getDB();

$action = $_POST['action'] ?? '';
$mois   = (int)($_POST['mois'] ?? date('m'));
$annee  = (int)($_POST['annee'] ?? date('Y'));

if ($action === 'ajouter') {
  $client_id   = (int)($_POST['client_id'] ?? 0);
  $date_visite = $_POST['date_visite'] ?? '';

  if ($client_id && $date_visite) {
    // Vérifier que la date n'est pas passée
    if ($date_visite >= date('Y-m-d')) {
      // Calculer semaine du mois
      $semaine = (int)ceil((int)date('d', strtotime($date_visite)) / 7);

      // Insérer (ignorer si doublon)
      $stmt = $db->prepare("
        INSERT IGNORE INTO visites (commercial_id, client_id, date_visite, semaine, statut)
        VALUES (?,?,?,?,'PLANIFIE')
      ");
      $stmt->execute([$user['id'], $client_id, $date_visite, $semaine]);
    }
  }
} elseif ($action === 'annuler') {
  $id = (int)($_POST['id'] ?? 0);
  if ($id) {
    $stmt = $db->prepare("
      UPDATE visites SET statut = 'ANNULE'
      WHERE id = ? AND commercial_id = ?
    ");
    $stmt->execute([$id, $user['id']]);
  }
}

header("Location: planning.php?mois=$mois&annee=$annee");
exit;

<?php
// ============================================================
// modules/commercial/dashboard.php
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Tableau de bord', ['COMMERCIAL','MANAGER','MANAGER_INTERIM']);
$user = $ctx['user'];
$db   = getDB();
$today = date('Y-m-d');

// ── Objectif commercial : nombre de clients à visiter ─────
$stmt = $db->prepare("
  SELECT COALESCE(objectif_clients,0) AS objectif_clients
  FROM objectifs
  WHERE commercial_id=? AND annee=YEAR(CURDATE()) AND mois=MONTH(CURDATE())
    AND semaine IS NULL AND jour IS NULL
  ORDER BY id DESC LIMIT 1
");
$stmt->execute([$user['id']]);
$obj = $stmt->fetch() ?: ['objectif_clients' => 0];
$obj['objectif_hl'] = 0;

// ── Stats du jour ─────────────────────────────────────────
$stmt = $db->prepare("
  SELECT
    COALESCE(SUM(c.total_hl), 0)       AS total_hl,
    COALESCE(SUM(c.montant_total), 0)  AS montant_total,
    COUNT(c.id)                         AS nb_commandes,
    COUNT(DISTINCT c.client_id)         AS nb_clients
  FROM commandes c
  WHERE c.commercial_id = ?
    AND DATE(c.date_commande) = ?
    AND c.statut NOT IN ('CREEE')
");
$stmt->execute([$user['id'], $today]);
$stats = $stmt->fetch() ?: ['total_hl'=>0,'montant_total'=>0,'nb_commandes'=>0,'nb_clients'=>0];

// ── Mois en cours : visites réalisées (objectif) + volume (activité / prime) ──
$stmt = $db->prepare("SELECT COUNT(*) FROM visites WHERE commercial_id=? AND statut='VISITE'
                      AND YEAR(date_visite)=YEAR(CURDATE()) AND MONTH(date_visite)=MONTH(CURDATE())");
$stmt->execute([$user['id']]);
$visites_mois = (int)$stmt->fetchColumn();
$stmt = $db->prepare("SELECT COALESCE(SUM(total_hl),0) FROM commandes WHERE commercial_id=? AND statut NOT IN ('CREEE')
                      AND YEAR(date_commande)=YEAR(CURDATE()) AND MONTH(date_commande)=MONTH(CURDATE())");
$stmt->execute([$user['id']]);
$hl_mois = (float)$stmt->fetchColumn();

// ── Planning du jour ──────────────────────────────────────
$stmt = $db->prepare("
  SELECT pv.*, cl.nom AS client_nom, cl.code_client, cl.type AS client_type,
         cl.adresse, cl.quartier
  FROM visites pv
  JOIN clients cl ON pv.client_id = cl.id
  WHERE pv.commercial_id = ? AND DATE(pv.date_visite) = ?
  ORDER BY pv.statut ASC
");
$stmt->execute([$user['id'], $today]);
$planning = $stmt->fetchAll();

// ── Commandes du jour ─────────────────────────────────────
$stmt = $db->prepare("
  SELECT c.*, cl.nom AS client_nom, cl.code_client
  FROM commandes c
  JOIN clients cl ON c.client_id = cl.id
  WHERE c.commercial_id = ?
    AND DATE(c.date_commande) = ?
  ORDER BY c.created_at DESC
  LIMIT 10
");
$stmt->execute([$user['id'], $today]);
$commandes = $stmt->fetchAll();

// ── Calculs ───────────────────────────────────────────────
$pct_hl      = $obj['objectif_hl'] > 0
  ? min(100, round($stats['total_hl'] / $obj['objectif_hl'] * 100))
  : 0;
$pct_clients = $obj['objectif_clients'] > 0
  ? min(100, round($visites_mois / $obj['objectif_clients'] * 100))
  : 0;
$visites_ok  = count(array_filter($planning, fn($p) => $p['statut'] === 'VISITE'));
$heure       = date('H:i');
$heure_limit = '20:00';
$temps_restant = $heure < $heure_limit ? 'Heure limite : 20h00' : '⚠️ Heure limite dépassée';
?>

<!-- Alerte heure limite -->
<?php if ($heure >= '19:00' && $heure < '20:00'): ?>
<div class="alert alert-error">
  ⏰ Il vous reste moins d'une heure ! Heure limite de prise de commande : 20h00.
</div>
<?php endif; ?>

<!-- Page header -->
<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Bonjour, <?= htmlspecialchars(explode(' ', $user['nom'])[0]) ?> 👋</div>
      <div class="page-subtitle">
        <?= date_fr() ?> · <?= $temps_restant ?>
      </div>
    </div>
    <div style="display:flex;gap:.6rem">
      <a href="visite.php" class="btn btn-secondary">🚶 Visite client</a>
      <a href="commande.php" class="btn btn-primary">+ Commande</a>
    </div>
  </div>
</div>

<!-- KPI Cards -->
<div class="grid-4" style="margin-bottom:1.2rem">

  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Volume du jour</div>
    <div class="kpi-value">
      <?= number_format($stats['total_hl'], 1) ?>
      <span class="unit">hl</span>
    </div>
    <div class="progress-label">
      <span>Mois en cours (base de la prime)</span>
      <span style="color:var(--red)"><?= number_format($hl_mois,2) ?> hl</span>
    </div>
  </div>

  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Clients visités ce mois</div>
    <div class="kpi-value">
      <?= $visites_mois ?>
      <span class="unit">/ <?= $obj['objectif_clients'] ?: '—' ?></span>
    </div>
    <div class="progress-bar">
      <div class="progress-fill" style="width:<?= $pct_clients ?>%"></div>
    </div>
    <div class="progress-label">
      <span><?= count($planning) - $visites_ok ?> restants aujourd'hui</span>
      <span style="color:var(--red)"><?= $pct_clients ?>%</span>
    </div>
  </div>

  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Commandes prises</div>
    <div class="kpi-value">
      <?= $stats['nb_commandes'] ?>
      <span class="unit">cmd</span>
    </div>
    <div class="kpi-trend neutral" style="margin-top:.6rem">
      <?= number_format($stats['montant_total']) ?> Ar au total
    </div>
  </div>

  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Progression planning</div>
    <div class="kpi-value">
      <?= $visites_ok ?>
      <span class="unit">/ <?= count($planning) ?></span>
    </div>
    <div class="progress-bar">
      <div class="progress-fill" style="width:<?= count($planning) > 0 ? round($visites_ok/count($planning)*100) : 0 ?>%"></div>
    </div>
    <div class="progress-label">
      <span>Visites planifiées aujourd'hui</span>
    </div>
  </div>

</div>

<!-- Planning + Commandes -->
<div class="grid-2">

  <!-- Planning du jour -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:1rem 1.2rem;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.85rem;font-weight:600">Planning du jour</div>
      <a href="planning.php" class="btn btn-secondary btn-sm">Voir tout</a>
    </div>
    <div class="table-wrap">
      <?php if (empty($planning)): ?>
        <div style="padding:2rem;text-align:center;color:var(--text-mute);font-size:.82rem">
          Aucune visite planifiée aujourd'hui.<br>
          <a href="planning.php" style="color:var(--red)">Gérer mon planning →</a>
        </div>
      <?php else: ?>
        <table class="data-table">
          <thead>
            <tr>
              <th>Client</th>
              <th>Type</th>
              <th>Quartier</th>
              <th>Statut</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($planning as $v): ?>
            <tr>
              <td>
                <div style="font-weight:500;color:var(--text)"><?= htmlspecialchars($v['client_nom']) ?></div>
                <div style="font-size:.65rem;color:var(--text-mute)"><?= htmlspecialchars($v['code_client']) ?></div>
              </td>
              <td><?= client_type_badge($v['client_type']) ?></td>
              <td style="font-size:.75rem"><?= htmlspecialchars($v['quartier'] ?? '—') ?></td>
              <td><?= planning_statut_badge($v['statut']) ?></td>
              <td>
                <?php if ($v['statut'] === 'PLANIFIE'): ?>
                  <a href="visite.php?client_id=<?= $v['client_id'] ?>" class="btn btn-primary btn-sm">Visiter</a>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>

  <!-- Commandes du jour -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:1rem 1.2rem;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.85rem;font-weight:600">Commandes du jour</div>
      <a href="commandes.php" class="btn btn-secondary btn-sm">Voir tout</a>
    </div>
    <div class="table-wrap">
      <?php if (empty($commandes)): ?>
        <div style="padding:2rem;text-align:center;color:var(--text-mute);font-size:.82rem">
          Aucune commande prise aujourd'hui.<br>
          <a href="commande.php" style="color:var(--red)">Prendre une commande →</a>
        </div>
      <?php else: ?>
        <table class="data-table">
          <thead>
            <tr>
              <th>N°</th>
              <th>Client</th>
              <th>Volume</th>
              <th>Montant</th>
              <th>Statut</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($commandes as $c): ?>
            <tr>
              <td style="font-family:monospace;font-size:.72rem;color:var(--text-mute)"><?= htmlspecialchars($c['code_commande']) ?></td>
              <td>
                <div style="font-weight:500;color:var(--text)"><?= htmlspecialchars($c['client_nom']) ?></div>
              </td>
              <td style="font-weight:600;color:var(--red)"><?= number_format($c['total_hl'],2) ?> hl</td>
              <td style="font-size:.78rem"><?= number_format($c['montant_total']) ?> Ar</td>
              <td><?= commande_statut_badge($c['statut']) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>

</div>

<?php

// ── Badge helpers ─────────────────────────────────────────
function client_type_badge(string $type): string {
  $map = [
    'DISTRIBUTEUR' => ['badge-blue',   'Dist.'],
    'GMS'          => ['badge-orange', 'GMS'],
    'STATION'      => ['badge-orange', 'Station'],
    'DEMI_GROS'    => ['badge-blue',   'Demi-gros'],
    'EPICERIE'     => ['badge-mute',   'Épicerie'],
    'BAR'          => ['badge-mute',   'Bar'],
    'RESTAURANT'   => ['badge-mute',   'Resto'],
  ];
  [$cls, $label] = $map[$type] ?? ['badge-mute', $type];
  return "<span class='badge $cls'>$label</span>";
}

function planning_statut_badge(string $s): string {
  return match($s) {
    'VISITE'  => "<span class='badge badge-green'>Visité</span>",
    'ANNULE'  => "<span class='badge badge-red'>Annulé</span>",
    default   => "<span class='badge badge-mute'>Planifié</span>",
  };
}

function commande_statut_badge(string $s): string {
  return match($s) {
    'CREEE'             => "<span class='badge badge-mute'>Brouillon</span>",
    'VALIDEE'           => "<span class='badge badge-blue'>Validée</span>",
    'TRANSMISE'         => "<span class='badge badge-orange'>Transmise</span>",
    'EN_ATTENTE_PAIEMENT'=>"<span class='badge badge-orange'>Att. paiement</span>",
    'PAYEE'             => "<span class='badge badge-green'>Payée</span>",
    'LIVREE'            => "<span class='badge badge-green'>Livrée</span>",
    'TERMINEE'          => "<span class='badge badge-green'>Terminée</span>",
    'DEFAUT_SIGNALE'    => "<span class='badge badge-red'>Défaut</span>",
    default             => "<span class='badge badge-mute'>$s</span>",
  };
}

?>
<!-- ── Graphiques ─────────────────────────────────────────── -->
<?php
$j30 = jours_periode(30);
$st = $db->prepare("SELECT DATE(date_commande) d, SUM(total_hl) v FROM commandes WHERE commercial_id=? AND statut NOT IN ('CREEE') AND date_commande >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY DATE(date_commande)");
$st->execute([$user['id']]); $mes_hl = serie($j30, $st->fetchAll());
$st = $db->prepare("SELECT DATE(date_visite) d, COUNT(*) v FROM visites WHERE commercial_id=? AND statut='VISITE' AND date_visite >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY DATE(date_visite)");
$st->execute([$user['id']]); $mes_vis = serie($j30, $st->fetchAll());
$st = $db->prepare("SELECT p.famille l, ROUND(SUM(lc.volume_hl),2) v FROM lignes_commande lc JOIN commandes c ON c.id=lc.commande_id JOIN produits p ON p.id=lc.produit_id
  WHERE c.commercial_id=? AND c.statut NOT IN ('CREEE') AND YEAR(c.date_commande)=YEAR(CURDATE()) AND MONTH(c.date_commande)=MONTH(CURDATE()) GROUP BY p.famille ORDER BY v DESC");
$st->execute([$user['id']]); $mes_fam = $st->fetchAll();
?>
<div class="grid-2" style="margin-top:1rem">
<?= graphique('gMonVolume', 'Mon activité (30 derniers jours)', ['type'=>'bar','data'=>['labels'=>etiquettes_jours($j30),'datasets'=>[
  ['type'=>'bar','label'=>'Volume (hl)','data'=>array_values($mes_hl),'backgroundColor'=>'rgba(232,0,28,.75)','borderRadius'=>3,'yAxisID'=>'y'],
  ['type'=>'line','label'=>'Visites','data'=>array_values($mes_vis),'borderColor'=>'#1f9d55','backgroundColor'=>'#1f9d55','tension'=>.3,'yAxisID'=>'y1','pointRadius'=>2],
]],'options'=>['scales'=>['y'=>['beginAtZero'=>true],'y1'=>['beginAtZero'=>true,'position'=>'right','grid'=>['drawOnChartArea'=>false]]]]], 260) ?>
<?= graphique('gMesFamilles', 'Mes ventes du mois par famille', ['type'=>'bar','unite'=>'hl','data'=>['labels'=>array_column($mes_fam,'l'),'datasets'=>[
  ['label'=>'Volume','data'=>array_map('floatval',array_column($mes_fam,'v')),'backgroundColor'=>'rgba(232,175,52,.8)','borderRadius'=>4]]],
  'options'=>['indexAxis'=>'y','plugins'=>['legend'=>['display'=>false]]]], 260) ?>
</div>

<?php close_layout();
?>

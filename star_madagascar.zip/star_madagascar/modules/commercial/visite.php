<?php
// ============================================================
// modules/commercial/visite.php
// Visite client — Saisie du stock observé
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Visite client', ['COMMERCIAL','MANAGER','MANAGER_INTERIM']);
$user = $ctx['user'];
$db   = getDB();

$client_id = (int)($_GET['client_id'] ?? 0);
if (!$client_id) {
  // Le menu « Visite client » arrive ici sans client : on affiche la liste
  // des clients du secteur à choisir (avant, la page renvoyait au tableau de bord).
  $st = $db->prepare("SELECT c.id, c.code_client, c.nom, c.type, c.quartier,
      (SELECT MAX(v.date_visite) FROM visites v WHERE v.client_id=c.id AND v.statut='VISITE') AS derniere_visite,
      (SELECT COUNT(*) FROM visites v WHERE v.client_id=c.id AND v.commercial_id=? AND v.statut='PLANIFIE' AND DATE(v.date_visite)=CURDATE()) AS prevu_auj
    FROM clients c
    WHERE c.statut='ACTIF' AND (c.secteur_id = ? OR ? IS NULL)
    ORDER BY prevu_auj DESC, c.nom");
  $st->execute([$user['id'], $user['secteur'], $user['secteur']]);
  $liste = $st->fetchAll();
  ?>
  <div class="page-header"><div class="page-title">Visite client</div>
    <div class="page-subtitle">Choisissez le client visité · <?= count($liste) ?> client(s) dans votre secteur</div></div>
  <div class="card" style="padding:.8rem 1rem;margin-bottom:1rem">
    <input type="text" class="form-input" style="width:100%" placeholder="🔍 Nom, code ou quartier..." oninput="
      const q=this.value.toLowerCase(); document.querySelectorAll('#listeClients tbody tr').forEach(r=>r.style.display=r.textContent.toLowerCase().includes(q)?'':'none')">
  </div>
  <div class="card card-long" style="padding:0">
    <table class="data-table" id="listeClients">
      <thead><tr><th>Client</th><th>Type</th><th>Quartier</th><th>Dernière visite</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($liste as $c): ?>
        <tr>
          <td><div style="font-weight:600"><?= htmlspecialchars($c['nom']) ?></div><div style="font-size:.65rem;color:var(--text-mute)"><?= htmlspecialchars($c['code_client'] ?? '') ?></div></td>
          <td><?= htmlspecialchars(type_label($c['type'])) ?></td>
          <td><?= htmlspecialchars($c['quartier'] ?? '—') ?></td>
          <td style="font-size:.75rem"><?= $c['derniere_visite'] ? date('d/m/Y', strtotime($c['derniere_visite'])) : '—' ?>
            <?= $c['prevu_auj'] ? ' <span class="badge badge-orange" style="font-size:.6rem">Prévue aujourd’hui</span>' : '' ?></td>
          <td><a class="btn btn-primary btn-sm" href="visite.php?client_id=<?= $c['id'] ?>">Visiter →</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php
  close_layout();
  exit;
}

// Infos client
// Un commercial ne peut visiter que les clients de son secteur
$stmt = $db->prepare("SELECT * FROM clients WHERE id = ? AND statut = 'ACTIF' AND (secteur_id = ? OR ? IS NULL)");
$stmt->execute([$client_id, $user['secteur'], $user['secteur']]);
$client = $stmt->fetch();
if (!$client) {
  header('Location: visite.php');
  exit;
}

// Produits actifs
$produits = $db->query("
  SELECT p.*, p.famille AS famille_nom
  FROM produits p
  WHERE p.actif = 1
  ORDER BY p.famille ASC, p.description ASC
")->fetchAll();

// Grouper par famille
$familles = [];
foreach ($produits as $prod) {
  $familles[$prod['famille_nom']][] = $prod;
}

// Dernier stock relevé chez ce client (JSON stocké directement sur la visite)
$stmt = $db->prepare("
  SELECT stock_releve FROM visites
  WHERE client_id = ? AND statut = 'VISITE' AND stock_releve IS NOT NULL
  ORDER BY date_visite DESC LIMIT 1
");
$stmt->execute([$client_id]);
$dernier = $stmt->fetch();
$stock_precedent = [];
if ($dernier && $dernier['stock_releve']) {
  foreach (json_decode($dernier['stock_releve'], true) as $pid => $s) {
    $stock_precedent[$pid] = ['stock_casiers' => $s['casiers'] ?? 0, 'stock_bouteilles' => $s['bouteilles'] ?? 0];
  }
}

// Historique des 5 dernières visites de ce commercial
$stmt = $db->prepare("
  SELECT date_visite, remarque, stock_releve
  FROM visites
  WHERE client_id = ? AND commercial_id = ? AND statut = 'VISITE'
  ORDER BY date_visite DESC
  LIMIT 5
");
$stmt->execute([$client_id, $user['id']]);
$historique = array_map(function($h) {
  $stock = $h['stock_releve'] ? json_decode($h['stock_releve'], true) : [];
  $h['nb_produits']    = count($stock);
  $h['total_casiers']  = array_sum(array_column($stock, 'casiers'));
  return $h;
}, $stmt->fetchAll());
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Visite — <?= htmlspecialchars($client['nom']) ?></div>
      <div class="page-subtitle">
        <?= htmlspecialchars($client['code_client']) ?> ·
        <?= htmlspecialchars($client['quartier'] ?? '') ?> ·
        <?= type_label($client['type']) ?>
      </div>
    </div>
    <div style="display:flex;gap:.6rem">
      <a href="dashboard.php" class="btn btn-secondary">← Retour</a>
      <a href="commande_produits.php?client_id=<?= $client_id ?>" class="btn btn-primary">
        📋 Prendre une commande
      </a>
    </div>
  </div>
</div>

<?php if (!empty($_GET['success'])): ?>
<div class="alert alert-success">✅ Visite enregistrée.</div>
<?php elseif (!empty($_GET['error'])): ?>
<div class="alert alert-error">❌ La visite n'a pas pu être enregistrée. Réessayez.</div>
<?php endif; ?>

<div class="visite-grid" style="display:grid;grid-template-columns:1fr 280px;gap:1rem;align-items:start">
<style>@media (max-width:900px){.visite-grid{grid-template-columns:1fr !important}}</style>

  <!-- Saisie stock -->
  <div>
    <form method="POST" action="visite_enregistrer.php">
      <input type="hidden" name="client_id" value="<?= $client_id ?>">

      <!-- Stock observé : même présentation que la page Produits (un tableau
           simple dans une carte), sans effet de flou sur chaque champ.
           L'ancienne version empilait ~70 champs ayant chacun leur propre
           backdrop-filter dans une très grande carte floutée : au défilement,
           le navigateur n'arrivait plus à peindre ces calques et le contenu
           disparaissait. -->
      <div class="card card-long" style="padding:0;margin-bottom:1rem">
        <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);
                    display:flex;justify-content:space-between;align-items:center;gap:.8rem;flex-wrap:wrap">
          <div style="font-size:.85rem;font-weight:600">📦 Stock observé chez le client</div>
          <input type="text" class="form-input" placeholder="🔍 Filtrer un produit..." oninput="filtrerStock(this.value)"
                 style="max-width:220px;padding:.4rem .7rem;font-size:.78rem">
          <div style="font-size:.72rem;color:var(--text-mute)">
            <?= !empty($stock_precedent) ? 'Pré-rempli depuis la dernière visite' : 'Aucun stock précédent' ?>
          </div>
        </div>
        <table class="data-table stock-visite">
          <thead>
            <tr>
              <th>Produit</th>
              <th style="text-align:center;width:120px">Casiers</th>
              <th style="text-align:center;width:120px">Bouteilles</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($familles as $famille => $prods): ?>
            <tr class="famille-row"><td colspan="3" style="background:var(--bg3);font-size:.65rem;font-weight:700;
                color:var(--text-mute);text-transform:uppercase;letter-spacing:.08em;padding:.45rem 1.2rem">
              <?= htmlspecialchars($famille) ?></td></tr>
            <?php foreach ($prods as $prod):
              $prec = $stock_precedent[$prod['id']] ?? null;
            ?>
            <tr class="prod-row" data-nom="<?= htmlspecialchars($prod['description'] . ' ' . $prod['code']) ?>">
              <td>
                <div style="font-size:.8rem;font-weight:500;color:var(--text)"><?= htmlspecialchars($prod['description']) ?></div>
                <div style="font-size:.65rem;color:var(--text-mute)">
                  <?= $prod['code'] ?> · Kit <?= $prod['kit'] ?>
                  <?php if ($prec): ?> · <span style="color:#4d94ff">Préc : <?= $prec['stock_casiers'] ?> casier(s)</span><?php endif; ?>
                </div>
              </td>
              <td style="text-align:center">
                <input type="number" class="qty-input" name="stock_c_<?= $prod['id'] ?>"
                  value="<?= $prec ? $prec['stock_casiers'] : 0 ?>" min="0" placeholder="0">
              </td>
              <td style="text-align:center">
                <input type="number" class="qty-input" name="stock_b_<?= $prod['id'] ?>"
                  value="<?= $prec ? $prec['stock_bouteilles'] : 0 ?>" min="0" max="<?= $prod['kit']-1 ?>" placeholder="0"
                  title="Maximum <?= $prod['kit']-1 ?> (au-delà, compter un casier)">
              </td>
            </tr>
            <?php endforeach; ?>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <script>
      function filtrerStock(q) {
        q = q.trim().toLowerCase();
        document.querySelectorAll('.stock-visite .prod-row').forEach(r => {
          r.style.display = !q || r.dataset.nom.toLowerCase().includes(q) ? '' : 'none';
        });
        document.querySelectorAll('.stock-visite .famille-row').forEach(f => {
          let n = f.nextElementSibling, visible = false;
          while (n && !n.classList.contains('famille-row')) { if (n.style.display !== 'none') visible = true; n = n.nextElementSibling; }
          f.style.display = visible ? '' : 'none';
        });
      }
      </script>

      <!-- Remarque -->
      <div class="card" style="margin-bottom:1rem">
        <div style="font-size:.72rem;color:var(--text-mute);margin-bottom:.5rem;font-weight:500">
          Remarque / Observation (optionnel)
        </div>
        <textarea name="remarque" rows="3" placeholder="Ex: client absent, stock en rupture sur THB, besoin de matériels PLV..."
          style="width:100%;background:var(--bg3);border:1px solid var(--border);
                 border-radius:8px;padding:.7rem .9rem;color:var(--text);
                 font-size:.82rem;font-family:Inter,sans-serif;resize:vertical;
                 line-height:1.5"
          onfocus="this.style.borderColor='var(--red)'"
          onblur="this.style.borderColor='var(--border)'"></textarea>
      </div>

      <div style="display:flex;gap:.7rem">
        <button type="submit" name="action" value="enregistrer_seulement"
          class="btn btn-secondary" style="flex:1;justify-content:center">
          💾 Enregistrer la visite
        </button>
        <button type="submit" name="action" value="enregistrer_et_commander"
          class="btn btn-primary" style="flex:1;justify-content:center">
          💾 Enregistrer et prendre une commande →
        </button>
      </div>
    </form>
  </div>

  <!-- Infos client + historique -->
  <div style="display:flex;flex-direction:column;gap:.8rem">

    <!-- Fiche client -->
    <div class="card card-top-line">
      <div style="font-size:.72rem;color:var(--text-mute);font-weight:600;
                  text-transform:uppercase;letter-spacing:.06em;margin-bottom:.8rem">
        Fiche client
      </div>
      <?php
      $infos = [
        'Code' => $client['code_client'],
        'Type' => type_label($client['type']),
        'Adresse' => $client['adresse'],
        'Quartier' => $client['quartier'] ?? '—',
        'Téléphone' => $client['telephone'] ?? '—',
        'Paiement' => $client['type_paiement'] === 'AGENCE' ? '🏦 Agence' : '💵 Distributeur',
      ];
      foreach ($infos as $label => $val): ?>
      <div style="display:flex;justify-content:space-between;margin-bottom:.4rem;font-size:.75rem">
        <span style="color:var(--text-mute)"><?= $label ?></span>
        <span style="text-align:right;max-width:150px"><?= htmlspecialchars($val) ?></span>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Historique visites -->
    <div class="card" style="padding:0;overflow:hidden">
      <div style="padding:.8rem 1rem;border-bottom:1px solid var(--border);font-size:.82rem;font-weight:600">
        Historique des visites
      </div>
      <?php if (empty($historique)): ?>
      <div style="padding:1.2rem;text-align:center;color:var(--text-mute);font-size:.78rem">
        Pas encore de visite enregistrée.
      </div>
      <?php else: ?>
      <?php foreach ($historique as $h): ?>
      <div style="padding:.6rem 1rem;border-bottom:1px solid var(--bg3);font-size:.75rem">
        <div style="display:flex;justify-content:space-between;margin-bottom:.2rem">
          <span style="font-weight:600"><?= date('d/m/Y', strtotime($h['date_visite'])) ?></span>
          <span style="color:var(--text-mute)"><?= $h['total_casiers'] ?? 0 ?> casiers</span>
        </div>
        <?php if ($h['remarque']): ?>
        <div style="color:var(--text-mute);font-style:italic">
          <?= htmlspecialchars(substr($h['remarque'], 0, 60)) ?>
          <?= strlen($h['remarque']) > 60 ? '...' : '' ?>
        </div>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- Signaler un défaut -->
    <div style="background:rgba(232,0,28,.06);border:1px dashed rgba(232,0,28,.3);
                border-radius:10px;padding:.9rem">
      <div style="font-size:.78rem;font-weight:600;margin-bottom:.3rem">⚠️ Défaut produit ?</div>
      <div style="font-size:.72rem;color:var(--text-mute);margin-bottom:.7rem">
        Signalez un produit défectueux observé chez ce client.
      </div>
      <a href="signaler_defaut.php?client_id=<?= $client_id ?>" class="btn btn-secondary btn-sm">
        Signaler un défaut
      </a>
    </div>

  </div>
</div>

<?php
function type_label(string $t): string {
  $map = [
    'DISTRIBUTEUR'=>'Distributeur','GMS'=>'GMS','STATION'=>'Station Service',
    'DEMI_GROS'=>'Demi-Gros','EPICERIE'=>'Épicerie','BAR'=>'Bar','RESTAURANT'=>'Restaurant'
  ];
  return $map[$t] ?? $t;
}
close_layout();
?>

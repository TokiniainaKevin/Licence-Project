<?php
// ============================================================
// modules/commercial/commande_produits.php
// Prise de commande — Étape 2 : Sélection des produits
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/tarifs.php';

$ctx  = include_layout('Nouvelle commande', ['COMMERCIAL','MANAGER','MANAGER_INTERIM']);
$user = $ctx['user'];
$db   = getDB();

// Récupérer paramètres client
// Seul l'identifiant vient de l'URL : nom, type et mode de paiement sont relus
// en base (avant, ils étaient pris tels quels dans l'URL et réaffichés sans
// échappement — modifiables et injectables).
$client_id = (int)($_GET['client_id'] ?? 0);
$stmt = $db->prepare("SELECT * FROM clients WHERE id=? AND statut='ACTIF' AND (secteur_id=? OR ? IS NULL)"); // client du secteur uniquement
$stmt->execute([$client_id, $user['secteur'], $user['secteur']]);
$cl_db = $stmt->fetch();
if (!$cl_db) {
  header('Location: commande.php');
  exit;
}
$client_nom      = htmlspecialchars($cl_db['nom']);
$client_code     = htmlspecialchars($cl_db['code_client'] ?? '');
$client_type     = htmlspecialchars($cl_db['type']);
$client_paiement = htmlspecialchars($cl_db['type_paiement'] ?? '');

// Récupérer tous les produits actifs avec leurs familles
$produits = $db->query("
  SELECT p.*, p.famille AS famille_nom
  FROM produits p
  WHERE p.actif = 1
  ORDER BY p.famille ASC, p.description ASC
")->fetchAll();

// Grouper par famille
$familles = [];
foreach ($produits as $prod) {
  $familles[$prod['famille_nom']][] = $prod;
}

// Solde consigne du client — seuls les DEMI_GROS, DISTRIBUTEUR, STATION et GMS
// ont un compte consigne (les épiceries/bars/restaurants passent par un
// distributeur ou demi-gros et ne retournent jamais de consigne directement).
$solde_consigne = 0;
if (in_array($client_type, ['DEMI_GROS','DISTRIBUTEUR','STATION','GMS'], true)) {
  $stmt = $db->prepare("SELECT solde_ariary FROM solde_consigne WHERE client_id = ?");
  $stmt->execute([$client_id]);
  $sc = $stmt->fetch();
  $solde_consigne = $sc ? $sc['solde_ariary'] : 0;
}
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Sélection des produits</div>
      <div class="page-subtitle">Client : <strong style="color:var(--red)"><?= $client_nom ?></strong> · <?= $client_code ?></div>
    </div>
    <a href="commande.php" class="btn btn-secondary">← Changer de client</a>
  </div>
</div>

<!-- Étapes -->
<div style="display:flex;align-items:center;gap:0;margin-bottom:1.6rem">
  <?php
  $steps = ['Sélection client', 'Saisie commande', 'Vérification', 'Confirmation'];
  foreach ($steps as $i => $s):
    $done   = $i === 0;
    $active = $i === 1;
  ?>
  <div style="display:flex;align-items:center;flex:1">
    <div style="display:flex;align-items:center;gap:.5rem;flex:1">
      <div style="
        width:28px;height:28px;border-radius:50%;
        background:<?= $done ? 'rgba(0,200,100,.2)' : ($active ? 'var(--red)' : 'var(--bg3)') ?>;
        border:1px solid <?= $done ? '#00c864' : ($active ? 'var(--red)' : 'var(--border)') ?>;
        display:flex;align-items:center;justify-content:center;
        font-size:.7rem;font-weight:700;flex-shrink:0;
        color:<?= $done ? '#00c864' : ($active ? '#fff' : 'var(--text-mute)') ?>
      "><?= $done ? '✓' : ($i+1) ?></div>
      <span style="font-size:.75rem;font-weight:<?= $active ? '600' : '400' ?>;color:<?= $active ? 'var(--text)' : ($done ? '#00c864' : 'var(--text-mute)') ?>"><?= $s ?></span>
    </div>
    <?php if ($i < count($steps)-1): ?>
      <div style="height:1px;flex:1;background:var(--border);margin:0 .5rem"></div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<!-- Layout : Produits + Panier -->
<div style="display:grid;grid-template-columns:1fr 320px;gap:1rem;align-items:start">

  <!-- PRODUITS -->
  <div>
    <!-- Recherche + filtre famille -->
    <div class="card" style="padding:.8rem 1rem;margin-bottom:1rem">
      <div style="display:flex;gap:.6rem;flex-wrap:wrap;align-items:center">
        <input type="text" id="searchProd"
          placeholder="🔍 Rechercher un produit..."
          oninput="filterProds(this.value)"
          style="flex:1;min-width:200px;background:var(--bg3);border:1px solid var(--border);
                 border-radius:8px;padding:.55rem .9rem;color:var(--text);
                 font-size:.82rem;font-family:Inter,sans-serif;outline:none"
          onfocus="this.style.borderColor='var(--red)'"
          onblur="this.style.borderColor='var(--border)'">
        <div style="display:flex;gap:.4rem;flex-wrap:wrap" id="familleFilters">
          <button class="btn btn-primary btn-sm famille-btn" onclick="filterFamille('all',this)">Toutes</button>
          <?php foreach (array_keys($familles) as $f): ?>
          <button class="btn btn-secondary btn-sm famille-btn"
            onclick="filterFamille('<?= htmlspecialchars($f) ?>',this)">
            <?= htmlspecialchars($f) ?>
          </button>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Liste produits par famille -->
    <?php foreach ($familles as $famille => $prods): ?>
    <div class="famille-section" data-famille="<?= htmlspecialchars($famille) ?>"
         style="margin-bottom:1rem">
      <div style="font-size:.68rem;font-weight:700;color:var(--text-mute);
                  letter-spacing:.1em;text-transform:uppercase;
                  margin-bottom:.5rem;padding:.3rem .6rem;
                  background:var(--bg3);border-radius:6px;display:inline-block">
        <?= htmlspecialchars($famille) ?>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:.6rem">
        <?php foreach ($prods as $prod): ?>
        <div class="prod-card"
             data-id="<?= $prod['id'] ?>"
             data-nom="<?= htmlspecialchars(strtolower($prod['description'])) ?>"
             data-famille="<?= htmlspecialchars($famille) ?>"
             data-pag-kit="<?= $prod['pag_kit_nu'] ?>"
             data-pag-kit-loge="<?= $prod['pag_kit_loge'] ?>"
             data-pag-nu="<?= $prod['pag_nu'] ?>"
             data-kit="<?= $prod['kit'] ?>"
             data-vol="<?= $prod['volume_hl'] ?>"
             data-consigne-b="<?= $prod['consigne_bouteille'] ?>"
             data-consigne-c="<?= consigne_casier_plein($prod) ?>"
             style="background:var(--bg-solid);border:1px solid var(--border);
                    border-radius:10px;padding:.8rem;cursor:pointer;
                    transition:all .15s;user-select:none"
             onclick="toggleProd(this)">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.5rem">
            <div>
              <div style="font-size:.8rem;font-weight:600;color:var(--text);line-height:1.2">
                <?= htmlspecialchars($prod['description']) ?>
              </div>
              <div style="font-size:.65rem;color:var(--text-mute);margin-top:.2rem">
                Code : <?= htmlspecialchars($prod['code']) ?>
                · <?= $prod['kit'] ?> btl/casier
                · <?= $prod['type_emballage'] ?>
              </div>
            </div>
            <div class="prod-check" style="width:20px;height:20px;border-radius:50%;
              border:2px solid var(--border);flex-shrink:0;
              display:flex;align-items:center;justify-content:center;
              font-size:.7rem;transition:all .15s"></div>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div>
              <div style="font-size:.75rem;color:var(--red);font-weight:600">
                <?= number_format($prod['pag_kit_nu']) ?> Ar/casier
              </div>
              <?php if (consigne_casier_plein($prod) > 0): ?>
              <div style="font-size:.63rem;color:var(--text-mute)">
                + <?= number_format(consigne_casier_plein($prod)) ?> Ar consigne/casier · <?= number_format($prod['consigne_bouteille']) ?> Ar/btl
              </div>
              <?php endif; ?>
            </div>
            <div style="font-size:.65rem;color:var(--text-mute)">
              <?= number_format($prod['volume_hl'],4) ?> hl/casier
            </div>
          </div>

          <!-- Quantité (masqué par défaut) -->
          <div class="prod-qty" style="display:none;margin-top:.8rem;
               border-top:1px solid var(--border);padding-top:.7rem">
            <div style="font-size:.68rem;color:var(--text-mute);margin-bottom:.4rem">Quantité</div>
            <div style="display:flex;align-items:center;gap:.5rem">
              <div style="flex:1">
                <div style="font-size:.65rem;color:var(--text-mute);margin-bottom:.2rem">Casiers</div>
                <div style="display:flex;align-items:center;gap:.3rem">
                  <button onclick="event.stopPropagation();changeQty(<?= $prod['id'] ?>,'c',-1)"
                    style="width:28px;height:28px;border-radius:6px;border:1px solid var(--border);
                           background:var(--bg3);color:var(--text);cursor:pointer;font-size:.9rem">−</button>
                  <input type="number" id="qty_c_<?= $prod['id'] ?>" value="0" min="0"
                    onclick="event.stopPropagation()"
                    onchange="updatePanier(<?= $prod['id'] ?>)"
                    style="width:48px;text-align:center;background:var(--bg3);
                           border:1px solid var(--border);border-radius:6px;
                           padding:.3rem;color:var(--text);font-size:.85rem;
                           font-family:Inter,sans-serif">
                  <button onclick="event.stopPropagation();changeQty(<?= $prod['id'] ?>,'c',1)"
                    style="width:28px;height:28px;border-radius:6px;border:1px solid var(--red);
                           background:var(--red-dim);color:var(--red);cursor:pointer;font-size:.9rem">+</button>
                </div>
              </div>
              <div style="flex:1">
                <div style="font-size:.65rem;color:var(--text-mute);margin-bottom:.2rem">Bouteilles</div>
                <div style="display:flex;align-items:center;gap:.3rem">
                  <button onclick="event.stopPropagation();changeQty(<?= $prod['id'] ?>,'b',-1)"
                    style="width:28px;height:28px;border-radius:6px;border:1px solid var(--border);
                           background:var(--bg3);color:var(--text);cursor:pointer;font-size:.9rem">−</button>
                  <input type="number" id="qty_b_<?= $prod['id'] ?>" value="0" min="0"
                    max="<?= $prod['kit']-1 ?>"
                    onclick="event.stopPropagation()"
                    onchange="updatePanier(<?= $prod['id'] ?>)"
                    style="width:48px;text-align:center;background:var(--bg3);
                           border:1px solid var(--border);border-radius:6px;
                           padding:.3rem;color:var(--text);font-size:.85rem;
                           font-family:Inter,sans-serif">
                  <button onclick="event.stopPropagation();changeQty(<?= $prod['id'] ?>,'b',1)"
                    style="width:28px;height:28px;border-radius:6px;border:1px solid var(--red);
                           background:var(--red-dim);color:var(--red);cursor:pointer;font-size:.9rem">+</button>
                </div>
              </div>
            </div>
            <div id="sous_total_<?= $prod['id'] ?>"
              style="margin-top:.5rem;font-size:.72rem;color:var(--red);font-weight:600;text-align:right">
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- PANIER (sticky) -->
  <div style="position:sticky;top:calc(var(--topbar-h) + 1rem)">
    <div class="card" style="padding:0;overflow:hidden">
      <div style="padding:.9rem 1.1rem;border-bottom:1px solid var(--border);
                  background:var(--bg3);display:flex;justify-content:space-between;align-items:center">
        <div style="font-size:.85rem;font-weight:600">🛒 Panier</div>
        <span id="panier-count" class="badge badge-red">0 produit</span>
      </div>

      <div id="panier-items" style="max-height:320px;overflow-y:auto;padding:.8rem">
        <div id="panier-empty" style="text-align:center;color:var(--text-mute);font-size:.78rem;padding:1.5rem">
          Aucun produit sélectionné
        </div>
      </div>

      <!-- Totaux -->
      <div style="padding:.9rem 1.1rem;border-top:1px solid var(--border);display:flex;flex-direction:column;gap:.4rem">
        <div style="display:flex;justify-content:space-between;font-size:.75rem;color:var(--text-mute)">
          <span>Volume total</span>
          <span id="total-hl" style="color:var(--text);font-weight:600">0,00 hl</span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:.75rem;color:var(--text-mute)">
          <span>Sous-total produits</span>
          <span id="total-prod" style="color:var(--text);font-weight:600">0 Ar</span>
        </div>
        <?php if ($client_paiement === 'AGENCE'): ?>
        <div style="display:flex;justify-content:space-between;font-size:.75rem;color:var(--text-mute)">
          <span>Consigne</span>
          <span id="total-consigne" style="color:var(--text);font-weight:600">0 Ar</span>
        </div>
        <?php if ($solde_consigne > 0): ?>
        <div style="display:flex;justify-content:space-between;font-size:.75rem;color:#00c864">
          <span>Crédit consigne disponible</span>
          <span>−<?= number_format($solde_consigne) ?> Ar</span>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <div style="height:1px;background:var(--border);margin:.2rem 0"></div>
        <div style="display:flex;justify-content:space-between;font-size:.85rem">
          <span style="font-weight:600">Total à payer</span>
          <span id="total-final" style="color:var(--red);font-weight:700;font-size:1rem">0 Ar</span>
        </div>
      </div>

      <!-- Bouton continuer -->
      <div style="padding:.8rem 1.1rem;border-top:1px solid var(--border)">
        <form id="formCommande" method="POST" action="commande_verification.php">
          <input type="hidden" name="client_id" value="<?= $client_id ?>">
          <input type="hidden" name="client_nom" value="<?= $client_nom ?>">
          <input type="hidden" name="client_code" value="<?= $client_code ?>">
          <input type="hidden" name="client_type" value="<?= $client_type ?>">
          <input type="hidden" name="client_paiement" value="<?= $client_paiement ?>">
          <input type="hidden" name="panier_json" id="panier_json" value="[]">
          <input type="hidden" name="total_hl" id="input_total_hl" value="0">
          <input type="hidden" name="total_montant" id="input_total_montant" value="0">
          <button type="button" id="btnContinuer" onclick="continuer()"
            class="btn btn-primary" style="width:100%;justify-content:center;opacity:.4;pointer-events:none">
            Vérifier la commande →
          </button>
        </form>
      </div>
    </div>
  </div>

</div>

<script>
// ── État du panier ────────────────────────────────────────
const panier = {}; // { prod_id: { nom, casiers, bouteilles, vol, prix, consigne } }
const SOLDE_CONSIGNE = <?= $solde_consigne ?>;
const CLIENT_PAIEMENT = '<?= $client_paiement ?>';
const CONSIGNE_ELIGIBLE = <?= in_array($client_type, ['DEMI_GROS','DISTRIBUTEUR','STATION','GMS'], true) ? 'true' : 'false' ?>;

function toggleProd(card) {
  const id = card.dataset.id;
  const qtyDiv = card.querySelector('.prod-qty');
  const check  = card.querySelector('.prod-check');

  if (qtyDiv.style.display === 'none') {
    // Ouvrir
    qtyDiv.style.display = '';
    card.style.borderColor = 'var(--red)';
    card.style.background  = 'var(--bg-solid-sel)';
    check.style.background  = 'var(--red)';
    check.style.borderColor = 'var(--red)';
    check.textContent = '✓';
    check.style.color = '#fff';
    // Init panier
    if (!panier[id]) {
      panier[id] = {
        nom:      card.querySelector('[style*="font-weight:600"]').textContent.trim(),
        code:     card.dataset.id,
        casiers:  0,
        bouteilles:0,
        vol:      parseFloat(card.dataset.vol),
        pag_kit:  parseFloat(card.dataset.pagKit),
        pag_nu:   parseFloat(card.dataset.pagNu),
        consigne_b:parseFloat(card.dataset.consigneB),
        consigne_c:parseFloat(card.dataset.consigneC),
        kit:      parseInt(card.dataset.kit),
      };
    }
  } else {
    // Fermer → retirer du panier
    qtyDiv.style.display = 'none';
    card.style.borderColor = 'var(--border)';
    card.style.background  = 'var(--bg-solid)';
    check.style.background  = '';
    check.style.borderColor = 'var(--border)';
    check.textContent = '';
    document.getElementById('qty_c_' + id).value = 0;
    document.getElementById('qty_b_' + id).value = 0;
    delete panier[id];
    updateTotaux();
    renderPanier();
  }
}

function changeQty(id, type, delta) {
  const input = document.getElementById('qty_' + type + '_' + id);
  let val = parseInt(input.value) + delta;
  if (val < 0) val = 0;
  // Max bouteilles = kit-1
  if (type === 'b') {
    const max = parseInt(input.max);
    if (val > max) val = max;
  }
  input.value = val;
  updatePanier(id);
}

function updatePanier(id) {
  if (!panier[id]) return;
  const c = parseInt(document.getElementById('qty_c_' + id).value) || 0;
  const b = parseInt(document.getElementById('qty_b_' + id).value) || 0;
  panier[id].casiers    = c;
  panier[id].bouteilles = b;

  // Sous-total ligne
  const p = panier[id];
  const prix_casiers = c * p.pag_kit;
  const prix_btl     = b * p.pag_nu;
  const csg_c        = c * p.consigne_c;
  const csg_b        = b * p.consigne_b;
  const sous_total   = prix_casiers + prix_btl + csg_c + csg_b;

  const stEl = document.getElementById('sous_total_' + id);
  if (sous_total > 0) {
    stEl.textContent = 'Sous-total : ' + fmt(sous_total) + ' Ar';
  } else {
    stEl.textContent = '';
  }

  updateTotaux();
  renderPanier();
}

function updateTotaux() {
  let total_hl = 0, total_prod = 0, total_csg = 0;

  Object.values(panier).forEach(p => {
    total_hl   += p.casiers * p.vol + p.bouteilles * (p.vol / p.kit);
    total_prod += p.casiers * p.pag_kit + p.bouteilles * p.pag_nu;
    total_csg  += p.casiers * p.consigne_c + p.bouteilles * p.consigne_b;
  });

  const credit = CONSIGNE_ELIGIBLE ? Math.min(SOLDE_CONSIGNE, total_csg) : 0;
  const total_final = total_prod + total_csg - credit;

  document.getElementById('total-hl').textContent    = total_hl.toFixed(4).replace('.',',') + ' hl';
  document.getElementById('total-prod').textContent  = fmt(total_prod) + ' Ar';
  if (document.getElementById('total-consigne'))
    document.getElementById('total-consigne').textContent = fmt(total_csg) + ' Ar';
  document.getElementById('total-final').textContent = fmt(total_final) + ' Ar';

  // Hidden inputs pour le form
  document.getElementById('input_total_hl').value      = total_hl.toFixed(4);
  document.getElementById('input_total_montant').value = total_final.toFixed(2);
  document.getElementById('panier_json').value = JSON.stringify(
    Object.entries(panier).map(([id, p]) => ({
      produit_id: id, ...p
    }))
  );

  // Activer bouton
  const hasItems = Object.values(panier).some(p => p.casiers > 0 || p.bouteilles > 0);
  const btn = document.getElementById('btnContinuer');
  btn.style.opacity = hasItems ? '1' : '.4';
  btn.style.pointerEvents = hasItems ? 'auto' : 'none';
}

function renderPanier() {
  const container = document.getElementById('panier-items');
  const empty     = document.getElementById('panier-empty');
  const count     = document.getElementById('panier-count');
  const items     = Object.entries(panier).filter(([,p]) => p.casiers > 0 || p.bouteilles > 0);

  count.textContent = items.length + ' produit' + (items.length > 1 ? 's' : '');

  if (items.length === 0) {
    empty.style.display = '';
    return;
  }
  empty.style.display = 'none';

  // Garder le div empty, remplacer le reste
  const existing = container.querySelectorAll('.panier-item');
  existing.forEach(e => e.remove());

  items.forEach(([id, p]) => {
    const sous = p.casiers * p.pag_kit + p.bouteilles * p.pag_nu
               + p.casiers * p.consigne_c + p.bouteilles * p.consigne_b;
    const div = document.createElement('div');
    div.className = 'panier-item';
    div.style.cssText = 'padding:.5rem 0;border-bottom:1px solid var(--bg3);font-size:.75rem';
    div.innerHTML = `
      <div style="font-weight:600;color:var(--text);margin-bottom:.2rem">${p.nom}</div>
      <div style="display:flex;justify-content:space-between;color:var(--text-mute)">
        <span>${p.casiers > 0 ? p.casiers + ' casier(s)' : ''}${p.casiers > 0 && p.bouteilles > 0 ? ' + ' : ''}${p.bouteilles > 0 ? p.bouteilles + ' btl' : ''}</span>
        <span style="color:var(--red);font-weight:600">${fmt(sous)} Ar</span>
      </div>
    `;
    container.appendChild(div);
  });
}

function continuer() {
  const hasItems = Object.values(panier).some(p => p.casiers > 0 || p.bouteilles > 0);
  if (!hasItems) return;
  document.getElementById('formCommande').submit();
}

// ── Filtres ───────────────────────────────────────────────
function filterProds(q) {
  q = q.toLowerCase().trim();
  document.querySelectorAll('.prod-card').forEach(c => {
    c.style.display = (!q || c.dataset.nom.includes(q)) ? '' : 'none';
  });
}

function filterFamille(f, btn) {
  document.querySelectorAll('.famille-btn').forEach(b => {
    b.className = 'btn btn-secondary btn-sm famille-btn';
  });
  btn.className = 'btn btn-primary btn-sm famille-btn';

  document.querySelectorAll('.famille-section').forEach(s => {
    s.style.display = (f === 'all' || s.dataset.famille === f) ? '' : 'none';
  });
}

function fmt(n) {
  return Math.round(n).toLocaleString('fr-FR');
}
</script>

<?php close_layout(); ?>

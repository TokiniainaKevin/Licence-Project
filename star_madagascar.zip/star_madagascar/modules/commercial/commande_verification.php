<?php
// ============================================================
// modules/commercial/commande_verification.php
// Prise de commande — Étape 3 : Double vérification
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/tarifs.php';

$ctx  = include_layout('Vérification commande', ['COMMERCIAL','MANAGER','MANAGER_INTERIM']);
$user = $ctx['user'];
$db   = getDB();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: commande.php');
  exit;
}

$client_id = (int)($_POST['client_id'] ?? 0);
// Client relu en base (et non depuis les champs cachés du formulaire)
$stmt = $db->prepare("SELECT * FROM clients WHERE id=? AND statut='ACTIF' AND (secteur_id=? OR ? IS NULL)"); // client du secteur uniquement
$stmt->execute([$client_id, $user['secteur'], $user['secteur']]);
$cl_db = $stmt->fetch();
if (!$cl_db) { header('Location: commande.php'); exit; }
$client_nom      = htmlspecialchars($cl_db['nom']);
$client_code     = htmlspecialchars($cl_db['code_client'] ?? '');
$client_type     = htmlspecialchars($cl_db['type']);
$client_paiement = htmlspecialchars($cl_db['type_paiement'] ?? '');
$panier_json     = $_POST['panier_json'] ?? '[]';
$total_hl        = (float)($_POST['total_hl'] ?? 0);
$total_montant   = (float)($_POST['total_montant'] ?? 0);

$panier = json_decode($panier_json, true) ?? [];
$panier = array_filter($panier, fn($p) => ($p['casiers'] ?? 0) > 0 || ($p['bouteilles'] ?? 0) > 0);

if (empty($panier)) {
  header('Location: commande.php');
  exit;
}

// Récupérer infos produits depuis la BD pour vérification
$ids = array_column($panier, 'produit_id');
$placeholders = implode(',', array_fill(0, count($ids), '?'));
$stmt = $db->prepare("SELECT * FROM produits WHERE id IN ($placeholders)");
$stmt->execute($ids);
$produits_db = $stmt->fetchAll(PDO::FETCH_UNIQUE);

// Solde consigne — seuls les DEMI_GROS, DISTRIBUTEUR, STATION et GMS ont un
// compte consigne (voir modules/logistique/consignes.php).
$consigne_eligible = in_array($client_type, ['DEMI_GROS','DISTRIBUTEUR','STATION','GMS'], true);
$solde_consigne = 0;
if ($consigne_eligible) {
  $stmt = $db->prepare("SELECT solde_ariary FROM solde_consigne WHERE client_id = ?");
  $stmt->execute([$client_id]);
  $sc = $stmt->fetch();
  $solde_consigne = $sc ? $sc['solde_ariary'] : 0;
}

// Recalculer totaux côté serveur (sécurité)
$total_hl_srv    = 0;
$total_prod_srv  = 0;
$total_csg_srv   = 0;

foreach ($panier as &$ligne) {
  $pid = $ligne['produit_id'];
  if (!isset($produits_db[$pid])) continue;
  $p = $produits_db[$pid];

  $c = (int)($ligne['casiers'] ?? 0);
  $b = (int)($ligne['bouteilles'] ?? 0);

  $ligne['description']  = $p['description'];
  $ligne['code']         = $p['code'];
  $ligne['kit']          = $p['kit'];
  $ligne['pag_kit']      = $p['pag_kit_nu'];
  $ligne['pag_nu']       = $p['pag_nu'];
  $ligne['consigne_c']   = consigne_casier_plein($p);
  $ligne['consigne_b']   = $p['consigne_bouteille'];
  $ligne['vol_unit']     = $p['volume_hl'];

  $k = calcul_ligne($p, $c, $b);
  $vol_ligne   = $k['vol'];
  $prix_ligne  = $k['prix'];
  $csg_ligne   = $k['csg'];

  $ligne['vol_ligne']  = $vol_ligne;
  $ligne['prix_ligne'] = $prix_ligne;
  $ligne['csg_ligne']  = $csg_ligne;
  $ligne['total_ligne']= $prix_ligne + $csg_ligne;

  $total_hl_srv   += $vol_ligne;
  $total_prod_srv += $prix_ligne;
  $total_csg_srv  += $csg_ligne;
}
unset($ligne);

$credit_consigne  = $consigne_eligible ? min($solde_consigne, $total_csg_srv) : 0;
$montant_final    = $total_prod_srv + $total_csg_srv - $credit_consigne;
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Vérification de la commande</div>
      <div class="page-subtitle">Relisez attentivement avant de confirmer — cette action est irréversible</div>
    </div>
  </div>
</div>

<!-- Étapes -->
<div style="display:flex;align-items:center;gap:0;margin-bottom:1.6rem">
  <?php
  $steps = ['Sélection client', 'Saisie commande', 'Vérification', 'Confirmation'];
  foreach ($steps as $i => $s):
    $done   = $i < 2;
    $active = $i === 2;
  ?>
  <div style="display:flex;align-items:center;flex:1">
    <div style="display:flex;align-items:center;gap:.5rem;flex:1">
      <div style="
        width:28px;height:28px;border-radius:50%;
        background:<?= $done ? 'rgba(0,200,100,.2)' : ($active ? 'var(--red)' : 'var(--bg3)') ?>;
        border:1px solid <?= $done ? '#00c864' : ($active ? 'var(--red)' : 'var(--border)') ?>;
        display:flex;align-items:center;justify-content:center;
        font-size:.7rem;font-weight:700;flex-shrink:0;
        color:<?= $done ? '#00c864' : ($active ? '#fff' : 'var(--text-mute)') ?>
      "><?= $done ? '✓' : ($i+1) ?></div>
      <span style="font-size:.75rem;font-weight:<?= $active ? '600' : '400' ?>;color:<?= $active ? 'var(--text)' : ($done ? '#00c864' : 'var(--text-mute)') ?>"><?= $s ?></span>
    </div>
    <?php if ($i < count($steps)-1): ?>
      <div style="height:1px;flex:1;background:var(--border);margin:0 .5rem"></div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<div style="display:grid;grid-template-columns:1fr 300px;gap:1rem;align-items:start">

  <!-- Détail commande -->
  <div>

    <!-- Infos client -->
    <div class="card" style="margin-bottom:1rem;padding:1rem 1.2rem">
      <div style="font-size:.72rem;color:var(--text-mute);font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:.7rem">
        Client
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <div style="font-size:1rem;font-weight:700;color:var(--text)"><?= $client_nom ?></div>
          <div style="font-size:.75rem;color:var(--text-mute);margin-top:.2rem">
            <?= $client_code ?> · <?= type_label($client_type) ?> ·
            <?= $client_paiement === 'AGENCE' ? '🏦 Paiement à l\'agence' : '💵 Paiement au distributeur' ?>
          </div>
        </div>
        <div style="text-align:right">
          <div style="font-size:.7rem;color:var(--text-mute)">Date de commande</div>
          <div style="font-size:.82rem;font-weight:600"><?= date('d/m/Y H:i') ?></div>
          <div style="font-size:.68rem;color:var(--text-mute)">Livraison : <?= date('d/m/Y', strtotime('+1 day')) ?></div>
        </div>
      </div>
    </div>

    <!-- Tableau produits -->
    <div class="card" style="padding:0;overflow:hidden">
      <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:.85rem;font-weight:600">
        Détail des produits
      </div>
      <table class="data-table">
        <thead>
          <tr>
            <th>Produit</th>
            <th style="text-align:center">Casiers</th>
            <th style="text-align:center">Bouteilles</th>
            <th style="text-align:right">Volume</th>
            <th style="text-align:right">Prix produit</th>
            <th style="text-align:right">Consigne</th>
            <th style="text-align:right">Total ligne</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($panier as $ligne): ?>
          <tr>
            <td>
              <div style="font-weight:600;color:var(--text);font-size:.8rem"><?= htmlspecialchars($ligne['description']) ?></div>
              <div style="font-size:.65rem;color:var(--text-mute)"><?= htmlspecialchars($ligne['code']) ?></div>
            </td>
            <td style="text-align:center;font-weight:600"><?= $ligne['casiers'] ?></td>
            <td style="text-align:center"><?= $ligne['bouteilles'] ?: '—' ?></td>
            <td style="text-align:right;color:var(--red);font-weight:600"><?= number_format($ligne['vol_ligne'],4) ?> hl</td>
            <td style="text-align:right"><?= number_format($ligne['prix_ligne']) ?> Ar</td>
            <td style="text-align:right;color:var(--text-mute)"><?= $ligne['csg_ligne'] > 0 ? number_format($ligne['csg_ligne']).' Ar' : '—' ?></td>
            <td style="text-align:right;font-weight:600;color:var(--text)"><?= number_format($ligne['total_ligne']) ?> Ar</td>
          </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr style="background:var(--bg3)">
            <td colspan="3" style="font-weight:600;font-size:.78rem">TOTAL</td>
            <td style="text-align:right;font-weight:700;color:var(--red)"><?= number_format($total_hl_srv,4) ?> hl</td>
            <td style="text-align:right;font-weight:600"><?= number_format($total_prod_srv) ?> Ar</td>
            <td style="text-align:right;font-weight:600"><?= number_format($total_csg_srv) ?> Ar</td>
            <td style="text-align:right;font-weight:700;font-size:.9rem"><?= number_format($total_prod_srv + $total_csg_srv) ?> Ar</td>
          </tr>
        </tfoot>
      </table>
    </div>

  </div>

  <!-- Résumé + confirmation -->
  <div style="display:flex;flex-direction:column;gap:.8rem">

    <!-- Récap financier -->
    <div class="card card-top-line">
      <div style="font-size:.72rem;color:var(--text-mute);font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:.9rem">
        Récapitulatif
      </div>
      <div style="display:flex;flex-direction:column;gap:.5rem">
        <div style="display:flex;justify-content:space-between;font-size:.78rem">
          <span style="color:var(--text-mute)">Volume total</span>
          <span style="font-weight:700;color:var(--red)"><?= number_format($total_hl_srv,4) ?> hl</span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:.78rem">
          <span style="color:var(--text-mute)">Produits</span>
          <span><?= number_format($total_prod_srv) ?> Ar</span>
        </div>
        <?php if ($total_csg_srv > 0): ?>
        <div style="display:flex;justify-content:space-between;font-size:.78rem">
          <span style="color:var(--text-mute)">Consigne</span>
          <span><?= number_format($total_csg_srv) ?> Ar</span>
        </div>
        <?php endif; ?>
        <?php if ($credit_consigne > 0): ?>
        <div style="display:flex;justify-content:space-between;font-size:.78rem;color:#00c864">
          <span>Crédit consigne</span>
          <span>−<?= number_format($credit_consigne) ?> Ar</span>
        </div>
        <?php endif; ?>
        <div style="height:1px;background:var(--border);margin:.3rem 0"></div>
        <div style="display:flex;justify-content:space-between;font-size:.9rem">
          <span style="font-weight:700">À PAYER</span>
          <span style="font-weight:700;color:var(--red);font-size:1.1rem"><?= number_format($montant_final) ?> Ar</span>
        </div>
      </div>
    </div>

    <!-- Avertissement irréversible -->
    <div style="background:rgba(232,0,28,.06);border:1px solid rgba(232,0,28,.2);
                border-radius:10px;padding:.9rem;font-size:.75rem;color:#ff8888;line-height:1.5">
      ⚠️ <strong>Attention</strong> — Une fois confirmée, cette commande ne peut plus être modifiée ni annulée.
      <br><br>
      Vérifiez bien les quantités et le client avant de confirmer.
    </div>

    <!-- Boutons -->
    <form method="POST" action="commande_confirmer.php" id="formFinal">
      <input type="hidden" name="client_id"       value="<?= $client_id ?>">
      <input type="hidden" name="client_nom"      value="<?= $client_nom ?>">
      <input type="hidden" name="client_code"     value="<?= $client_code ?>">
      <input type="hidden" name="client_type"     value="<?= $client_type ?>">
      <input type="hidden" name="client_paiement" value="<?= $client_paiement ?>">
      <input type="hidden" name="panier_json"     value="<?= htmlspecialchars($panier_json) ?>">
      <input type="hidden" name="total_hl"        value="<?= $total_hl_srv ?>">
      <input type="hidden" name="total_montant"   value="<?= $montant_final ?>">
      <input type="hidden" name="total_prod"      value="<?= $total_prod_srv ?>">
      <input type="hidden" name="total_csg"       value="<?= $total_csg_srv ?>">
      <input type="hidden" name="credit_csg"      value="<?= $credit_consigne ?>">

      <div style="display:flex;flex-direction:column;gap:.5rem">
        <button type="button" onclick="history.back()" class="btn btn-secondary" style="width:100%;justify-content:center">
          ← Modifier la commande
        </button>
        <button type="button" onclick="confirmer()" class="btn btn-primary" style="width:100%;justify-content:center">
          ✅ Confirmer définitivement
        </button>
      </div>
    </form>

  </div>
</div>

<!-- Modal confirmation finale -->
<div id="modalConfirm" style="display:none;position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.8);backdrop-filter:blur(4px);
  align-items:center;justify-content:center">
  <div class="modal-box" style="border:1px solid var(--red);border-radius:16px;
              padding:1.8rem;max-width:380px;width:90%;text-align:center">
    <div style="font-size:2rem;margin-bottom:.8rem">⚠️</div>
    <div style="font-family:'Space Grotesk',sans-serif;font-size:1.1rem;font-weight:700;margin-bottom:.5rem">
      Confirmer la commande ?
    </div>
    <div style="font-size:.8rem;color:var(--text-mute);margin-bottom:1.4rem;line-height:1.5">
      Cette action est <strong style="color:var(--red)">définitive et irréversible</strong>.<br>
      La commande sera transmise au distributeur.
    </div>
    <div style="display:flex;gap:.7rem">
      <button onclick="closeModal()" class="btn btn-secondary" style="flex:1;justify-content:center">Annuler</button>
      <button onclick="document.getElementById('formFinal').submit()"
              class="btn btn-primary" style="flex:1;justify-content:center">Oui, confirmer</button>
    </div>
  </div>
</div>

<script>
function confirmer() {
  document.getElementById('modalConfirm').style.display = 'flex';
}
function closeModal() {
  document.getElementById('modalConfirm').style.display = 'none';
}
document.getElementById('modalConfirm').addEventListener('click', function(e) {
  if (e.target === this) closeModal();
});
</script>

<?php
function type_label(string $t): string {
  $map = [
    'DISTRIBUTEUR'=>'Distributeur','GMS'=>'GMS','STATION'=>'Station',
    'DEMI_GROS'=>'Demi-gros','EPICERIE'=>'Épicerie','BAR'=>'Bar','RESTAURANT'=>'Restaurant'
  ];
  return $map[$t] ?? $t;
}
close_layout();
?>

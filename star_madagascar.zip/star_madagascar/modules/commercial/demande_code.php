<?php
// ============================================================
// modules/commercial/demande_code.php
// Demande de code client pour nouveau client
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Nouveau client', ['COMMERCIAL','MANAGER','MANAGER_INTERIM']);
$user = $ctx['user'];
$db   = getDB();

// Secteur du commercial
$stmt = $db->prepare("
  SELECT s.id, s.nom, s.zone FROM secteurs s
  JOIN utilisateurs u ON u.secteur_id = s.id
  WHERE u.id = ?
");
$stmt->execute([$user['id']]);
$secteurs = $stmt->fetchAll();

// Mes demandes en cours (= mes clients créés via ce formulaire, quel que soit leur statut)
$stmt = $db->prepare("
  SELECT c.*, c.code_client AS code_attribue, s.nom AS secteur_nom
  FROM clients c
  LEFT JOIN secteurs s ON c.secteur_id = s.id
  WHERE c.demandeur_id = ?
  ORDER BY c.created_at DESC LIMIT 10
");
$stmt->execute([$user['id']]);
$mes_demandes = $stmt->fetchAll();

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nom       = trim($_POST['nom'] ?? '');
  $type      = $_POST['type'] ?? '';
  $adresse   = trim($_POST['adresse'] ?? '');
  $quartier  = trim($_POST['quartier'] ?? '');
  $secteur_id= (int)($_POST['secteur_id'] ?? 0);
  $telephone = trim($_POST['telephone'] ?? '');

  $types_valides = ['DISTRIBUTEUR','GMS','STATION','DEMI_GROS','EPICERIE','BAR','RESTAURANT'];

  if ($nom && in_array($type, $types_valides) && $adresse) {
    // Trouver manager
    $stmt = $db->prepare("
      SELECT u.id FROM utilisateurs u
      JOIN utilisateurs com ON com.secteur_id = u.secteur_id
      WHERE com.id = ? AND u.role IN ('MANAGER','MANAGER_INTERIM')
      LIMIT 1
    ");
    $stmt->execute([$user['id']]);
    $manager = $stmt->fetch();

    try {
      $stmt = $db->prepare("
        INSERT INTO clients
          (nom, type, adresse, quartier, secteur_id, telephone, demandeur_id, manager_id, statut)
        VALUES (?,?,?,?,?,?,?,?,'EN_ATTENTE')
      ");
      $stmt->execute([
        $nom, $type, $adresse, $quartier ?: null,
        $secteur_id ?: null, $telephone ?: null,
        $user['id'], $manager ? $manager['id'] : null
      ]);
      $demande_id = $db->lastInsertId();

      // Notifier manager
      if ($manager) {
        $stmt = $db->prepare("
          INSERT INTO notifications (utilisateur_id, titre, message, type, reference_id)
          VALUES (?,?,?,'CODE_CLIENT',?)
        ");
        $stmt->execute([
          $manager['id'],
          'Demande de code client',
          "Nouveau client à valider : $nom ($type) — demandé par {$user['nom']}",
          $demande_id
        ]);
      }

      $success = "Demande envoyée avec succès ! Votre manager sera notifié.";
    } catch (Exception $e) {
      $error = "Erreur lors de l'envoi de la demande.";
    }
  } else {
    $error = "Veuillez remplir tous les champs obligatoires.";
  }
}

$badge_statut = function(string $s): string {
  return match($s) {
    'EN_ATTENTE'      => "<span class='badge badge-orange'>En attente</span>",
    'VALIDE_MANAGER'  => "<span class='badge badge-blue'>Validé manager</span>",
    'ACTIF'           => "<span class='badge badge-green'>Approuvé ✓</span>",
    'REJETE'          => "<span class='badge badge-red'>Rejeté</span>",
    default           => "<span class='badge badge-mute'>$s</span>",
  };
};
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Demande de code client</div>
      <div class="page-subtitle">Pour les nouveaux clients qui n'ont pas encore de code</div>
    </div>
    <a href="dashboard.php" class="btn btn-secondary">← Retour</a>
  </div>
</div>

<?php if ($success): ?>
<div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;align-items:start">

  <!-- Formulaire -->
  <div class="card">
    <div style="font-size:.85rem;font-weight:600;margin-bottom:1.2rem">Informations du nouveau client</div>
    <form method="POST" style="display:flex;flex-direction:column;gap:.9rem">

      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Nom du commerce *</label>
        <input type="text" name="nom" required placeholder="Ex: Épicerie Rabe, Bar chez Soa..."
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.7rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif"
          onfocus="this.style.borderColor='var(--red)'"
          onblur="this.style.borderColor='var(--border)'">
      </div>

      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Type de client *</label>
        <select name="type" required
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.7rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
          <option value="">Sélectionner...</option>
          <option value="EPICERIE">Épicerie</option>
          <option value="BAR">Bar</option>
          <option value="RESTAURANT">Restaurant</option>
          <option value="STATION">Station service</option>
          <option value="GMS">Grande/Moyenne Surface</option>
          <option value="DEMI_GROS">Demi-Gros</option>
          <option value="DISTRIBUTEUR">Distributeur</option>
        </select>
      </div>

      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Adresse complète *</label>
        <textarea name="adresse" required rows="2"
          placeholder="Adresse complète du commerce..."
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.7rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif;resize:vertical"
          onfocus="this.style.borderColor='var(--red)'"
          onblur="this.style.borderColor='var(--border)'"></textarea>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem">
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Quartier</label>
          <input type="text" name="quartier" placeholder="Ex: Ankofafa, Centre-ville..."
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.65rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif"
            onfocus="this.style.borderColor='var(--red)'"
            onblur="this.style.borderColor='var(--border)'">
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Téléphone</label>
          <input type="tel" name="telephone" placeholder="034 XX XXX XX"
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.65rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif"
            onfocus="this.style.borderColor='var(--red)'"
            onblur="this.style.borderColor='var(--border)'">
        </div>
      </div>

      <?php if (!empty($secteurs)): ?>
      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Secteur</label>
        <select name="secteur_id"
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.7rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
          <option value="">Sélectionner un secteur...</option>
          <?php foreach ($secteurs as $s): ?>
          <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['nom']) ?> — <?= htmlspecialchars($s['zone']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <?php endif; ?>

      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:.4rem">
        🆔 Envoyer la demande au manager
      </button>
    </form>
  </div>

  <!-- Mes demandes -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:.85rem;font-weight:600">
      Mes demandes récentes
    </div>
    <?php if (empty($mes_demandes)): ?>
    <div style="padding:2rem;text-align:center;color:var(--text-mute);font-size:.82rem">
      Aucune demande envoyée pour l'instant.
    </div>
    <?php else: ?>
    <?php foreach ($mes_demandes as $d): ?>
    <div style="padding:.8rem 1.2rem;border-bottom:1px solid var(--bg3)">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.3rem">
        <div style="font-weight:600;font-size:.82rem"><?= htmlspecialchars($d['nom']) ?></div>
        <?= $badge_statut($d['statut']) ?>
      </div>
      <div style="font-size:.7rem;color:var(--text-mute)">
        <?= htmlspecialchars($d['type']) ?> ·
        <?= htmlspecialchars($d['quartier'] ?? '') ?> ·
        <?= date('d/m/Y', strtotime($d['created_at'])) ?>
      </div>
      <?php if ($d['statut'] === 'APPROUVE' && $d['code_attribue']): ?>
      <div style="margin-top:.4rem;font-size:.75rem;color:#00c864;font-weight:600">
        ✓ Code attribué : <?= htmlspecialchars($d['code_attribue']) ?>
      </div>
      <?php elseif ($d['statut'] === 'REJETE' && $d['motif_rejet']): ?>
      <div style="margin-top:.4rem;font-size:.72rem;color:var(--red)">
        ✗ <?= htmlspecialchars($d['motif_rejet']) ?>
      </div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

</div>

<?php close_layout(); ?>

<?php
// ============================================================
// modules/admin/codes_clients.php
// Attribution finale des codes clients
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx = include_layout('Codes clients', ['ADMIN']);
$user = $ctx['user'];
$db   = getDB();

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action     = $_POST['action'] ?? '';
  $demande_id = (int)($_POST['demande_id'] ?? 0);
  $code       = strtoupper(trim($_POST['code'] ?? ''));

  if ($action === 'attribuer' && $demande_id && $code) {
    $stmt = $db->prepare("SELECT * FROM clients WHERE id=? AND statut='VALIDE_MANAGER'");
    $stmt->execute([$demande_id]);
    $d = $stmt->fetch();

    if ($d) {
      try {
        $type_paiement = in_array($d['type'], ['DISTRIBUTEUR','GMS','STATION','DEMI_GROS'])
          ? 'AGENCE' : 'DISTRIBUTEUR';

        $stmt = $db->prepare("
          UPDATE clients SET code_client=?, type_paiement=?, statut='ACTIF' WHERE id=?
        ");
        $stmt->execute([$code, $type_paiement, $demande_id]);

        // Notifier commercial
        $stmt = $db->prepare("
          INSERT INTO notifications (utilisateur_id,titre,message,type,reference_id)
          VALUES (?,?,?,'CODE_CLIENT',?)
        ");
        $stmt->execute([
          $d['demandeur_id'],
          'Code client attribué ✓',
          "Code $code attribué à {$d['nom']}. Vous pouvez le remettre au client.",
          $demande_id
        ]);

        $msg = ['success', "Code $code attribué à {$d['nom']}."];
      } catch (Exception $e) {
        $msg = ['error', 'Code déjà utilisé ou erreur : '.$e->getMessage()];
      }
    }
  } elseif ($action === 'rejeter' && $demande_id) {
    $motif = trim($_POST['motif'] ?? 'Demande rejetée.');
    $db->prepare("UPDATE clients SET statut='REJETE',motif_rejet=? WHERE id=?")
      ->execute([$motif,$demande_id]);
    $msg = ['success', 'Demande rejetée.'];
  }
}

// Demandes en attente d'attribution (validées par manager)
$en_attente = $db->query("
  SELECT d.*, CONCAT(u.prenom,' ',u.nom) AS commercial_nom,
         s.nom AS secteur_nom
  FROM clients d
  JOIN utilisateurs u ON d.demandeur_id = u.id
  LEFT JOIN secteurs s ON d.secteur_id = s.id
  WHERE d.statut = 'VALIDE_MANAGER'
  ORDER BY d.created_at ASC
")->fetchAll();

// Historique
$historique = $db->query("
  SELECT d.*, CONCAT(u.prenom,' ',u.nom) AS commercial_nom
  FROM clients d
  JOIN utilisateurs u ON d.demandeur_id = u.id
  WHERE d.statut IN ('ACTIF','REJETE') AND d.demandeur_id IS NOT NULL
  ORDER BY d.created_at DESC LIMIT 30
")->fetchAll();
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Attribution des codes clients</div>
      <div class="page-subtitle"><?= count($en_attente) ?> demande(s) à traiter</div>
    </div>
  </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-<?= $msg[0]==='success'?'success':'error' ?>">
  <?= $msg[0]==='success'?'✅':'❌' ?> <?= htmlspecialchars($msg[1]) ?>
</div>
<?php endif; ?>

<?php if (empty($en_attente)): ?>
<div class="card" style="text-align:center;padding:3rem;margin-bottom:1.2rem">
  <div style="font-size:2rem;margin-bottom:.8rem">✅</div>
  <div style="font-weight:600">Aucune demande en attente.</div>
</div>
<?php else: ?>
<?php foreach ($en_attente as $d): ?>
<div class="card" style="margin-bottom:.8rem;border-color:rgba(255,160,0,.3)">
  <div style="display:grid;grid-template-columns:1fr auto;gap:1.2rem;align-items:center">
    <div>
      <div style="font-size:.95rem;font-weight:700;margin-bottom:.3rem"><?= htmlspecialchars($d['nom']) ?></div>
      <div style="display:flex;gap:1.2rem;flex-wrap:wrap;font-size:.74rem;color:var(--text-mute);margin-bottom:.3rem">
        <span>Type : <strong style="color:var(--text)"><?= $d['type'] ?></strong></span>
        <span>Quartier : <strong style="color:var(--text)"><?= htmlspecialchars($d['quartier']??'—') ?></strong></span>
        <span>Secteur : <strong style="color:var(--text)"><?= htmlspecialchars($d['secteur_nom']??'—') ?></strong></span>
        <?php if ($d['telephone']): ?>
        <span>Tél : <strong style="color:var(--text)"><?= htmlspecialchars($d['telephone']) ?></strong></span>
        <?php endif; ?>
      </div>
      <div style="font-size:.72rem;color:var(--text-mute)">
        Adresse : <?= htmlspecialchars($d['adresse']) ?>
      </div>
      <div style="font-size:.7rem;color:var(--text-mute);margin-top:.3rem">
        Demandé par <strong><?= htmlspecialchars($d['commercial_nom']) ?></strong>
        le <?= date('d/m/Y', strtotime($d['created_at'])) ?>
      </div>
    </div>
    <div style="display:flex;flex-direction:column;gap:.5rem;min-width:200px">
      <form method="POST" style="display:flex;gap:.4rem;align-items:center">
        <input type="hidden" name="action" value="attribuer">
        <input type="hidden" name="demande_id" value="<?= $d['id'] ?>">
        <input type="text" name="code" required
          placeholder="Code client"
          style="flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.5rem .7rem;color:var(--text);font-size:.82rem;
                 font-family:Inter,sans-serif;text-transform:uppercase"
          oninput="this.value=this.value.toUpperCase()">
        <button type="submit" class="btn btn-primary btn-sm">✓</button>
      </form>
      <form method="POST" style="display:flex;gap:.4rem">
        <input type="hidden" name="action" value="rejeter">
        <input type="hidden" name="demande_id" value="<?= $d['id'] ?>">
        <input type="text" name="motif" placeholder="Motif rejet..."
          style="flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.5rem .7rem;color:var(--text);font-size:.78rem;font-family:Inter,sans-serif">
        <button type="submit" class="btn btn-secondary btn-sm" style="color:var(--red)">✗</button>
      </form>
    </div>
  </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<!-- Historique -->
<?php if (!empty($historique)): ?>
<div class="card" style="padding:0;overflow:hidden;margin-top:1rem">
  <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:.85rem;font-weight:600">
    Historique
  </div>
  <table class="data-table">
    <thead>
      <tr><th>Client</th><th>Type</th><th>Commercial</th><th>Code attribué</th><th>Statut</th><th>Date</th></tr>
    </thead>
    <tbody>
      <?php foreach ($historique as $d): ?>
      <tr>
        <td style="font-weight:500"><?= htmlspecialchars($d['nom']) ?></td>
        <td style="font-size:.72rem"><?= $d['type'] ?></td>
        <td style="font-size:.75rem"><?= htmlspecialchars($d['commercial_nom']) ?></td>
        <td style="font-family:monospace;font-weight:700;color:var(--red)">
          <?= $d['code_client'] ? htmlspecialchars($d['code_client']) : '—' ?>
        </td>
        <td><?= $d['statut']==='ACTIF'
          ? "<span class='badge badge-green'>Approuvé</span>"
          : "<span class='badge badge-red'>Rejeté</span>" ?>
        </td>
        <td style="font-size:.72rem"><?= date('d/m/Y', strtotime($d['created_at'])) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<?php close_layout(); ?>

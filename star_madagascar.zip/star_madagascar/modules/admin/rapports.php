<?php require_once '../../includes/layout.php'; require_once '../../config/db.php'; $ctx=include_layout('Rapports',['ADMIN','DIRECTEUR']); $db=getDB();
$rows=$db->query("SELECT DATE(date_commande) jour,COUNT(*) commandes,COALESCE(SUM(total_hl),0) hl,COALESCE(SUM(montant_total),0) montant FROM commandes WHERE date_commande>=DATE_SUB(CURDATE(),INTERVAL 30 DAY) AND statut NOT IN ('CREEE') GROUP BY DATE(date_commande) ORDER BY jour DESC")->fetchAll(); ?>
<div class="page-header"><div class="page-title">Rapports</div><div class="page-subtitle">Synthèse des commandes sur 30 jours</div></div><div class="card" style="padding:0;overflow:hidden"><table class="data-table"><thead><tr><th>Date</th><th>Commandes</th><th>HL</th><th>Montant</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?=date('d/m/Y',strtotime($r['jour']))?></td><td><?=$r['commandes']?></td><td><?=number_format($r['hl'],2)?> hl</td><td><?=number_format($r['montant'])?> Ar</td></tr><?php endforeach; ?></tbody></table></div><?php ?>
<!-- ── Graphiques ─────────────────────────────────────────── -->
<?php $rows_g = array_reverse($rows); ?>
<div style="margin-top:1rem">
<?= graphique('gRapport', 'Évolution sur 30 jours : volume et chiffre d’affaires', ['type'=>'line','data'=>['labels'=>array_map(fn($r)=>date('d/m',strtotime($r['jour'])),$rows_g),'datasets'=>[
  ['label'=>'Volume (hl)','data'=>array_map(fn($r)=>round((float)$r['hl'],2),$rows_g),'borderColor'=>'#E8001C','backgroundColor'=>'rgba(232,0,28,.15)','fill'=>true,'tension'=>.3,'yAxisID'=>'y'],
  ['label'=>'Montant (Ar)','data'=>array_map(fn($r)=>round((float)$r['montant']),$rows_g),'borderColor'=>'#E8AF34','tension'=>.3,'yAxisID'=>'y1','pointRadius'=>2],
]],'options'=>['scales'=>['y'=>['beginAtZero'=>true,'title'=>['display'=>true,'text'=>'hl']],'y1'=>['beginAtZero'=>true,'position'=>'right','grid'=>['drawOnChartArea'=>false],'title'=>['display'=>true,'text'=>'Ar']]]]], 320) ?>
</div>

<?php close_layout(); ?>

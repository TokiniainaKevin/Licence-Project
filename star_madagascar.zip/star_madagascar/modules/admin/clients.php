<?php
// ============================================================
// modules/admin/clients.php
// CRUD clients + attribution code client
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx = include_layout('Clients', ['ADMIN','DIRECTEUR']);
$user = $ctx['user'];
$db   = getDB();
$editable = ($user['role'] === 'ADMIN');

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $editable) {
  $action = $_POST['action'] ?? '';

  if ($action === 'creer_client' || $action === 'modifier_client') {
    $id=(int)($_POST['id']??0); $code=strtoupper(trim($_POST['code_client']??'')); $nom=trim($_POST['nom']??'');
    $type=$_POST['type']??''; $paiement=$_POST['type_paiement']??'AGENCE'; $adresse=trim($_POST['adresse']??'');
    $quartier=trim($_POST['quartier']??''); $secteur=(int)($_POST['secteur_id']??0)?:null; $tel=trim($_POST['telephone']??''); $email=trim($_POST['email']??'');
    $nif=trim($_POST['nif']??''); $stat=trim($_POST['stat']??''); $dist=(int)($_POST['distributeur_id']??0)?:null;
    // Un compte d'accès au site n'existe que pour les clients de type DISTRIBUTEUR.
    // Les épiceries, bars, restaurants, demi-gros, stations et GMS n'ont pas de compte.
    $compte_email = trim($_POST['compte_email'] ?? '');
    $compte_password = trim($_POST['compte_password'] ?? '');
    $types=['DISTRIBUTEUR','GMS','STATION','DEMI_GROS','EPICERIE','BAR','RESTAURANT'];
    $est_distributeur = ($type === 'DISTRIBUTEUR');
    // Clients directs : livrés directement par l'agence, sans distributeur intermédiaire.
    // Seuls les petits clients (épicerie, bar, restaurant) sont livrés par un distributeur/demi-gros.
    $est_client_direct = in_array($type, ['DISTRIBUTEUR','GMS','STATION','DEMI_GROS'], true);
    if ($est_client_direct) $dist = null;

    if(!$code||!$nom||!in_array($type,$types,true)||!$adresse||!in_array($paiement,['AGENCE','DISTRIBUTEUR'],true)) {
      $msg=['error','Champs obligatoires manquants ou invalides.'];
    } elseif ($est_distributeur && $action==='creer_client' && (!$compte_email || !$compte_password)) {
      $msg=['error','Un client Distributeur nécessite un email et un mot de passe pour son compte d\'accès.'];
    } else {
      try{
        $db->beginTransaction();

        if($action==='creer_client'){
          $uid = null;
          // Un distributeur reçoit directement son compte d'accès ici ; il n'a pas
          // de distributeur livreur qui lui est propre (il en est un lui-même).
          if ($est_distributeur) {
            $stmtU = $db->prepare("INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, telephone, role, statut_presence) VALUES (?,?,?,?,?,'DISTRIBUTEUR','EN_TRAVAIL')");
            $stmtU->execute([$nom, 'Distributeur', $compte_email, password_hash($compte_password, PASSWORD_DEFAULT), $tel ?: null]);
            $uid = $db->lastInsertId();
            $dist = null;
          }
          $db->prepare("INSERT INTO clients (code_client,nom,type,type_paiement,adresse,quartier,secteur_id,telephone,email,nif,stat,distributeur_id,utilisateur_id,statut) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'ACTIF')")
            ->execute([$code,$nom,$type,$paiement,$adresse,$quartier?:null,$secteur,$tel?:null,$email?:($compte_email?:null),$nif?:null,$stat?:null,$dist,$uid]);
          $msg=['success','Client créé avec succès.'];
        } else {
          // Récupérer l'état actuel du client pour gérer le compte lié
          $stmtC = $db->prepare("SELECT type, utilisateur_id FROM clients WHERE id=?");
          $stmtC->execute([$id]);
          $ancien = $stmtC->fetch();
          $uid = $ancien['utilisateur_id'] ?? null;

          if ($est_distributeur) {
            $dist = null;
            if ($uid) {
              // Compte déjà existant : on peut mettre à jour ses coordonnées / mot de passe
              if ($compte_password) {
                $db->prepare("UPDATE utilisateurs SET email=?, telephone=?, mot_de_passe=?, actif=1 WHERE id=?")
                  ->execute([$compte_email ?: $email, $tel ?: null, password_hash($compte_password, PASSWORD_DEFAULT), $uid]);
              } else {
                $db->prepare("UPDATE utilisateurs SET email=?, telephone=?, actif=1 WHERE id=?")
                  ->execute([$compte_email ?: $email, $tel ?: null, $uid]);
              }
            } elseif ($compte_email && $compte_password) {
              // Le client devient/était Distributeur sans compte : on le crée maintenant
              $stmtU = $db->prepare("INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, telephone, role, statut_presence) VALUES (?,?,?,?,?,'DISTRIBUTEUR','EN_TRAVAIL')");
              $stmtU->execute([$nom, 'Distributeur', $compte_email, password_hash($compte_password, PASSWORD_DEFAULT), $tel ?: null]);
              $uid = $db->lastInsertId();
            } else {
              throw new Exception("Un email et un mot de passe sont requis pour créer le compte d'accès de ce distributeur.");
            }
          } else {
            // Type non-distributeur : jamais de compte d'accès au site.
            // Si le client était un distributeur avant, on désactive son ancien compte.
            if ($uid) { $db->prepare("UPDATE utilisateurs SET actif=0 WHERE id=?")->execute([$uid]); }
            $uid = null;
          }

          $db->prepare("UPDATE clients SET code_client=?,nom=?,type=?,type_paiement=?,adresse=?,quartier=?,secteur_id=?,telephone=?,email=?,nif=?,stat=?,distributeur_id=?,utilisateur_id=? WHERE id=?")
            ->execute([$code,$nom,$type,$paiement,$adresse,$quartier?:null,$secteur,$tel?:null,$email?:null,$nif?:null,$stat?:null,$dist,$uid,$id]);
          $msg=['success','Client mis à jour.'];
        }

        $db->commit();
      } catch(Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $msg=['error','Erreur : '.$e->getMessage()];
      }
    }
  } elseif ($action === 'attribuer_code') {
    // Attribuer code à une demande (le client existe déjà, créé à la demande)
    $demande_id = (int)($_POST['demande_id'] ?? 0);
    $code       = strtoupper(trim($_POST['code'] ?? ''));

    if ($demande_id && $code) {
      $stmt = $db->prepare("SELECT * FROM clients WHERE id=? AND statut='VALIDE_MANAGER'");
      $stmt->execute([$demande_id]);
      $demande = $stmt->fetch();

      if ($demande) {
        try {
          $type_paiement = in_array($demande['type'], ['DISTRIBUTEUR','GMS','STATION','DEMI_GROS'])
            ? 'AGENCE' : 'DISTRIBUTEUR';

          $stmt = $db->prepare("
            UPDATE clients SET code_client=?, type_paiement=?, statut='ACTIF' WHERE id=?
          ");
          $stmt->execute([$code, $type_paiement, $demande_id]);

          // Notifier commercial
          $stmt = $db->prepare("
            INSERT INTO notifications (utilisateur_id, titre, message, type, reference_id)
            VALUES (?,?,?,'CODE_CLIENT',?)
          ");
          $stmt->execute([
            $demande['demandeur_id'],
            'Code client attribué',
            "Le code $code a été attribué à {$demande['nom']}. Vous pouvez le communiquer au client.",
            $demande_id
          ]);

          $msg = ['success', "Code $code attribué au client {$demande['nom']}."];
        } catch (Exception $e) {
          $msg = ['error', 'Erreur : ' . $e->getMessage()];
        }
      }
    }
  } elseif ($action === 'toggle_client') {
    $id = (int)($_POST['id'] ?? 0);
    $stmt = $db->prepare("
      UPDATE clients SET statut = CASE WHEN statut='ACTIF' THEN 'INACTIF' ELSE 'ACTIF' END
      WHERE id=? AND statut IN ('ACTIF','INACTIF') -- une demande en cours ne peut pas être activée sans code
    ");
    $stmt->execute([$id]);
    header('Location: clients.php');
    exit;
  }
}

// Demandes en attente d'attribution
$demandes_attente = $db->query("
  SELECT d.*, CONCAT(u.prenom,' ',u.nom) AS commercial_nom, s.nom AS secteur_nom
  FROM clients d
  JOIN utilisateurs u ON d.demandeur_id = u.id
  LEFT JOIN secteurs s ON d.secteur_id = s.id
  WHERE d.statut = 'VALIDE_MANAGER'
  ORDER BY d.created_at ASC
")->fetchAll();

// Clients
$search = trim($_GET['q'] ?? '');
$type_f = $_GET['type'] ?? '';
$where  = "WHERE c.statut IN ('ACTIF','INACTIF')";
$params = [];
if ($search) { $where .= " AND (c.nom LIKE ? OR c.code_client LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($type_f) { $where .= " AND c.type=?"; $params[] = $type_f; }

$stmt = $db->prepare("
  SELECT c.*, s.nom AS secteur_nom
  FROM clients c
  LEFT JOIN secteurs s ON c.secteur_id = s.id
  $where ORDER BY c.nom ASC LIMIT 100
");
$stmt->execute($params);
$clients = $stmt->fetchAll();

$types = ['DISTRIBUTEUR','GMS','STATION','DEMI_GROS','EPICERIE','BAR','RESTAURANT'];
$secteurs = $db->query("SELECT id,nom FROM secteurs WHERE actif=1 ORDER BY nom")->fetchAll();
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Gestion des clients</div>
      <div class="page-subtitle">
        <?= count($clients) ?> client(s)
        <?php if (!empty($demandes_attente)): ?>
          · <span style="color:#ffa000">⏳ <?= count($demandes_attente) ?> code(s) à attribuer</span>
        <?php endif; ?>
      </div>
    </div>
    <?php if ($editable): ?><button onclick="ouvrirClientModal()" class="btn btn-primary">+ Nouveau client</button><?php endif; ?>
  </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-<?= $msg[0]==='success'?'success':'error' ?>">
  <?= $msg[0]==='success'?'✅':'❌' ?> <?= htmlspecialchars($msg[1]) ?>
</div>
<?php endif; ?>

<!-- Demandes à traiter -->
<?php if (!empty($demandes_attente)): ?>
<div style="margin-bottom:1.4rem">
  <div style="font-size:.72rem;font-weight:700;color:#ffa000;text-transform:uppercase;
              letter-spacing:.08em;margin-bottom:.7rem">
    ⏳ Codes à attribuer (<?= count($demandes_attente) ?>)
  </div>
  <?php foreach ($demandes_attente as $d): ?>
  <div class="card" style="margin-bottom:.6rem;border-color:rgba(255,160,0,.3)">
    <div style="display:grid;grid-template-columns:1fr auto;gap:1rem;align-items:center">
      <div>
        <div style="font-weight:700;font-size:.9rem"><?= htmlspecialchars($d['nom']) ?></div>
        <div style="font-size:.72rem;color:var(--text-mute);margin-top:.2rem">
          <?= $d['type'] ?> · <?= htmlspecialchars($d['quartier']??'') ?>
          · <?= htmlspecialchars($d['adresse']) ?>
          · Demandé par <strong><?= htmlspecialchars($d['commercial_nom']) ?></strong>
        </div>
      </div>
      <?php if ($editable): ?><form method="POST" style="display:flex;gap:.5rem;align-items:center">
        <input type="hidden" name="action" value="attribuer_code">
        <input type="hidden" name="demande_id" value="<?= $d['id'] ?>">
        <input type="text" name="code" required placeholder="Code client"
          style="width:130px;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.5rem .7rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif;
                 text-transform:uppercase"
          oninput="this.value=this.value.toUpperCase()">
        <button type="submit" class="btn btn-primary btn-sm">✓ Attribuer</button>
      </form><?php else: ?><span class="badge badge-mute">Lecture seule</span><?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Recherche + filtres -->
<div class="card" style="padding:.8rem 1rem;margin-bottom:1rem">
  <form method="GET" style="display:flex;gap:.6rem;flex-wrap:wrap;align-items:center">
    <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
      placeholder="🔍 Nom ou code client..."
      style="flex:1;min-width:200px;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
             padding:.55rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
    <select name="type"
      style="background:var(--bg3);border:1px solid var(--border);border-radius:8px;
             padding:.55rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
      <option value="">Tous les types</option>
      <?php foreach ($types as $t): ?>
      <option value="<?= $t ?>" <?= $type_f===$t?'selected':'' ?>><?= $t ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filtrer</button>
    <?php if ($search||$type_f): ?>
    <a href="clients.php" class="btn btn-secondary btn-sm">Effacer</a>
    <?php endif; ?>
  </form>
</div>

<!-- Table clients -->
<div class="card" style="padding:0;overflow:hidden">
  <table class="data-table">
    <thead>
      <tr><th>Code</th><th>Nom</th><th>Type</th><th>Paiement</th><th>Secteur</th><th>Tél</th><th style="text-align:center">Statut</th><th></th></tr>
    </thead>
    <tbody>
      <?php foreach ($clients as $c): ?>
      <tr style="opacity:<?= $c['statut']==='ACTIF'?'1':'.5' ?>">
        <td style="font-family:monospace;font-size:.75rem;font-weight:700;color:var(--red)"><?= htmlspecialchars($c['code_client']) ?></td>
        <td style="font-weight:500"><?= htmlspecialchars($c['nom']) ?></td>
        <td><span class="badge badge-mute" style="font-size:.63rem"><?= $c['type'] ?></span></td>
        <td style="font-size:.72rem"><?= $c['type_paiement']==='AGENCE'?'🏦 Agence':'💵 Distributeur' ?></td>
        <td style="font-size:.72rem;color:var(--text-mute)"><?= htmlspecialchars($c['secteur_nom']??'—') ?></td>
        <td style="font-size:.72rem"><?= htmlspecialchars($c['telephone']??'—') ?></td>
        <td style="text-align:center">
          <?= $c['statut']==='ACTIF' ? "<span class='badge badge-green'>Actif</span>" : "<span class='badge badge-mute'>Inactif</span>" ?>
        </td>
        <td>
          <?php if ($editable): ?><form method="POST" style="margin:0">
            <input type="hidden" name="action" value="toggle_client">
            <input type="hidden" name="id" value="<?= $c['id'] ?>">
            <button type="submit" class="btn btn-secondary btn-sm"
              style="color:<?= $c['statut']==='ACTIF'?'var(--red)':'#00c864' ?>">
              <?= $c['statut']==='ACTIF'?'Désactiver':'Activer' ?>
            </button>
          </form><?php endif; ?>
          <?php if ($editable): ?><button type="button" class="btn btn-secondary btn-sm" onclick='editerClient(<?=htmlspecialchars(json_encode($c),ENT_QUOTES,"UTF-8")?>)'>Modifier</button><?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php if ($editable): ?>
<div id="modalClient" style="display:none;position:fixed;inset:0;z-index:200;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);align-items:center;justify-content:center;padding:1rem;overflow:auto">
<div class="card modal-box" style="width:min(760px,96vw);max-height:92vh;overflow:auto"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem"><strong id="clientModalTitle">Nouveau client</strong><button type="button" onclick="fermerClientModal()" class="btn btn-secondary btn-sm">✕</button></div>
<form method="POST" id="formClient" style="display:grid;gap:.75rem">
  <input type="hidden" name="action" id="clientAction" value="creer_client">
  <input type="hidden" name="id" id="clientId" value="0">
  <div class="grid-2"><input name="code_client" id="fc_code" required placeholder="Code client"><input name="nom" id="fc_nom" required placeholder="Nom du client"></div>
  <div class="grid-2">
    <select name="type" id="fc_type" required onchange="onTypeChange()">
      <option value="">Type...</option>
      <?php foreach($types as $t):?><option value="<?=$t?>"><?=$t?></option><?php endforeach;?>
    </select>
    <select name="type_paiement" id="fc_paiement"><option value="AGENCE">Paiement agence</option><option value="DISTRIBUTEUR">Paiement distributeur</option></select>
  </div>
  <input name="adresse" id="fc_adresse" required placeholder="Adresse">
  <div class="grid-2"><input name="quartier" id="fc_quartier" placeholder="Quartier"><select name="secteur_id" id="fc_secteur"><option value="">Secteur...</option><?php foreach($secteurs as $sct):?><option value="<?=$sct['id']?>"><?=htmlspecialchars($sct['nom'])?></option><?php endforeach;?></select></div>
  <div class="grid-2"><input name="telephone" id="fc_tel" placeholder="Téléphone"><input name="email" id="fc_email" type="email" placeholder="Email"></div>
  <div class="grid-2"><input name="nif" id="fc_nif" placeholder="NIF"><input name="stat" id="fc_stat" placeholder="STAT"></div>

  <!-- Distributeur livreur : uniquement pour les petits clients (épicerie, bar, restaurant),
       livrés par un distributeur/demi-gros. Les clients directs (Distributeur, GMS, Station,
       Demi-gros) sont livrés directement par l'agence. -->
  <div id="fc_dist_wrap"><select name="distributeur_id" id="fc_dist"><option value="">Distributeur livreur...</option><?php foreach($clients as $d): if($d['type']==='DISTRIBUTEUR'):?><option value="<?=$d['id']?>"><?=htmlspecialchars($d['nom'])?></option><?php endif; endforeach;?></select></div>

  <!-- Compte d'accès au site : uniquement pour un client de type DISTRIBUTEUR -->
  <div id="fc_compte_wrap" style="display:none;background:var(--bg3);border:1px solid var(--border);border-radius:8px;padding:.8rem">
    <div style="font-size:.75rem;color:var(--text-mute);margin-bottom:.6rem">🔑 Compte d'accès au site (seul un Distributeur a un compte — les autres clients n'en ont pas)</div>
    <div class="grid-2">
      <input name="compte_email" id="fc_compte_email" type="email" placeholder="Email de connexion">
      <input name="compte_password" id="fc_compte_password" type="password" placeholder="Mot de passe" autocomplete="new-password">
    </div>
    <div id="fc_compte_hint" style="font-size:.68rem;color:var(--text-mute);margin-top:.4rem"></div>
  </div>

  <div style="display:flex;justify-content:flex-end;gap:.6rem"><button type="button" onclick="fermerClientModal()" class="btn btn-secondary">Annuler</button><button class="btn btn-primary" id="clientSubmit">Créer</button></div>
</form></div></div>
<script>
const CLIENTS_DIRECTS = ['DISTRIBUTEUR','GMS','STATION','DEMI_GROS'];
function onTypeChange(){
  const type = document.getElementById('fc_type').value;
  const estDistributeur = type === 'DISTRIBUTEUR';
  const estClientDirect = CLIENTS_DIRECTS.includes(type);
  document.getElementById('fc_compte_wrap').style.display = estDistributeur ? 'block' : 'none';
  document.getElementById('fc_dist_wrap').style.display = estClientDirect ? 'none' : 'block';
  if (estClientDirect) document.getElementById('fc_dist').value = '';
  if (!estDistributeur) { document.getElementById('fc_compte_email').value = ''; document.getElementById('fc_compte_password').value = ''; }
}
function ouvrirClientModal(){
  document.getElementById('clientAction').value='creer_client';
  document.getElementById('clientId').value='0';
  document.getElementById('clientModalTitle').textContent='Nouveau client';
  document.getElementById('clientSubmit').textContent='Créer';
  document.getElementById('formClient').reset();
  document.getElementById('fc_compte_hint').textContent='Requis pour un nouveau Distributeur.';
  onTypeChange();
  document.getElementById('modalClient').style.display='flex';
}
function editerClient(c){
  document.getElementById('clientAction').value='modifier_client';
  document.getElementById('clientId').value=c.id;
  document.getElementById('clientModalTitle').textContent='Modifier '+c.nom;
  document.getElementById('clientSubmit').textContent='Enregistrer';
  const map={code_client:'code',nom:'nom',type:'type',type_paiement:'paiement',adresse:'adresse',quartier:'quartier',secteur_id:'secteur',telephone:'tel',email:'email',nif:'nif',stat:'stat',distributeur_id:'dist'};
  Object.entries(map).forEach(([k,id])=>{const e=document.getElementById('fc_'+id);if(e)e.value=c[k]??''});
  document.getElementById('fc_compte_email').value = c.type==='DISTRIBUTEUR' ? (c.email??'') : '';
  document.getElementById('fc_compte_password').value = '';
  document.getElementById('fc_compte_hint').textContent = c.utilisateur_id
    ? 'Compte déjà créé. Laisser le mot de passe vide pour ne pas le changer.'
    : 'Aucun compte encore lié : email + mot de passe requis pour en créer un.';
  onTypeChange();
  document.getElementById('modalClient').style.display='flex';
}
function fermerClientModal(){document.getElementById('modalClient').style.display='none';}
</script>
<?php endif; ?>
<?php close_layout(); ?>

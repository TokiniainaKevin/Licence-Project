<?php
// ============================================================
// modules/admin/secteurs.php
// Gestion des secteurs (fusionnés avec les équipes) et affectation
// directe des commerciaux (plus d'historique séparé : le secteur
// actuel d'un commercial est simplement utilisateurs.secteur_id).
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx = include_layout('Secteurs', ['ADMIN','DIRECTEUR']);
$user = $ctx['user'];
$db   = getDB();
$editable = ($user['role'] === 'ADMIN');

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $editable) {
  $action = $_POST['action'] ?? '';

  if ($action === 'creer_secteur') {
    $nom  = trim($_POST['nom_secteur'] ?? '');
    $zone = trim($_POST['zone'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    if ($nom && $zone) {
      $db->prepare("INSERT INTO secteurs (nom, zone, description) VALUES (?,?,?)")->execute([$nom,$zone,$desc?:null]);
      $msg = ['success', "Secteur $nom créé."];
    }
  } elseif ($action === 'affecter') {
    $commercial_id = (int)($_POST['commercial_id'] ?? 0);
    $secteur_id    = (int)($_POST['secteur_id'] ?? 0);
    if ($commercial_id && $secteur_id) {
      $db->prepare("UPDATE utilisateurs SET secteur_id=? WHERE id=?")->execute([$secteur_id,$commercial_id]);
      $msg = ['success', 'Affectation enregistrée.'];
    }
  }
}

$secteurs = $db->query("SELECT s.*, COUNT(u.id) AS nb_commerciaux
  FROM secteurs s LEFT JOIN utilisateurs u ON u.secteur_id=s.id AND u.actif=1
  WHERE s.actif=1 GROUP BY s.id ORDER BY s.nom ASC")->fetchAll();

$commerciaux = $db->query("SELECT u.id, CONCAT(u.prenom,' ',u.nom) AS nom, u.secteur_id, s.nom AS secteur_nom
  FROM utilisateurs u LEFT JOIN secteurs s ON u.secteur_id=s.id
  WHERE u.role IN ('COMMERCIAL','MANAGER_INTERIM') AND u.actif=1
  ORDER BY s.nom ASC, u.nom ASC")->fetchAll();
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Secteurs</div>
      <div class="page-subtitle"><?= count($secteurs) ?> secteur(s)</div>
    </div>
  </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-<?= $msg[0]==='success'?'success':'error' ?>">
  <?= $msg[0]==='success'?'✅':'❌' ?> <?= htmlspecialchars($msg[1]) ?>
</div>
<?php endif; ?>

<div class="grid-2" style="margin-bottom:1.2rem">

  <!-- Secteurs -->
  <div>
    <div style="font-size:.72rem;font-weight:700;color:var(--text-mute);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.6rem">
      Secteurs
    </div>
    <div class="card" style="padding:0;overflow:hidden;margin-bottom:.8rem">
      <table class="data-table">
        <thead><tr><th>Secteur</th><th>Zone</th><th>Commerciaux</th></tr></thead>
        <tbody>
          <?php foreach ($secteurs as $s): ?>
          <tr>
            <td style="font-weight:500"><?= htmlspecialchars($s['nom']) ?></td>
            <td style="font-size:.75rem"><?= htmlspecialchars($s['zone']) ?></td>
            <td><span class="badge badge-blue" style="font-size:.65rem"><?= $s['nb_commerciaux'] ?></span></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php if ($editable): ?><div class="card">
      <div style="font-size:.82rem;font-weight:600;margin-bottom:.8rem">+ Nouveau secteur</div>
      <form method="POST" style="display:flex;flex-direction:column;gap:.7rem">
        <input type="hidden" name="action" value="creer_secteur">
        <input type="text" name="nom_secteur" required placeholder="Nom du secteur"
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.6rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
        <input type="text" name="zone" required placeholder="Zone géographique"
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.6rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
        <input type="text" name="description" placeholder="Description (optionnel)"
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.6rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
        <button type="submit" class="btn btn-primary btn-sm" style="width:100%;justify-content:center">Créer le secteur</button>
      </form>
    </div><?php endif; ?>
  </div>

  <!-- Affectations -->
  <div>
    <div style="font-size:.72rem;font-weight:700;color:var(--text-mute);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.6rem">
      Affectation des commerciaux
    </div>
    <div class="card" style="padding:0;overflow:hidden;margin-bottom:.8rem">
      <table class="data-table">
        <thead><tr><th>Commercial</th><th>Secteur actuel</th></tr></thead>
        <tbody>
          <?php foreach ($commerciaux as $c): ?>
          <tr>
            <td style="font-weight:500"><?= htmlspecialchars($c['nom']) ?></td>
            <td>
              <?php if ($c['secteur_nom']): ?>
                <span class="badge badge-green" style="font-size:.65rem"><?= htmlspecialchars($c['secteur_nom']) ?></span>
              <?php else: ?>
                <span class="badge badge-mute" style="font-size:.65rem">Non affecté</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php if ($editable): ?><div class="card">
      <div style="font-size:.82rem;font-weight:600;margin-bottom:.8rem">Modifier une affectation</div>
      <form method="POST" style="display:flex;flex-direction:column;gap:.7rem">
        <input type="hidden" name="action" value="affecter">
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Commercial</label>
          <select name="commercial_id" required
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.6rem .9rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
            <option value="">Sélectionner...</option>
            <?php foreach ($commerciaux as $c): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nom']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Secteur</label>
          <select name="secteur_id" required
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.6rem .9rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
            <option value="">Sélectionner...</option>
            <?php foreach ($secteurs as $s): ?>
            <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['nom']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Enregistrer l'affectation</button>
      </form>
    </div><?php else: ?><div class="alert alert-info">👁️ Mode lecture seule.</div><?php endif; ?>
  </div>
</div>

<?php close_layout(); ?>

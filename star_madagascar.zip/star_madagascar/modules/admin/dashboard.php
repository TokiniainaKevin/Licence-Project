<?php
// ============================================================
// modules/admin/dashboard.php
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/stock.php';
require_once '../../includes/objectifs.php';
$synth_agence = null;

$ctx  = include_layout('Administration', ['ADMIN','DIRECTEUR']);
$user = $ctx['user'];
$db   = getDB();

// Stats globales
$stats = $db->query("
  SELECT
    (SELECT COUNT(*) FROM utilisateurs WHERE actif=1)                     AS nb_users,
    (SELECT COUNT(*) FROM clients WHERE statut='ACTIF')                    AS nb_clients,
    (SELECT COUNT(*) FROM commandes WHERE DATE(date_commande)=CURDATE())   AS nb_cmd_jour,
    (SELECT COALESCE(SUM(total_hl),0) FROM commandes
     WHERE DATE(date_commande)=CURDATE() AND statut NOT IN ('CREEE'))      AS hl_jour,
    (SELECT COUNT(*) FROM clients WHERE statut IN ('EN_ATTENTE','VALIDE_MANAGER')) AS nb_codes,
    (SELECT COUNT(*) FROM produits p
     " . stock_join_sql() . "
     WHERE COALESCE(se.total_btl,0) <= 0 AND p.actif=1)           AS nb_alertes
")->fetch();

// Commandes par statut aujourd'hui
$cmd_statuts = $db->query("
  SELECT statut, COUNT(*) AS nb, COALESCE(SUM(total_hl),0) AS hl
  FROM commandes WHERE DATE(date_commande)=CURDATE()
  GROUP BY statut
")->fetchAll();

// Top commerciaux du jour
$top_com = $db->query("
  SELECT CONCAT(u.prenom,' ',u.nom) AS nom, e.nom AS equipe,
         COALESCE(SUM(c.total_hl),0) AS hl, COUNT(c.id) AS nb_cmd
  FROM utilisateurs u
  LEFT JOIN commandes c ON c.commercial_id=u.id AND DATE(c.date_commande)=CURDATE() AND c.statut NOT IN ('CREEE')
  LEFT JOIN secteurs e ON u.secteur_id=e.id
  WHERE u.role IN ('COMMERCIAL','MANAGER_INTERIM') AND u.actif=1
  GROUP BY u.id ORDER BY hl DESC LIMIT 8
")->fetchAll();
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Administration</div>
      <div class="page-subtitle"><?= date('d/m/Y H:i') ?> — Vue globale</div>
    </div>
    <div style="display:flex;gap:.6rem">
      <?php if ($stats['nb_codes'] > 0): ?>
      <a href="codes_clients.php" class="btn btn-secondary" style="color:#ffa000;border-color:#ffa000">
        🆔 <?= $stats['nb_codes'] ?> code(s) à traiter
      </a>
      <?php endif; ?>
      <?php if ($stats['nb_alertes'] > 0): ?>
      <a href="stock.php?filtre=alerte" class="btn btn-secondary" style="color:var(--red);border-color:var(--red)">
        ⚠️ <?= $stats['nb_alertes'] ?> alerte(s) stock
      </a>
      <?php endif; ?>
    </div>
  </div>
</div>

<?= bloc_objectif_agence(synthese_objectif_agence($db)) ?>

<!-- KPI globaux -->
<div class="grid-4" style="margin-bottom:1.2rem">
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Utilisateurs actifs</div>
    <div class="kpi-value"><?= $stats['nb_users'] ?> <span class="unit">comptes</span></div>
    <a href="utilisateurs.php" style="font-size:.72rem;color:var(--red)">Gérer →</a>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Clients actifs</div>
    <div class="kpi-value"><?= $stats['nb_clients'] ?> <span class="unit">clients</span></div>
    <a href="clients.php" style="font-size:.72rem;color:var(--red)">Gérer →</a>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Commandes aujourd'hui</div>
    <div class="kpi-value"><?= $stats['nb_cmd_jour'] ?> <span class="unit">cmd</span></div>
    <div class="kpi-trend neutral"><?= number_format($stats['hl_jour'],2) ?> hl</div>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Alertes stock</div>
    <div class="kpi-value" style="color:<?= $stats['nb_alertes']>0?'#ffa000':'var(--text)' ?>">
      <?= $stats['nb_alertes'] ?> <span class="unit">produits</span>
    </div>
    <a href="stock.php" style="font-size:.72rem;color:#ffa000">Voir stock →</a>
  </div>
</div>

<div class="grid-2">
  <!-- Top commerciaux -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:.85rem;font-weight:600">
      Performances commerciaux — Aujourd'hui
    </div>
    <table class="data-table">
      <thead>
        <tr><th>Commercial</th><th>Équipe</th><th style="text-align:right">Hl</th><th style="text-align:center">Cmd</th></tr>
      </thead>
      <tbody>
        <?php foreach ($top_com as $c): ?>
        <tr>
          <td style="font-weight:500"><?= htmlspecialchars($c['nom']) ?></td>
          <td style="font-size:.72rem;color:var(--text-mute)"><?= htmlspecialchars($c['equipe'] ?? '—') ?></td>
          <td style="text-align:right;font-weight:700;color:<?= $c['hl']>0?'var(--red)':'var(--text-mute)' ?>">
            <?= number_format($c['hl'],2) ?>
          </td>
          <td style="text-align:center"><?= $c['nb_cmd'] ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Raccourcis admin -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem">
    <?php
    $raccourcis = [
      ['👥', 'Utilisateurs', 'utilisateurs.php', 'Gérer les comptes et rôles'],
      ['🏪', 'Clients', 'clients.php', 'Codes clients, types, secteurs'],
      ['🍺', 'Produits', 'produits.php', 'Catalogue, prix, familles'],
      ['🗺️', 'Secteurs', 'secteurs.php', 'Zones et équipes commerciales'],
      ['🎯', 'Objectifs', 'objectifs.php', 'Objectif agence (mois/semaine/jour) et visites'],
      ['🆔', 'Codes clients', 'codes_clients.php', 'Valider les nouvelles demandes'],
      ['📦', 'Stock', 'stock.php', 'Entrepôt et alertes'],
      ['📋', 'Commandes', 'commandes.php', 'Toutes les commandes'],
    ];
    foreach ($raccourcis as [$ico, $titre, $url, $desc]): ?>
    <a href="<?= $url ?>" class="card" style="text-decoration:none;cursor:pointer;transition:border-color .15s"
       onmouseover="this.style.borderColor='var(--red)'" onmouseout="this.style.borderColor='var(--border)'">
      <div style="font-size:1.4rem;margin-bottom:.4rem"><?= $ico ?></div>
      <div style="font-size:.82rem;font-weight:700;color:var(--text);margin-bottom:.2rem"><?= $titre ?></div>
      <div style="font-size:.7rem;color:var(--text-mute)"><?= $desc ?></div>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<?php ?>
<!-- ── Graphiques ─────────────────────────────────────────── -->
<?php
$a_ = (int)date('Y'); $m_ = (int)date('n');
$obj_g = objectifs_agence($db, $a_, $m_);
$real_g = realise_agence_par_jour($db, $a_, $m_);
$jours_g = [];
foreach (semaines_ouvrees($a_, $m_) as $js) foreach ($js as $d) $jours_g[] = $d;
$fam_g = $db->query("SELECT p.famille l, ROUND(SUM(lc.volume_hl),2) v FROM lignes_commande lc JOIN commandes c ON c.id=lc.commande_id JOIN produits p ON p.id=lc.produit_id
  WHERE c.statut NOT IN ('CREEE') AND YEAR(c.date_commande)=YEAR(CURDATE()) AND MONTH(c.date_commande)=MONTH(CURDATE()) GROUP BY p.famille ORDER BY v DESC")->fetchAll();
$typ_g = $db->query("SELECT cl.type l, ROUND(SUM(c.total_hl),2) v FROM commandes c JOIN clients cl ON cl.id=c.client_id
  WHERE c.statut NOT IN ('CREEE') AND YEAR(c.date_commande)=YEAR(CURDATE()) AND MONTH(c.date_commande)=MONTH(CURDATE()) GROUP BY cl.type ORDER BY v DESC")->fetchAll();
$top_g = $db->query("SELECT p.description l, ROUND(SUM(lc.volume_hl),2) v FROM lignes_commande lc JOIN commandes c ON c.id=lc.commande_id JOIN produits p ON p.id=lc.produit_id
  WHERE c.statut NOT IN ('CREEE') AND c.date_commande >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY p.id ORDER BY v DESC LIMIT 10")->fetchAll();
$types_fr = ['DISTRIBUTEUR'=>'Distributeurs','GMS'=>'GMS','STATION'=>'Stations','DEMI_GROS'=>'Demi-gros','EPICERIE'=>'Épiceries','BAR'=>'Bars','RESTAURANT'=>'Restaurants'];
?>
<div style="margin-top:1.2rem">
<?= graphique('gAgence', 'Objectif agence : réalisé par jour ouvré', ['type'=>'bar','unite'=>'hl','data'=>[
  'labels'=>array_map(fn($d)=>date('d/m',strtotime($d)),$jours_g),
  'datasets'=>[
    ['type'=>'bar','label'=>'Réalisé (clients agence, payé)','data'=>array_map(fn($d)=>round($real_g[$d]??0,2),$jours_g),'backgroundColor'=>'rgba(232,0,28,.75)','borderRadius'=>4],
    ['type'=>'line','label'=>'Objectif journalier','data'=>array_map(fn($d)=>$obj_g['jours'][$d]??0,$jours_g),'borderColor'=>'#E8AF34','borderDash'=>[6,4],'pointRadius'=>0,'borderWidth'=>2],
  ]],'options'=>['scales'=>['y'=>['beginAtZero'=>true,'title'=>['display'=>true,'text'=>'hl']]]]], 280, 'Mois en cours · lundi au samedi') ?>
<div class="grid-2">
<?= graphique('gFamille', 'Volume du mois par famille de produits', ['type'=>'bar','unite'=>'hl','data'=>['labels'=>array_column($fam_g,'l'),
  'datasets'=>[['label'=>'Volume','data'=>array_map('floatval',array_column($fam_g,'v')),'backgroundColor'=>'rgba(232,0,28,.7)','borderRadius'=>4]]],
  'options'=>['indexAxis'=>'y','plugins'=>['legend'=>['display'=>false]]]], 320) ?>
<?= graphique('gType', 'Volume du mois par type de client', ['type'=>'bar','unite'=>'hl','data'=>['labels'=>array_map(fn($t)=>$types_fr[$t]??$t,array_column($typ_g,'l')),
  'datasets'=>[['label'=>'Volume','data'=>array_map('floatval',array_column($typ_g,'v')),'backgroundColor'=>'rgba(31,157,85,.75)','borderRadius'=>4]]],
  'options'=>['indexAxis'=>'y','plugins'=>['legend'=>['display'=>false]]]], 320) ?>
</div>
<?= graphique('gTop', 'Top 10 des produits (30 derniers jours)', ['type'=>'bar','unite'=>'hl','data'=>['labels'=>array_column($top_g,'l'),
  'datasets'=>[['label'=>'Volume','data'=>array_map('floatval',array_column($top_g,'v')),'backgroundColor'=>'rgba(232,175,52,.8)','borderRadius'=>4]]],
  'options'=>['indexAxis'=>'y','plugins'=>['legend'=>['display'=>false]]]], 340) ?>
</div>

<?php close_layout(); ?>

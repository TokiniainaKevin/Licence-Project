<?php
// ============================================================
// modules/admin/utilisateurs.php
// CRUD utilisateurs
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx = include_layout('Utilisateurs', ['ADMIN','DIRECTEUR']);
$user = $ctx['user'];
$db   = getDB();
$editable = ($user['role'] === 'ADMIN');

$msg = '';

// Traitement POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $editable) {
  $action = $_POST['action'] ?? '';

  if ($action === 'creer' || $action === 'modifier') {
    $id        = (int)($_POST['id'] ?? 0);
    $nom       = trim($_POST['nom'] ?? '');
    $prenom    = trim($_POST['prenom'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $role      = $_POST['role'] ?? '';
    $secteur_id = (int)($_POST['secteur_id'] ?? 0) ?: null;
    $tel       = trim($_POST['telephone'] ?? '');
    $statut_presence = $_POST['statut_presence'] ?? 'EN_TRAVAIL';
    $statuts_presence = ['EN_TRAVAIL','CONGE','ABSENT','SUSPENDU'];
    if (!in_array($statut_presence, $statuts_presence, true)) $statut_presence = 'EN_TRAVAIL';
    $password  = trim($_POST['password'] ?? '');

    $roles_valides = ['ADMIN','DIRECTEUR','MANAGER','MANAGER_INTERIM','COMMERCIAL','LOGISTIQUE','CAISSIER','DISTRIBUTEUR'];

    // Les comptes Distributeur se créent et se gèrent uniquement depuis la fiche
    // client (module Clients) : ici on ne permet ni d'en créer un nouveau, ni de
    // faire basculer un autre rôle vers Distributeur. On garde en revanche la
    // possibilité de modifier les autres champs d'un distributeur déjà existant.
    $role_actuel = null;
    if ($action === 'modifier' && $id) {
      $stmt = $db->prepare("SELECT role FROM utilisateurs WHERE id=?");
      $stmt->execute([$id]);
      $role_actuel = $stmt->fetchColumn() ?: null;
      if ($role_actuel === 'DISTRIBUTEUR') $role = 'DISTRIBUTEUR';
    }

    if ($role === 'DISTRIBUTEUR' && $role_actuel !== 'DISTRIBUTEUR') {
      $msg = ['error', "Un compte Distributeur ne peut pas être créé ou attribué ici : il se crée automatiquement depuis la fiche client (module Clients)."];
    } elseif (!$nom || !$prenom || !$email || !in_array($role, $roles_valides)) {
      $msg = ['error', 'Champs obligatoires manquants ou rôle invalide.'];
    } else {
      if ($action === 'creer') {
        if (!$password) { $msg = ['error', 'Mot de passe requis pour la création.']; }
        else {
          try {
            $stmt = $db->prepare("
              INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, telephone, role, secteur_id, statut_presence)
              VALUES (?,?,?,?,?,?,?,?)
            ");
            $stmt->execute([$nom, $prenom, $email, password_hash($password, PASSWORD_DEFAULT), $tel ?: null, $role, $secteur_id, $statut_presence]);
            $msg = ['success', "Utilisateur $prenom $nom créé avec succès."];
          } catch (Exception $e) {
            $msg = ['error', 'Email déjà utilisé ou erreur : ' . $e->getMessage()];
          }
        }
      } else {
        $updates = "nom=?, prenom=?, email=?, telephone=?, role=?, secteur_id=?, statut_presence=?";
        $params  = [$nom, $prenom, $email, $tel ?: null, $role, $secteur_id, $statut_presence];
        if ($password) {
          $updates .= ", mot_de_passe=?";
          $params[] = password_hash($password, PASSWORD_DEFAULT);
        }
        $params[] = $id;
        $stmt = $db->prepare("UPDATE utilisateurs SET $updates WHERE id=?");
        $stmt->execute($params);
        $msg = ['success', 'Utilisateur mis à jour.'];
      }
    }
  } elseif ($action === 'toggle') {
    $id = (int)($_POST['id'] ?? 0);
    $db->prepare("UPDATE utilisateurs SET actif = NOT actif WHERE id=? AND id != ?")->execute([$id, $user['id']]);
    header('Location: utilisateurs.php');
    exit;
  }
}

// Récupérer utilisateurs
$utilisateurs = $db->query("
  SELECT u.*, e.nom AS secteur_nom
  FROM utilisateurs u
  LEFT JOIN secteurs e ON u.secteur_id = e.id
  ORDER BY u.role ASC, u.nom ASC
")->fetchAll();

$secteurs = $db->query("SELECT id, nom FROM secteurs WHERE actif=1 ORDER BY nom ASC")->fetchAll();

$roles_labels = [
  'ADMIN'=>'Administrateur','DIRECTEUR'=>'Directeur','MANAGER'=>'Manager',
  'MANAGER_INTERIM'=>'Manager Intérim','COMMERCIAL'=>'Commercial',
  'LOGISTIQUE'=>'Logistique','CAISSIER'=>'Caissier','DISTRIBUTEUR'=>'Distributeur'
];

function role_badge_class(string $r): string {
  return match($r) {
    'ADMIN'          => 'badge-red',
    'DIRECTEUR'      => 'badge-red',
    'MANAGER'        => 'badge-blue',
    'MANAGER_INTERIM'=> 'badge-blue',
    'COMMERCIAL'     => 'badge-green',
    'LOGISTIQUE'     => 'badge-orange',
    'CAISSIER'       => 'badge-green',
    'DISTRIBUTEUR'   => 'badge-mute',
    default          => 'badge-mute',
  };
}
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Gestion des utilisateurs</div>
      <div class="page-subtitle"><?= count($utilisateurs) ?> compte(s) enregistré(s) · les comptes Distributeur se créent depuis la fiche client</div>
    </div>
    <?php if ($editable): ?><button onclick="ouvrirModal()" class="btn btn-primary">+ Nouvel utilisateur</button><?php endif; ?>
  </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-<?= $msg[0] === 'success' ? 'success' : 'error' ?>">
  <?= $msg[0] === 'success' ? '✅' : '❌' ?> <?= htmlspecialchars($msg[1]) ?>
</div>
<?php endif; ?>

<div class="card" style="padding:0;overflow:hidden">
  <table class="data-table">
    <thead>
      <tr><th>Nom</th><th>Email</th><th>Rôle</th><th>Secteur</th><th>Présence</th><th style="text-align:center">Compte</th><th></th></tr>
    </thead>
    <tbody>
      <?php foreach ($utilisateurs as $u): ?>
      <tr style="opacity:<?= $u['actif'] ? '1' : '.5' ?>">
        <td style="font-weight:600"><?= htmlspecialchars($u['prenom'].' '.$u['nom']) ?></td>
        <td style="font-size:.75rem"><?= htmlspecialchars($u['email']) ?></td>
        <td>
          <span class="badge <?= role_badge_class($u['role']) ?>" style="font-size:.65rem">
            <?= $roles_labels[$u['role']] ?? $u['role'] ?>
          </span>
        </td>
        <td style="font-size:.75rem;color:var(--text-mute)"><?= htmlspecialchars($u['secteur_nom'] ?? '—') ?></td>
        <td style="font-size:.72rem"><?= htmlspecialchars(str_replace('_',' ', $u['statut_presence'] ?? 'EN_TRAVAIL')) ?></td>
        <td style="text-align:center">
          <?= $u['actif'] ? "<span class='badge badge-green'>Actif</span>" : "<span class='badge badge-mute'>Inactif</span>" ?>
        </td>
        <td>
          <?php if ($editable): ?><div style="display:flex;gap:.4rem">
            <button onclick="editerUser(<?= htmlspecialchars(json_encode($u)) ?>)"
              class="btn btn-secondary btn-sm">Modifier</button>
            <?php if ($u['id'] !== $user['id']): ?>
            <form method="POST" style="margin:0">
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?= $u['id'] ?>">
              <button type="submit" class="btn btn-secondary btn-sm"
                style="color:<?= $u['actif'] ? 'var(--red)' : '#00c864' ?>">
                <?= $u['actif'] ? 'Désactiver' : 'Activer' ?>
              </button>
            </form>
            <?php endif; ?>
          </div><?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php if ($editable): ?>
<!-- Modal création/édition -->
<div id="modalUser" style="display:none;position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.7);backdrop-filter:blur(4px);align-items:center;justify-content:center">
  <div class="modal-box" style="border:1px solid var(--border);border-radius:16px;
              width:90%;max-width:500px;overflow:hidden;max-height:90vh;overflow-y:auto">
    <div class="modal-sticky-header" style="padding:1rem 1.2rem;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;z-index:1">
      <div style="font-weight:700" id="modalTitre">Nouvel utilisateur</div>
      <button onclick="fermerModal()" style="background:none;border:none;color:var(--text-mute);cursor:pointer;font-size:1.2rem">✕</button>
    </div>
    <form method="POST" id="formUser" style="padding:1.2rem;display:flex;flex-direction:column;gap:.9rem">
      <input type="hidden" name="action" id="formAction" value="creer">
      <input type="hidden" name="id" id="formId" value="0">

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem">
        <?php foreach ([['nom','Nom *'],['prenom','Prénom *']] as [$n,$l]): ?>
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem"><?= $l ?></label>
          <input type="text" name="<?= $n ?>" id="f_<?= $n ?>" required
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.65rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
        </div>
        <?php endforeach; ?>
      </div>

      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Email *</label>
        <input type="email" name="email" id="f_email" required
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.65rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem">
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Rôle *</label>
          <select name="role" id="f_role" required
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.65rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
            <?php foreach ($roles_labels as $r => $l): ?>
            <option value="<?= $r ?>" <?= $r === 'DISTRIBUTEUR' ? 'id="opt_distributeur" disabled' : '' ?>><?= $l ?></option>
            <?php endforeach; ?>
          </select>
          <div id="roleHintDistributeur" style="display:none;font-size:.68rem;color:var(--text-mute);margin-top:.3rem">
            Rôle géré depuis la fiche client (module Clients), non modifiable ici.
          </div>
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Secteur</label>
          <select name="secteur_id" id="f_secteur"
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.65rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
            <option value="">Aucune</option>
            <?php foreach ($secteurs as $e): ?>
            <option value="<?= $e['id'] ?>"><?= htmlspecialchars($e['nom']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Téléphone</label>
        <input type="tel" name="telephone" id="f_telephone"
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.65rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
      </div>

      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Statut de présence</label>
        <select name="statut_presence" id="f_statut_presence"
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;padding:.65rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
          <option value="EN_TRAVAIL">En travail</option>
          <option value="CONGE">En congé</option>
          <option value="ABSENT">Absent</option>
          <option value="SUSPENDU">Suspendu</option>
        </select>
      </div>

      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem" id="passLabel">
          Mot de passe *
        </label>
        <input type="password" name="password" id="f_password"
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.65rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
      </div>

      <div style="display:flex;gap:.6rem">
        <button type="button" onclick="fermerModal()" class="btn btn-secondary" style="flex:1;justify-content:center">Annuler</button>
        <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center" id="formSubmitBtn">Créer</button>
      </div>
    </form>
  </div>
</div>

<script>
function ouvrirModal() {
  document.getElementById('modalTitre').textContent = 'Nouvel utilisateur';
  document.getElementById('formAction').value = 'creer';
  document.getElementById('formId').value = '0';
  document.getElementById('formUser').reset();
  document.getElementById('passLabel').textContent = 'Mot de passe *';
  document.getElementById('formSubmitBtn').textContent = 'Créer';
  const roleSel = document.getElementById('f_role');
  roleSel.disabled = false;
  document.getElementById('opt_distributeur').disabled = true;
  document.getElementById('roleHintDistributeur').style.display = 'none';
  document.getElementById('modalUser').style.display = 'flex';
}

function editerUser(u) {
  document.getElementById('modalTitre').textContent = 'Modifier ' + u.prenom + ' ' + u.nom;
  document.getElementById('formAction').value = 'modifier';
  document.getElementById('formId').value = u.id;
  document.getElementById('f_nom').value = u.nom;
  document.getElementById('f_prenom').value = u.prenom;
  document.getElementById('f_email').value = u.email;
  const roleSel = document.getElementById('f_role');
  const optDist = document.getElementById('opt_distributeur');
  const hint = document.getElementById('roleHintDistributeur');
  if (u.role === 'DISTRIBUTEUR') {
    optDist.disabled = false;
    roleSel.value = 'DISTRIBUTEUR';
    roleSel.disabled = true;
    hint.style.display = 'block';
  } else {
    optDist.disabled = true;
    roleSel.disabled = false;
    roleSel.value = u.role;
    hint.style.display = 'none';
  }
  document.getElementById('f_secteur').value = u.secteur_id || '';
  document.getElementById('f_telephone').value = u.telephone || '';
  const presence = document.getElementById('f_statut_presence');
  if (presence) presence.value = u.statut_presence || 'EN_TRAVAIL';
  document.getElementById('f_password').value = '';
  document.getElementById('passLabel').textContent = 'Nouveau mot de passe (laisser vide pour ne pas changer)';
  document.getElementById('formSubmitBtn').textContent = 'Enregistrer';
  document.getElementById('modalUser').style.display = 'flex';
}

function fermerModal() {
  document.getElementById('modalUser').style.display = 'none';
}

document.getElementById('modalUser').addEventListener('click', function(e) {
  if (e.target === this) fermerModal();
});
</script>
<?php endif; ?>

<?php
close_layout();
?>

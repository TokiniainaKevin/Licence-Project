<?php
// ============================================================
// modules/admin/produits.php
// CRUD produits
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/tarifs.php';

$ctx = include_layout('Produits', ['ADMIN','DIRECTEUR']);
$user = $ctx['user'];
$db   = getDB();
$editable = ($user['role'] === 'ADMIN');

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $editable) {
  $action = $_POST['action'] ?? '';

  if (in_array($action, ['creer','modifier'])) {
    $id          = (int)($_POST['id'] ?? 0);
    $code        = strtoupper(trim($_POST['code'] ?? ''));
    $description = trim($_POST['description'] ?? '');
    $famille     = trim($_POST['famille'] ?? '');
    $contenance  = (int)($_POST['contenance_cl'] ?? 0);
    $emballage   = $_POST['type_emballage'] ?? '';
    $kit         = (int)($_POST['kit'] ?? 0);
    $pag_nu      = (float)str_replace(',','.',($_POST['pag_nu'] ?? 0));
    $pag_kit_nu  = (float)str_replace(',','.',($_POST['pag_kit_nu'] ?? 0));
    $pag_kit_loge= (float)str_replace(',','.',($_POST['pag_kit_loge'] ?? 0));
    $csg_btl     = (float)str_replace(',','.',($_POST['consigne_bouteille'] ?? 0));
    $csg_cas     = (float)str_replace(',','.',($_POST['consigne_casier'] ?? 0));
    $volume_hl   = $kit > 0 && $contenance > 0 ? round($kit * $contenance / 10000, 4) : 0;
    // Consigne : valeur saisie (pré-remplie avec la grille STAR, includes/tarifs.php).
    // PET et canettes ne sont jamais consignés. Le PAG kit logé en découle
    // automatiquement : kit nu + consigne des bouteilles + consigne du casier.
    if ($emballage !== 'VER') { $csg_btl = 0; $csg_cas = 0; }
    $csg_btl      = max(0, $csg_btl);
    $csg_cas      = max(0, $csg_cas);
    $pag_kit_loge = $pag_kit_nu + $kit * $csg_btl + $csg_cas;

    if (!$code || !$description || !$famille || !$kit || !$contenance) {
      $msg = ['error', 'Champs obligatoires manquants.'];
    } else {
      try {
        if ($action === 'creer') {
          $stmt = $db->prepare("
            INSERT INTO produits
              (code,description,famille,contenance_cl,type_emballage,kit,volume_hl,
               pag_nu,pag_kit_nu,pag_kit_loge,consigne_bouteille,consigne_casier)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
          ");
          $stmt->execute([$code,$description,$famille,$contenance,$emballage,$kit,$volume_hl,
                          $pag_nu,$pag_kit_nu,$pag_kit_loge,$csg_btl,$csg_cas]);
          $msg = ['success', "Produit $code créé."];
        } else {
          $stmt = $db->prepare("
            UPDATE produits SET code=?,description=?,famille=?,contenance_cl=?,
              type_emballage=?,kit=?,volume_hl=?,pag_nu=?,pag_kit_nu=?,pag_kit_loge=?,
              consigne_bouteille=?,consigne_casier=?
            WHERE id=?
          ");
          $stmt->execute([$code,$description,$famille,$contenance,$emballage,$kit,$volume_hl,
                          $pag_nu,$pag_kit_nu,$pag_kit_loge,$csg_btl,$csg_cas,$id]);
          $msg = ['success', 'Produit mis à jour.'];
        }
      } catch (Exception $e) {
        $msg = ['error', 'Code déjà existant ou erreur : '.$e->getMessage()];
      }
    }
  } elseif ($action === 'toggle') {
    $id = (int)($_POST['id'] ?? 0);
    $db->prepare("UPDATE produits SET actif = NOT actif WHERE id=?")->execute([$id]);
    header('Location: produits.php'); exit;
  }
}

$produits = $db->query("
  SELECT p.*, p.famille AS famille_nom
  FROM produits p
  ORDER BY p.famille ASC, p.description ASC
")->fetchAll();

$familles = $db->query("SELECT DISTINCT famille FROM produits ORDER BY famille ASC")->fetchAll(PDO::FETCH_COLUMN);
$search   = trim($_GET['q'] ?? '');
if ($search) {
  $produits = array_filter($produits, fn($p) =>
    stripos($p['description'],$search) !== false || stripos($p['code'],$search) !== false
  );
}
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Catalogue produits</div>
      <div class="page-subtitle"><?= count($produits) ?> produit(s) · <?= count($familles) ?> famille(s)</div>
    </div>
    <?php if ($editable): ?>
    <div style="display:flex;gap:.6rem">
      <button onclick="ouvrirModal()" class="btn btn-primary">+ Nouveau produit</button>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php if ($msg): ?>
<div class="alert alert-<?= $msg[0]==='success'?'success':'error' ?>">
  <?= $msg[0]==='success'?'✅':'❌' ?> <?= htmlspecialchars($msg[1]) ?>
</div>
<?php endif; ?>

<!-- Recherche -->
<div class="card" style="padding:.7rem 1rem;margin-bottom:1rem">
  <form method="GET" style="display:flex;gap:.6rem">
    <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
      placeholder="🔍 Code ou description..."
      style="flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
             padding:.55rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
    <button type="submit" class="btn btn-primary btn-sm">Filtrer</button>
    <?php if ($search): ?><a href="produits.php" class="btn btn-secondary btn-sm">Effacer</a><?php endif; ?>
  </form>
</div>

<div class="card" style="padding:0;overflow:hidden">
  <table class="data-table">
    <thead>
      <tr>
        <th>Code</th><th>Description</th><th>Famille</th>
        <th style="text-align:center">Kit</th>
        <th style="text-align:center">Cl</th>
        <th style="text-align:center">Emb.</th>
        <th style="text-align:right">PAG nu</th>
        <th style="text-align:right">PAG kit logé</th>
        <th style="text-align:right">Csg/btl</th>
        <th style="text-align:center">Statut</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($produits as $p): ?>
      <tr style="opacity:<?= $p['actif']?'1':'.5' ?>">
        <td style="font-family:monospace;font-weight:700;color:var(--red);font-size:.75rem"><?= htmlspecialchars($p['code']) ?></td>
        <td style="font-weight:500;font-size:.8rem"><?= htmlspecialchars($p['description']) ?></td>
        <td style="font-size:.72rem;color:var(--text-mute)"><?= htmlspecialchars($p['famille_nom']) ?></td>
        <td style="text-align:center"><?= $p['kit'] ?></td>
        <td style="text-align:center"><?= $p['contenance_cl'] ?></td>
        <td style="text-align:center">
          <span class="badge badge-mute" style="font-size:.62rem"><?= $p['type_emballage'] ?></span>
        </td>
        <td style="text-align:right;font-size:.75rem"><?= number_format($p['pag_nu']) ?></td>
        <td style="text-align:right;font-size:.75rem;font-weight:600;color:var(--red)"><?= number_format($p['pag_kit_loge']) ?></td>
        <td style="text-align:right;font-size:.75rem"><?= number_format($p['consigne_bouteille']) ?></td>
        <td style="text-align:center">
          <?= $p['actif'] ? "<span class='badge badge-green'>Actif</span>" : "<span class='badge badge-mute'>Inactif</span>" ?>
        </td>
        <td>
          <div style="display:flex;gap:.3rem">
            <?php if ($editable): ?><button onclick="editerProduit(<?= htmlspecialchars(json_encode($p)) ?>)" class="btn btn-secondary btn-sm">Modifier</button><form method="POST" style="margin:0">
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?= $p['id'] ?>">
              <button type="submit" class="btn btn-secondary btn-sm"
                style="color:<?= $p['actif']?'var(--red)':'#00c864' ?>">
                <?= $p['actif']?'Off':'On' ?>
              </button>
            </form><?php endif; ?>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<!-- Modal -->
<div id="modalProd" style="display:none;position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.7);backdrop-filter:blur(4px);align-items:flex-start;
  justify-content:center;padding-top:60px;overflow-y:auto">
  <div class="modal-box" style="border:1px solid var(--border);border-radius:16px;
              width:90%;max-width:580px;overflow:hidden;margin-bottom:2rem">
    <div class="modal-sticky-header" style="padding:1rem 1.2rem;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center;
                position:sticky;top:0;z-index:1">
      <div style="font-weight:700" id="modalProdTitre">Nouveau produit</div>
      <button onclick="fermerModal()" style="background:none;border:none;color:var(--text-mute);cursor:pointer;font-size:1.2rem">✕</button>
    </div>
    <form method="POST" id="formProd" style="padding:1.2rem;display:flex;flex-direction:column;gap:.8rem">
      <input type="hidden" name="action" id="prodAction" value="creer">
      <input type="hidden" name="id" id="prodId" value="0">

      <div style="display:grid;grid-template-columns:120px 1fr;gap:.7rem">
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Code *</label>
          <input type="text" name="code" id="p_code" required
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.6rem .8rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif;text-transform:uppercase"
            oninput="this.value=this.value.toUpperCase()">
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Description *</label>
          <input type="text" name="description" id="p_desc" required
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.6rem .8rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.7rem">
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Famille *</label>
          <input type="text" name="famille" id="p_famille" required list="familles_list" placeholder="Ex : Gold"
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.6rem .8rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
          <datalist id="familles_list">
            <?php foreach ($familles as $f): ?>
            <option value="<?= htmlspecialchars($f) ?>">
            <?php endforeach; ?>
          </datalist>
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Contenance (cl) *</label>
          <input type="number" name="contenance_cl" id="p_cl" required min="1"
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.6rem .8rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Emballage *</label>
          <select name="type_emballage" id="p_emb"
            style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                   padding:.6rem .8rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
            <option value="VER">VER (Verre)</option>
            <option value="PET">PET (Plastique)</option>
            <option value="CAN">CAN (Canette)</option>
          </select>
        </div>
      </div>

      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Kit (btl/casier) *</label>
        <input type="number" name="kit" id="p_kit" required min="1"
          style="width:100px;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.6rem .8rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif">
      </div>

      <div style="background:var(--bg3);border-radius:8px;padding:.8rem">
        <div style="font-size:.72rem;font-weight:600;color:var(--text-mute);margin-bottom:.6rem;text-transform:uppercase;letter-spacing:.05em">
          Prix (Ariary)
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.7rem">
          <?php foreach ([
            ['pag_nu','p_pag_nu','PAG unitaire'],
            ['pag_kit_nu','p_pag_kit_nu','PAG kit nu'],
            ['pag_kit_loge','p_pag_loge','PAG kit logé'],
          ] as [$n,$id,$l]): ?>
          <div>
            <label style="font-size:.68rem;color:var(--text-mute);display:block;margin-bottom:.3rem"><?= $l ?></label>
            <input type="number" name="<?= $n ?>" id="<?= $id ?>" min="0" step="1" <?= $n==='pag_kit_loge' ? 'readonly title="Calculé : kit nu + consigne"' : '' ?>
              style="width:100%;background:var(--bg2);border:1px solid var(--border);border-radius:6px;<?= $n==='pag_kit_loge' ? 'opacity:.75;' : '' ?>
                     padding:.5rem .6rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div style="background:var(--bg3);border-radius:8px;padding:.8rem">
        <div style="font-size:.72rem;font-weight:600;color:var(--text-mute);margin-bottom:.6rem;text-transform:uppercase;letter-spacing:.05em">
          Consigne (Ariary)
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem">
          <?php foreach ([['consigne_bouteille','p_csg_btl','Par bouteille'],['consigne_casier','p_csg_cas','Par casier']] as [$n,$id,$l]): ?>
          <div>
            <label style="font-size:.68rem;color:var(--text-mute);display:block;margin-bottom:.3rem"><?= $l ?></label>
            <input type="number" name="<?= $n ?>" id="<?= $id ?>" min="0" step="1" oninput="majLoge()"
              style="width:100%;background:var(--bg2);border:1px solid var(--border);border-radius:6px;
                     padding:.5rem .6rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
          </div>
          <?php endforeach; ?>
        </div>
        <div style="font-size:.65rem;color:var(--text-mute);margin-top:.5rem">
          Grille STAR proposée automatiquement (verre uniquement) : 400 Ar (30/33 cl, Booster 50 cl) · 500 Ar (50 cl bières, 65 cl) · 700 Ar (100 cl et +) · casier 8 000 Ar. Modifiable.
        </div>
      </div>

      <div style="display:flex;gap:.6rem">
        <button type="button" onclick="fermerModal()" class="btn btn-secondary" style="flex:1;justify-content:center">Annuler</button>
        <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center" id="prodSubmitBtn">Créer</button>
      </div>
    </form>
  </div>
</div>

<script>
// Consigne proposée selon la grille STAR (modifiable) + PAG kit logé recalculé
function consigneStar() {
  const cl  = parseInt(document.getElementById('p_cl').value) || 0;
  const emb = document.getElementById('p_emb').value;
  const fam = (document.getElementById('p_famille').value || '').toLowerCase();
  if (emb !== 'VER') return [0, 0];
  const btl = cl >= 100 ? 700 : cl >= 65 ? 500 : cl >= 50 ? (fam.includes('booster') ? 400 : 500) : 400;
  return [btl, 8000];
}
function majConsigne() {                 // appelé quand contenance / emballage / famille change
  const [btl, cas] = consigneStar();
  document.getElementById('p_csg_btl').value = btl;
  document.getElementById('p_csg_cas').value = cas;
  majLoge();
}
function majLoge() {
  const kit = parseInt(document.getElementById('p_kit').value) || 0;
  const nu  = parseFloat(document.getElementById('p_pag_kit_nu').value) || 0;
  const verre = document.getElementById('p_emb').value === 'VER';
  const btl = verre ? (parseFloat(document.getElementById('p_csg_btl').value) || 0) : 0;
  const cas = verre ? (parseFloat(document.getElementById('p_csg_cas').value) || 0) : 0;
  document.getElementById('p_pag_loge').value = Math.round(nu + kit * btl + cas);
}
['p_cl','p_emb','p_famille'].forEach(id => {
  const el = document.getElementById(id);
  if (el) { el.addEventListener('input', majConsigne); el.addEventListener('change', majConsigne); }
});
['p_kit','p_pag_kit_nu'].forEach(id => {
  const el = document.getElementById(id);
  if (el) { el.addEventListener('input', majLoge); el.addEventListener('change', majLoge); }
});
function ouvrirModal() {
  document.getElementById('modalProdTitre').textContent = 'Nouveau produit';
  document.getElementById('prodAction').value = 'creer';
  document.getElementById('prodId').value = '0';
  document.getElementById('formProd').reset();
  document.getElementById('prodSubmitBtn').textContent = 'Créer';
  document.getElementById('modalProd').style.display = 'flex';
}
function editerProduit(p) {
  document.getElementById('modalProdTitre').textContent = 'Modifier ' + p.code;
  document.getElementById('prodAction').value = 'modifier';
  document.getElementById('prodId').value = p.id;
  document.getElementById('p_code').value = p.code;
  document.getElementById('p_desc').value = p.description;
  document.getElementById('p_famille').value = p.famille;
  document.getElementById('p_cl').value = p.contenance_cl;
  document.getElementById('p_emb').value = p.type_emballage;
  document.getElementById('p_kit').value = p.kit;
  document.getElementById('p_pag_nu').value = p.pag_nu;
  document.getElementById('p_pag_kit_nu').value = p.pag_kit_nu;
  document.getElementById('p_pag_loge').value = p.pag_kit_loge;
  document.getElementById('p_csg_btl').value = p.consigne_bouteille;
  document.getElementById('p_csg_cas').value = p.consigne_casier;
  majLoge();   // on garde la consigne enregistrée, seul le prix logé est recalculé
  document.getElementById('prodSubmitBtn').textContent = 'Enregistrer';
  document.getElementById('modalProd').style.display = 'flex';
}
function fermerModal() {
  document.getElementById('modalProd').style.display = 'none';
}
document.getElementById('modalProd').addEventListener('click', function(e) {
  if (e.target === this) fermerModal();
});
</script>

<?php close_layout(); ?>

<?php
// ============================================================
// modules/admin/stock.php
// Vue stock entrepôt (lecture seule pour admin/directeur)
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/stock.php';

$ctx = include_layout('Stock entrepôt', ['ADMIN','DIRECTEUR','MANAGER','MANAGER_INTERIM']);
$user = $ctx['user'];
$db   = getDB();

$filtre = $_GET['filtre'] ?? 'tous';

$stocks = $db->query("
  SELECT p.id AS produit_id,
         " . stock_cols_sql() . ",
         p.description, p.code, p.type_emballage, p.kit,
         p.volume_hl, p.famille
  FROM produits p
  " . stock_join_sql() . "
  WHERE p.actif = 1
  ORDER BY p.famille ASC, p.description ASC
")->fetchAll();

$total_casiers = array_sum(array_column($stocks, 'quantite_casiers'));
$total_hl      = array_sum(array_column($stocks, 'volume_total_hl'));
$nb_alertes    = count(array_filter($stocks, fn($s) => (int)$s['total_bouteilles'] <= 0));

// Mouvements récents
$mouvements = $db->query("
  SELECT m.*, p.description AS produit_nom, p.code,
         CONCAT(u.prenom,' ',u.nom) AS agent_nom,
         c.code_commande
  FROM mouvements_stock m
  JOIN produits p ON m.produit_id = p.id
  JOIN utilisateurs u ON m.logistique_id = u.id
  LEFT JOIN commandes c ON m.commande_id = c.id
  ORDER BY m.created_at DESC LIMIT 30
")->fetchAll();
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Stock entrepôt</div>
      <div class="page-subtitle">
        <?= $total_casiers ?> casiers · <?= number_format($total_hl,2) ?> hl
        <?php if ($nb_alertes > 0): ?>
          · <span style="color:#ffa000">⚠️ <?= $nb_alertes ?> alerte(s)</span>
        <?php endif; ?>
      </div>
    </div>
    <div style="display:flex;gap:.5rem">
      <a href="?filtre=tous" class="btn <?= $filtre==='tous'?'btn-primary':'btn-secondary' ?> btn-sm">Tous</a>
      <a href="?filtre=alerte" class="btn <?= $filtre==='alerte'?'btn-primary':'btn-secondary' ?> btn-sm">
        ⚠️ Alertes (<?= $nb_alertes ?>)
      </a>
    </div>
  </div>
</div>

<div class="grid-2" style="align-items:start">

  <!-- Stock table -->
  <div class="card" style="padding:0;overflow:hidden">
    <table class="data-table">
      <thead>
        <tr>
          <th>Produit</th>
          <th style="text-align:center">Casiers</th>
          <th style="text-align:right">Volume Hl</th>
          <th style="text-align:center">Alerte</th>
          <th style="text-align:center">Statut</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($stocks as $s):
          $en_alerte = (int)$s['total_bouteilles'] <= 0;
          if ($filtre === 'alerte' && !$en_alerte) continue;
        ?>
        <tr style="background:<?= $en_alerte ? 'rgba(255,160,0,.04)' : '' ?>">
          <td>
            <div style="font-weight:500;font-size:.8rem"><?= htmlspecialchars($s['description']) ?></div>
            <div style="font-size:.63rem;color:var(--text-mute)"><?= $s['code'] ?> · <?= $s['famille'] ?></div>
          </td>
          <td style="text-align:center;font-weight:700;font-size:1rem;
                     color:<?= $en_alerte ? '#ffa000' : 'var(--text)' ?>">
            <?= $s['quantite_casiers'] ?>
            <?php if ((int)$s['quantite_bouteilles'] !== 0): ?>
              <span style="font-size:.65rem;color:var(--text-mute);font-weight:500">+ <?= $s['quantite_bouteilles'] ?> btl</span>
            <?php endif; ?>
          </td>
          <td style="text-align:right;color:var(--red);font-weight:600">
            <?= number_format($s['volume_total_hl'],4) ?>
          </td>
          <td style="text-align:center;color:var(--text-mute);font-size:.75rem">
            0
          </td>
          <td style="text-align:center">
            <?= $en_alerte
              ? "<span class='badge badge-orange'>⚠️</span>"
              : "<span class='badge badge-green'>OK</span>" ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Mouvements récents -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:.85rem;font-weight:600">
      🔄 Mouvements récents
    </div>
    <table class="data-table">
      <thead>
        <tr>
          <th>Produit</th><th>Type</th>
          <th style="text-align:center">Qté</th>
          <th>Agent</th><th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($mouvements as $m): ?>
        <tr>
          <td>
            <div style="font-size:.78rem;font-weight:500"><?= htmlspecialchars($m['produit_nom']) ?></div>
            <?php if ($m['code_commande']): ?>
            <div style="font-size:.63rem;color:var(--text-mute)"><?= $m['code_commande'] ?></div>
            <?php endif; ?>
          </td>
          <td><?= match($m['type']) {
            'ENTREE'          => "<span class='badge badge-green' style='font-size:.62rem'>Entrée</span>",
            'SORTIE'          => "<span class='badge badge-red' style='font-size:.62rem'>Sortie</span>",
            'RETOUR_DEFAUT'   => "<span class='badge badge-orange' style='font-size:.62rem'>Retour défaut</span>",
            'RETOUR_CONSIGNE' => "<span class='badge badge-blue' style='font-size:.62rem'>Retour consigne</span>",
            default           => "<span class='badge badge-mute' style='font-size:.62rem'>{$m['type']}</span>",
          } ?></td>
          <td style="text-align:center;font-weight:700">
            <?= trim(($m['quantite_casiers'] > 0 ? $m['quantite_casiers'].' cas.' : '').' '.($m['quantite_bouteilles'] > 0 ? $m['quantite_bouteilles'].' btl' : '')) ?: '—' ?>
          </td>
          <td style="font-size:.7rem"><?= htmlspecialchars($m['agent_nom']) ?></td>
          <td style="font-size:.68rem;color:var(--text-mute)">
            <?= date('d/m H:i', strtotime($m['created_at'])) ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php close_layout(); ?>

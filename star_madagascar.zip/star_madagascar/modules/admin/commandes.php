<?php
// ============================================================
// modules/admin/commandes.php
// Vue globale de toutes les commandes
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx = include_layout('Toutes les commandes', ['ADMIN','DIRECTEUR']);
$user = $ctx['user'];
$db   = getDB();
$editable = ($user['role'] === 'ADMIN');

// Filtres
$date_debut = $_GET['debut'] ?? date('Y-m-d', strtotime('-7 days'));
$date_fin   = $_GET['fin']   ?? date('Y-m-d');
$statut_f   = $_GET['statut'] ?? '';
$type_f     = $_GET['type']   ?? '';
$search     = trim($_GET['q'] ?? '');

$where  = "WHERE DATE(c.date_commande) BETWEEN ? AND ?";
$params = [$date_debut, $date_fin];

if ($statut_f) { $where .= " AND c.statut=?"; $params[] = $statut_f; }
if ($type_f)   { $where .= " AND c.type_commande=?"; $params[] = $type_f; }
if ($search)   { $where .= " AND (c.code_commande LIKE ? OR cl.nom LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }

$stmt = $db->prepare("
  SELECT c.*, cl.nom AS client_nom, cl.code_client, cl.type AS client_type,
         CONCAT(u.prenom,' ',u.nom) AS commercial_nom,
         e.nom AS secteur_nom
  FROM commandes c
  JOIN clients cl ON c.client_id = cl.id
  LEFT JOIN utilisateurs u ON c.commercial_id = u.id
  LEFT JOIN secteurs e ON u.secteur_id = e.id
  $where
  ORDER BY c.date_commande DESC
  LIMIT 200
");
$stmt->execute($params);
$commandes = $stmt->fetchAll();

// Stats
$total_hl     = array_sum(array_column($commandes,'total_hl'));
$total_montant= array_sum(array_column($commandes,'montant_total'));
$nb_cmd       = count($commandes);

$statuts = ['CREEE','VALIDEE','TRANSMISE','EN_ATTENTE_PAIEMENT','PAYEE','EN_PREPARATION','LIVREE','TERMINEE','DEFAUT_SIGNALE'];

// La confirmation des paiements est désormais faite par le CAISSIER
// (modules/caissier/paiements.php) : l'admin garde une vue en lecture seule.
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Toutes les commandes</div>
      <div class="page-subtitle">
        <?= $nb_cmd ?> commande(s) · <?= number_format($total_hl,2) ?> hl · <?= number_format($total_montant) ?> Ar
      </div>
    </div>
  </div>
</div>

<!-- Filtres -->
<div class="card" style="padding:.8rem 1rem;margin-bottom:1rem">
  <form method="GET" style="display:flex;gap:.6rem;flex-wrap:wrap;align-items:center">
    <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
      placeholder="🔍 N° commande ou client..."
      style="flex:1;min-width:180px;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
             padding:.5rem .8rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
    <input type="date" name="debut" value="<?= $date_debut ?>"
      style="background:var(--bg3);border:1px solid var(--border);border-radius:8px;
             padding:.5rem .8rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
    <input type="date" name="fin" value="<?= $date_fin ?>"
      style="background:var(--bg3);border:1px solid var(--border);border-radius:8px;
             padding:.5rem .8rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
    <select name="statut"
      style="background:var(--bg3);border:1px solid var(--border);border-radius:8px;
             padding:.5rem .8rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
      <option value="">Tous statuts</option>
      <?php foreach ($statuts as $s): ?>
      <option value="<?= $s ?>" <?= $statut_f===$s?'selected':'' ?>><?= $s ?></option>
      <?php endforeach; ?>
    </select>
    <select name="type"
      style="background:var(--bg3);border:1px solid var(--border);border-radius:8px;
             padding:.5rem .8rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
      <option value="">Tous types</option>
      <option value="PETIT_CLIENT" <?= $type_f==='PETIT_CLIENT'?'selected':'' ?>>Petit client</option>
      <option value="CLIENT_DIRECT" <?= $type_f==='CLIENT_DIRECT'?'selected':'' ?>>Client direct</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filtrer</button>
  </form>
</div>

<div class="card" style="padding:0;overflow:hidden">
  <table class="data-table">
    <thead>
      <tr>
        <th>N° Commande</th><th>Client</th><th>Type</th>
        <th>Commercial</th><th style="text-align:right">Hl</th>
        <th style="text-align:right">Montant</th><th>Statut</th>
        <th>Date</th><th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($commandes as $c): ?>
      <tr>
        <td style="font-family:monospace;font-size:.72rem;color:var(--text-mute)"><?= htmlspecialchars($c['code_commande']) ?></td>
        <td>
          <div style="font-weight:500;font-size:.8rem"><?= htmlspecialchars($c['client_nom']) ?></div>
          <div style="font-size:.65rem;color:var(--text-mute)"><?= $c['code_client'] ?></div>
        </td>
        <td>
          <span class="badge <?= $c['type_commande']==='CLIENT_DIRECT'?'badge-blue':'badge-mute' ?>" style="font-size:.62rem">
            <?= $c['type_commande']==='CLIENT_DIRECT'?'Direct':'Petit client' ?>
          </span>
        </td>
        <td style="font-size:.75rem"><?= htmlspecialchars($c['commercial_nom']??'—') ?></td>
        <td style="text-align:right;font-weight:700;color:var(--red)"><?= number_format($c['total_hl'],2) ?></td>
        <td style="text-align:right;font-size:.75rem"><?= number_format($c['montant_a_payer']) ?> Ar</td>
        <td><?= statut_badge($c['statut']) ?></td>
        <td style="font-size:.7rem;color:var(--text-mute)"><?= date('d/m H:i', strtotime($c['date_commande'])) ?></td>
        <td>
          <?php if ($c['statut'] === 'EN_ATTENTE_PAIEMENT'): ?>
          <span style="font-size:.65rem;color:var(--text-mute)">À la caisse</span>
          <?php elseif (!empty($c['reference_paiement'])): ?>
          <span style="font-size:.65rem;color:var(--text-mute)" title="Référence paiement"><?= htmlspecialchars($c['reference_paiement']) ?></span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>



<?php
function statut_badge(string $s): string {
  return match($s) {
    'CREEE'               => "<span class='badge badge-mute' style='font-size:.62rem'>Brouillon</span>",
    'VALIDEE'             => "<span class='badge badge-blue' style='font-size:.62rem'>Validée</span>",
    'TRANSMISE'           => "<span class='badge badge-blue' style='font-size:.62rem'>Transmise</span>",
    'EN_ATTENTE_PAIEMENT' => "<span class='badge badge-orange' style='font-size:.62rem'>Att. paiement</span>",
    'PAYEE'               => "<span class='badge badge-green' style='font-size:.62rem'>Payée</span>",
    'EN_PREPARATION'      => "<span class='badge badge-blue' style='font-size:.62rem'>En prépa.</span>",
    'LIVREE'              => "<span class='badge badge-green' style='font-size:.62rem'>Livrée</span>",
    'TERMINEE'            => "<span class='badge badge-mute' style='font-size:.62rem'>Terminée</span>",
    'DEFAUT_SIGNALE'      => "<span class='badge badge-red' style='font-size:.62rem'>Défaut</span>",
    default               => "<span class='badge badge-mute' style='font-size:.62rem'>$s</span>",
  };
}
close_layout();
?>

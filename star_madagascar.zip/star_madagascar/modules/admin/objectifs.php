<?php
require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/objectifs.php';

$ctx = include_layout('Objectifs', ['ADMIN','DIRECTEUR']);
$user = $ctx['user'];
$db = getDB();
$editable = $user['role'] === 'ADMIN';
$msg = '';
$mois = max(1, min(12, (int)($_GET['mois'] ?? date('m'))));
$annee = max(2020, min(2100, (int)($_GET['annee'] ?? date('Y'))));
$noms_mois = ['', 'Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $editable) {
  $action = $_POST['action'] ?? '';
  $mois = max(1, min(12, (int)($_POST['mois'] ?? $mois)));
  $annee = max(2020, min(2100, (int)($_POST['annee'] ?? $annee)));
  try {
    if ($action === 'agence') {
      $hl = max(0, (float)str_replace(',', '.', $_POST['objectif_agence_hl'] ?? 0));
      // Découpage automatique mensuel -> semaines -> jours (lundi au samedi)
      enregistrer_objectif_agence($db, $annee, $mois, $hl, (int)$user['id']);
      $msg = ['success','Objectif de l’agence enregistré et réparti automatiquement par semaine et par jour (lundi–samedi).'];
    } elseif ($action === 'commerciaux') {
      $db->beginTransaction();
      foreach ($_POST as $key=>$val) {
        if (!str_starts_with($key,'obj_clients_')) continue;
        $commercial_id = (int)substr($key,12);
        $nb = max(0,(int)$val);
        $stmt = $db->prepare('SELECT id FROM objectifs WHERE commercial_id=? AND annee=? AND mois=? AND semaine IS NULL AND jour IS NULL LIMIT 1');
        $stmt->execute([$commercial_id,$annee,$mois]);
        $id = $stmt->fetchColumn();
        if ($id) {
          $db->prepare('UPDATE objectifs SET objectif_hl=0, objectif_clients=?, created_by=? WHERE id=?')->execute([$nb,$user['id'],$id]);
        } else {
          $db->prepare('INSERT INTO objectifs (commercial_id,annee,mois,semaine,jour,objectif_hl,objectif_clients,created_by) VALUES (?,?,?,?,?,?,?,?)')->execute([$commercial_id,$annee,$mois,null,null,0,$nb,$user['id']]);
        }
      }
      $db->commit();
      $msg = ['success','Objectifs clients des commerciaux enregistrés.'];
    }
  } catch (Throwable $e) {
    if ($db->inTransaction()) $db->rollBack();
    $msg = ['error','Erreur lors de l’enregistrement : '.$e->getMessage()];
  }
}

$obj_agence = objectifs_agence($db, $annee, $mois);
$objectif_agence_hl = $obj_agence['mois'];
$semaines = semaines_ouvrees($annee, $mois);
$realise_jours = realise_agence_par_jour($db, $annee, $mois);
$realise_mois = array_sum($realise_jours);
$jours_fr = ['', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];

$stmt = $db->prepare("SELECT u.id,u.nom,u.prenom,e.nom AS secteur_nom,
  COALESCE(obj.objectif_clients,0) AS objectif_clients,
  COALESCE(v.nb_visites,0) AS nb_visites,
  COALESCE(c.total_hl,0) AS reel_hl
  FROM utilisateurs u
  LEFT JOIN secteurs e ON e.id=u.secteur_id
  LEFT JOIN objectifs obj ON obj.commercial_id=u.id AND obj.annee=? AND obj.mois=? AND obj.semaine IS NULL AND obj.jour IS NULL
  LEFT JOIN (SELECT commercial_id,COUNT(*) nb_visites FROM visites WHERE statut='VISITE' AND MONTH(date_visite)=? AND YEAR(date_visite)=? GROUP BY commercial_id) v ON v.commercial_id=u.id
  LEFT JOIN (SELECT commercial_id,SUM(total_hl) total_hl FROM commandes WHERE MONTH(date_commande)=? AND YEAR(date_commande)=? AND statut NOT IN ('CREEE') GROUP BY commercial_id) c ON c.commercial_id=u.id
  WHERE u.role IN ('COMMERCIAL','MANAGER_INTERIM') AND u.actif=1
  ORDER BY e.nom,u.nom");
$stmt->execute([$annee,$mois,$mois,$annee,$mois,$annee]);
$commerciaux=$stmt->fetchAll();

$mp=$mois===1?12:$mois-1; $ap=$mois===1?$annee-1:$annee;
$mn=$mois===12?1:$mois+1; $an=$mois===12?$annee+1:$annee;
?>
<div class="page-header"><div class="page-header-top"><div><div class="page-title">Objectifs</div><div class="page-subtitle"><?= $noms_mois[$mois] ?> <?= $annee ?> · agence et commerciaux</div></div><div style="display:flex;gap:.5rem;align-items:center"><a href="?mois=<?=$mp?>&annee=<?=$ap?>" class="btn btn-secondary btn-sm">←</a><span style="font-size:.85rem;font-weight:600"><?=$noms_mois[$mois]?> <?=$annee?></span><a href="?mois=<?=$mn?>&annee=<?=$an?>" class="btn btn-secondary btn-sm">→</a></div></div></div>
<?php if($msg): ?><div class="alert alert-<?=$msg[0]==='success'?'success':'error'?>"><?= $msg[0]==='success'?'✅':'❌' ?> <?=htmlspecialchars($msg[1])?></div><?php endif; ?>
<div class="card card-long" style="margin-bottom:1rem">
  <div style="font-weight:700;margin-bottom:.35rem">🎯 Objectif de l’agence</div>
  <div style="font-size:.75rem;color:var(--text-mute);margin-bottom:.8rem">
    Saisissez l’objectif <strong>mensuel</strong> en HL : il est réparti automatiquement par semaine et par jour ouvré
    (lundi au samedi, <?= nb_jours_ouvres($annee,$mois) ?> jours ce mois-ci). Le réalisé ne compte que les commandes
    <strong>payées</strong> des clients qui achètent à l’agence (Distributeur, GMS, Station, Demi-gros).
  </div>
  <?php if($editable): ?>
  <form method="POST" style="display:flex;gap:.7rem;align-items:end;margin-bottom:1rem;flex-wrap:wrap">
    <input type="hidden" name="action" value="agence"><input type="hidden" name="mois" value="<?=$mois?>"><input type="hidden" name="annee" value="<?=$annee?>">
    <div><label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem">Objectif mensuel HL</label>
      <input type="number" step="0.01" min="0" name="objectif_agence_hl" value="<?=htmlspecialchars((string)$objectif_agence_hl)?>" class="qty-input" style="width:160px"></div>
    <button class="btn btn-primary">Enregistrer et répartir</button>
  </form>
  <?php endif; ?>
  <div class="grid-3" style="margin-bottom:1rem">
    <div class="kpi-card"><div class="kpi-label">Objectif mensuel</div><div class="kpi-value"><?=number_format($objectif_agence_hl,2,',',' ')?> <span class="unit">hl</span></div></div>
    <div class="kpi-card"><div class="kpi-label">Objectif journalier</div><div class="kpi-value"><?=number_format(nb_jours_ouvres($annee,$mois)?$objectif_agence_hl/nb_jours_ouvres($annee,$mois):0,2,',',' ')?> <span class="unit">hl / jour</span></div></div>
    <div class="kpi-card"><div class="kpi-label">Réalisé du mois</div><div class="kpi-value" style="color:<?=$objectif_agence_hl>0&&$realise_mois>=$objectif_agence_hl?'#00c864':'var(--red)'?>"><?=number_format($realise_mois,2,',',' ')?> <span class="unit">hl · <?=$objectif_agence_hl>0?round($realise_mois/$objectif_agence_hl*100):0?> %</span></div></div>
  </div>
  <div class="table-wrap"><table class="data-table">
    <thead><tr><th>Semaine</th><th>Jours</th><th style="text-align:right">Objectif</th><th style="text-align:right">Réalisé</th><th style="text-align:right">%</th></tr></thead>
    <tbody>
    <?php foreach($semaines as $n=>$jours):
      $o_s = $obj_agence['semaines'][$n] ?? 0; $r_s = 0; foreach($jours as $d) $r_s += $realise_jours[$d] ?? 0; ?>
      <tr style="background:var(--bg3)"><td style="font-weight:700">Semaine <?=$n?></td>
        <td style="font-size:.72rem;color:var(--text-mute)"><?=date('d/m',strtotime($jours[0]))?> → <?=date('d/m',strtotime(end($jours)))?> · <?=count($jours)?> j</td>
        <td style="text-align:right;font-weight:700"><?=number_format($o_s,2,',',' ')?> hl</td>
        <td style="text-align:right;font-weight:700;color:var(--red)"><?=number_format($r_s,2,',',' ')?> hl</td>
        <td style="text-align:right"><?=$o_s>0?round($r_s/$o_s*100):0?> %</td></tr>
      <?php foreach($jours as $d): $o_j=$obj_agence['jours'][$d]??0; $r_j=$realise_jours[$d]??0; ?>
      <tr><td style="padding-left:1.6rem;font-size:.75rem"><?=$jours_fr[(int)date('N',strtotime($d))]?> <?=date('d/m',strtotime($d))?><?=$d===date('Y-m-d')?' <span class="badge badge-red" style="font-size:.55rem">Aujourd’hui</span>':''?></td><td></td>
        <td style="text-align:right;font-size:.75rem"><?=number_format($o_j,2,',',' ')?></td>
        <td style="text-align:right;font-size:.75rem"><?=number_format($r_j,2,',',' ')?></td>
        <td style="text-align:right;font-size:.72rem;color:<?=$o_j>0&&$r_j>=$o_j?'#00c864':'var(--text-mute)'?>"><?=$o_j>0?round($r_j/$o_j*100):0?> %</td></tr>
      <?php endforeach; ?>
    <?php endforeach; ?>
    </tbody></table></div>
</div>
<div class="card" style="margin-bottom:1rem"><div style="font-weight:700;margin-bottom:.35rem">👥 Objectifs commerciaux</div><div style="font-size:.75rem;color:var(--text-mute);margin-bottom:1rem">Le commercial a un objectif en <strong>nombre de clients à visiter</strong>. Le HL vendu est une mesure d’activité et sert au calcul de performance/prime, pas de quota commercial.</div>
<?php if($editable): ?><form method="POST"><input type="hidden" name="action" value="commerciaux"><input type="hidden" name="mois" value="<?=$mois?>"><input type="hidden" name="annee" value="<?=$annee?>"><?php endif; ?><div class="table-wrap"><table class="data-table"><thead><tr><th>Commercial</th><th>Secteur</th><th style="text-align:center">Objectif clients</th><th style="text-align:center">Visites</th><th style="text-align:right">HL vendu</th></tr></thead><tbody><?php foreach($commerciaux as $c): ?><tr><td style="font-weight:600"><?=htmlspecialchars($c['prenom'].' '.$c['nom'])?></td><td><?=htmlspecialchars($c['secteur_nom']??'—')?></td><td style="text-align:center"><?php if($editable): ?><input type="number" min="0" name="obj_clients_<?=$c['id']?>" value="<?=$c['objectif_clients']?>" style="width:85px;background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:.4rem;color:var(--text);text-align:center"><?php else: ?><?=$c['objectif_clients']?:'—'?><?php endif; ?></td><td style="text-align:center"><?=$c['nb_visites']?></td><td style="text-align:right;font-weight:700;color:var(--red)"><?=number_format($c['reel_hl'],2)?> hl</td></tr><?php endforeach; ?></tbody></table></div><?php if($editable): ?><div style="display:flex;justify-content:flex-end;margin-top:1rem"><button class="btn btn-primary">💾 Enregistrer</button></div></form><?php endif; ?></div>
<?php close_layout(); ?>

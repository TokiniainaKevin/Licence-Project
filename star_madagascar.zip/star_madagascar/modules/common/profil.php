<?php
// ============================================================
// modules/common/profil.php
// Profil de l'utilisateur connecté : infos, mot de passe, photo de profil
// ============================================================
require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Mon profil');
$user = $ctx['user'];
$db   = getDB();
$msg  = null;

const PHOTO_DIR     = __DIR__ . '/../../assets/images/profils/';
const PHOTO_MAX     = 2 * 1024 * 1024;   // 2 Mo
const PHOTO_TYPES   = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];

$st = $db->prepare('SELECT * FROM utilisateurs WHERE id=?');
$st->execute([$user['id']]);
$me = $st->fetch();

function supprimer_photo_fichier(?string $nom): void {
  if ($nom && preg_match('/^u\d+_\d+\.(jpg|png|webp)$/', $nom) && is_file(PHOTO_DIR . $nom)) @unlink(PHOTO_DIR . $nom);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? 'infos';

  if ($action === 'photo') {
    $f = $_FILES['photo'] ?? null;
    if (!$f || $f['error'] === UPLOAD_ERR_NO_FILE) {
      $msg = ['error', 'Choisissez une image.'];
    } elseif ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > PHOTO_MAX) {
      $msg = ['error', 'Image trop lourde (2 Mo maximum) ou envoi interrompu.'];
    } else {
      // Vérification du contenu réel du fichier (et pas seulement de son extension)
      $info = @getimagesize($f['tmp_name']);
      if (!$info || !isset(PHOTO_TYPES[$info[2]])) {
        $msg = ['error', 'Format non accepté : JPG, PNG ou WEBP uniquement.'];
      } else {
        if (!is_dir(PHOTO_DIR)) @mkdir(PHOTO_DIR, 0755, true);
        $nom = 'u' . (int)$user['id'] . '_' . time() . '.' . PHOTO_TYPES[$info[2]];
        if (move_uploaded_file($f['tmp_name'], PHOTO_DIR . $nom)) {
          supprimer_photo_fichier($me['photo'] ?? null);
          $db->prepare('UPDATE utilisateurs SET photo=? WHERE id=?')->execute([$nom, $user['id']]);
          $_SESSION['user_photo'] = $nom;
          $me['photo'] = $nom;
          $msg = ['success', 'Photo de profil mise à jour.'];
        } else {
          $msg = ['error', "Impossible d'enregistrer l'image (droits du dossier assets/images/profils)."];
        }
      }
    }
  } elseif ($action === 'supprimer_photo') {
    supprimer_photo_fichier($me['photo'] ?? null);
    $db->prepare('UPDATE utilisateurs SET photo=NULL WHERE id=?')->execute([$user['id']]);
    $_SESSION['user_photo'] = null;
    $me['photo'] = null;
    $msg = ['success', 'Photo de profil supprimée.'];
  } else {
    $nom = trim($_POST['nom'] ?? ''); $prenom = trim($_POST['prenom'] ?? '');
    $tel = trim($_POST['telephone'] ?? '');
    $pass = $_POST['password'] ?? ''; $pass2 = $_POST['password2'] ?? '';
    if (!$nom || !$prenom) {
      $msg = ['error', 'Nom et prénom obligatoires.'];
    } elseif ($pass !== '' && strlen($pass) < 8) {
      $msg = ['error', 'Le mot de passe doit contenir au moins 8 caractères.'];
    } elseif ($pass !== $pass2) {
      $msg = ['error', 'Les deux mots de passe ne correspondent pas.'];
    } else {
      if ($pass !== '') {
        $db->prepare('UPDATE utilisateurs SET nom=?,prenom=?,telephone=?,mot_de_passe=? WHERE id=?')
           ->execute([$nom, $prenom, $tel ?: null, password_hash($pass, PASSWORD_DEFAULT), $user['id']]);
      } else {
        $db->prepare('UPDATE utilisateurs SET nom=?,prenom=?,telephone=? WHERE id=?')
           ->execute([$nom, $prenom, $tel ?: null, $user['id']]);
      }
      $_SESSION['user_nom'] = $prenom . ' ' . $nom;
      $me['nom'] = $nom; $me['prenom'] = $prenom; $me['telephone'] = $tel;
      $msg = ['success', 'Profil mis à jour.' . ($pass !== '' ? ' Nouveau mot de passe enregistré.' : '')];
    }
  }
}
// Après un envoi réussi : redirection (le menu, déjà affiché, montre alors
// la nouvelle photo / le nouveau nom, et F5 ne renvoie pas le formulaire)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $msg && $msg[0] === 'success') {
  $_SESSION['flash_profil'] = $msg[1];
  header('Location: profil.php'); exit;
}
if (!$msg && !empty($_SESSION['flash_profil'])) { $msg = ['success', $_SESSION['flash_profil']]; unset($_SESSION['flash_profil']); }
$initiales = initiales($me['prenom'] . ' ' . $me['nom']);
$photo_url = !empty($me['photo']) ? '../../assets/images/profils/' . rawurlencode($me['photo']) : null;
?>
<div class="page-header"><div class="page-title">Mon profil</div><div class="page-subtitle">Informations de votre compte</div></div>
<?php if ($msg): ?><div class="alert alert-<?= $msg[0] === 'success' ? 'success' : 'error' ?>"><?= $msg[0] === 'success' ? '✅' : '❌' ?> <?= htmlspecialchars($msg[1]) ?></div><?php endif; ?>

<style>
.profil-grid{display:grid;grid-template-columns:280px 1fr;gap:1rem;align-items:start;max-width:960px}
@media (max-width:800px){.profil-grid{grid-template-columns:1fr}}
.avatar-xl{width:140px;height:140px;border-radius:50%;margin:0 auto 1rem;overflow:hidden;border:3px solid var(--red);
  display:flex;align-items:center;justify-content:center;background:var(--red-dim);font-size:2.6rem;font-weight:700;color:#fff}
.avatar-xl img{width:100%;height:100%;object-fit:cover}
.profil-grid label{font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.3rem}
.profil-grid .champ{width:100%;padding:.65rem;background:var(--bg3);border:1px solid var(--border);border-radius:8px;color:var(--text);font-family:Inter,sans-serif}
</style>

<div class="profil-grid">
  <div class="card" style="text-align:center">
    <div class="avatar-xl" id="avatarApercu">
      <?php if ($photo_url): ?><img src="<?= $photo_url ?>" alt="Photo de profil"><?php else: ?><?= htmlspecialchars($initiales) ?><?php endif; ?>
    </div>
    <div style="font-weight:700"><?= htmlspecialchars($me['prenom'] . ' ' . $me['nom']) ?></div>
    <div style="font-size:.72rem;color:var(--text-mute);margin-bottom:1rem"><?= htmlspecialchars(role_label($me['role'])) ?></div>
    <form method="POST" enctype="multipart/form-data" style="display:grid;gap:.6rem">
      <input type="hidden" name="action" value="photo">
      <input type="file" name="photo" id="photoInput" accept="image/jpeg,image/png,image/webp" class="champ" style="font-size:.72rem" onchange="apercuPhoto(this)">
      <div style="font-size:.65rem;color:var(--text-mute)">JPG, PNG ou WEBP · 2 Mo maximum</div>
      <button class="btn btn-primary" style="justify-content:center">📷 Enregistrer la photo</button>
    </form>
    <?php if ($photo_url): ?>
    <form method="POST" style="margin-top:.5rem" onsubmit="return confirm('Supprimer la photo de profil ?')">
      <input type="hidden" name="action" value="supprimer_photo">
      <button class="btn btn-secondary btn-sm" style="width:100%;justify-content:center">Supprimer la photo</button>
    </form>
    <?php endif; ?>
  </div>

  <div class="card">
    <form method="POST" style="display:grid;gap:.9rem">
      <input type="hidden" name="action" value="infos">
      <div class="grid-2">
        <div><label>Nom</label><input name="nom" required value="<?= htmlspecialchars($me['nom']) ?>" class="champ"></div>
        <div><label>Prénom</label><input name="prenom" required value="<?= htmlspecialchars($me['prenom']) ?>" class="champ"></div>
      </div>
      <div><label>Email</label><input value="<?= htmlspecialchars($me['email']) ?>" disabled class="champ" style="color:var(--text-mute)"></div>
      <div><label>Téléphone</label><input name="telephone" value="<?= htmlspecialchars($me['telephone'] ?? '') ?>" class="champ"></div>
      <div class="grid-2">
        <div><label>Nouveau mot de passe</label><input type="password" name="password" minlength="8" placeholder="Laisser vide pour conserver" class="champ" autocomplete="new-password"></div>
        <div><label>Confirmer le mot de passe</label><input type="password" name="password2" class="champ" autocomplete="new-password"></div>
      </div>
      <div style="display:flex;justify-content:flex-end"><button class="btn btn-primary">Enregistrer</button></div>
    </form>
  </div>
</div>
<script>
function apercuPhoto(input) {
  const f = input.files && input.files[0];
  if (!f) return;
  if (f.size > <?= PHOTO_MAX ?>) { alert('Image trop lourde (2 Mo maximum).'); input.value = ''; return; }
  const r = new FileReader();
  r.onload = e => { document.getElementById('avatarApercu').innerHTML = '<img src="' + e.target.result + '" alt="">'; };
  r.readAsDataURL(f);
}
</script>
<?php close_layout(); ?>

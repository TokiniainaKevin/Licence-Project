<?php
require_once '../../includes/layout.php'; require_once '../../config/db.php';
$ctx=include_layout('Notifications'); $user=$ctx['user']; $db=getDB();
if($_SERVER['REQUEST_METHOD']==='POST'){$db->prepare('UPDATE notifications SET lu=1 WHERE utilisateur_id=?')->execute([$user['id']]);}
$st=$db->prepare('SELECT * FROM notifications WHERE utilisateur_id=? ORDER BY created_at DESC LIMIT 50');$st->execute([$user['id']]);$items=$st->fetchAll();
?>
<div class="page-header"><div class="page-header-top"><div><div class="page-title">Notifications</div><div class="page-subtitle"><?=count($items)?> notification(s)</div></div><form method="POST"><button class="btn btn-secondary btn-sm">Tout marquer comme lu</button></form></div></div>
<div class="card" style="padding:0;overflow:hidden"><?php if(!$items): ?><div style="padding:2rem;text-align:center;color:var(--text-mute)">Aucune notification.</div><?php else: ?><table class="data-table"><thead><tr><th>Titre</th><th>Message</th><th>Date</th><th>État</th></tr></thead><tbody><?php foreach($items as $n): ?><tr><td style="font-weight:600"><?=htmlspecialchars($n['titre'])?></td><td><?=htmlspecialchars($n['message'])?></td><td><?=date('d/m/Y H:i',strtotime($n['created_at']))?></td><td><?=$n['lu']?'<span class="badge badge-mute">Lue</span>':'<span class="badge badge-red">Nouvelle</span>'?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?></div>
<?php close_layout(); ?>

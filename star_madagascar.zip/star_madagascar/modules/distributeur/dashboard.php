<?php
// ============================================================
// modules/distributeur/dashboard.php
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Mon espace', ['DISTRIBUTEUR']);
$user = $ctx['user'];
$db   = getDB();

// Récupérer le client associé à cet utilisateur
$stmt = $db->prepare("SELECT * FROM clients WHERE utilisateur_id=? LIMIT 1");
$stmt->execute([$user['id']]);
$mon_client = $stmt->fetch();

if (!$mon_client) {
  echo '<div class="alert alert-error">⚠️ Aucun compte distributeur associé. Contactez l\'administrateur.</div>';
  close_layout();
  exit;
}

$client_id = $mon_client['id'];

// Commandes à livrer demain
$demain = date('Y-m-d', strtotime('+1 day'));
$stmt = $db->prepare("
  SELECT c.*, cl.nom AS client_nom, cl.code_client, cl.adresse, cl.quartier
  FROM commandes c
  JOIN clients cl ON c.client_id = cl.id
  WHERE c.distributeur_id = ?
    AND c.date_livraison = ?
    AND c.statut IN ('VALIDEE','TRANSMISE')
  ORDER BY cl.quartier ASC, cl.nom ASC
");
$stmt->execute([$client_id, $demain]);
$livraisons_demain = $stmt->fetchAll();

// Mes propres commandes récentes (stock agence)
$stmt = $db->prepare("
  SELECT c.*, COUNT(lc.id) AS nb_produits
  FROM commandes c
  LEFT JOIN lignes_commande lc ON lc.commande_id = c.id
  WHERE c.client_id = ?
  GROUP BY c.id
  ORDER BY c.date_commande DESC LIMIT 5
");
$stmt->execute([$client_id]);
$mes_commandes = $stmt->fetchAll();

// Solde consigne
$stmt = $db->prepare("SELECT solde_ariary FROM solde_consigne WHERE client_id=?");
$stmt->execute([$client_id]);
$sc = $stmt->fetch();
$solde_consigne = $sc ? $sc['solde_ariary'] : 0;

// Total Hl à livrer demain
$total_hl_demain = array_sum(array_column($livraisons_demain, 'total_hl'));
$total_clients_demain = count($livraisons_demain);
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title"><?= htmlspecialchars($mon_client['nom']) ?></div>
      <div class="page-subtitle">Code : <?= htmlspecialchars($mon_client['code_client']) ?> · Distributeur</div>
    </div>
    <a href="commande.php" class="btn btn-primary">+ Passer une commande</a>
  </div>
</div>

<!-- KPI -->
<div class="grid-3" style="margin-bottom:1.2rem">
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Livraisons demain</div>
    <div class="kpi-value"><?= $total_clients_demain ?> <span class="unit">clients</span></div>
    <div class="kpi-trend neutral"><?= number_format($total_hl_demain,2) ?> hl à livrer</div>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Solde consigne</div>
    <div class="kpi-value" style="font-size:1.4rem"><?= number_format($solde_consigne) ?> <span class="unit" style="font-size:.7rem">Ar</span></div>
    <div class="kpi-trend neutral">Déductible sur prochain achat</div>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Mes commandes</div>
    <div class="kpi-value"><?= count($mes_commandes) ?> <span class="unit">récentes</span></div>
    <a href="historique.php" style="font-size:.72rem;color:var(--red);display:block;margin-top:.4rem">Voir l'historique →</a>
  </div>
</div>

<div class="grid-2">

  <!-- Livraisons demain -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center">
      <div>
        <div style="font-size:.85rem;font-weight:600">🚚 À livrer demain</div>
        <div style="font-size:.7rem;color:var(--text-mute)"><?= date('d/m/Y', strtotime('+1 day')) ?></div>
      </div>
      <a href="a_livrer.php" class="btn btn-secondary btn-sm">Voir tout</a>
    </div>
    <?php if (empty($livraisons_demain)): ?>
    <div style="padding:2rem;text-align:center;color:var(--text-mute);font-size:.82rem">
      Aucune livraison prévue demain.
    </div>
    <?php else: ?>
    <table class="data-table">
      <thead>
        <tr><th>Client</th><th>Quartier</th><th style="text-align:right">Hl</th><th style="text-align:right">Montant</th></tr>
      </thead>
      <tbody>
        <?php foreach ($livraisons_demain as $l): ?>
        <tr>
          <td>
            <div style="font-weight:500"><?= htmlspecialchars($l['client_nom']) ?></div>
            <div style="font-size:.65rem;color:var(--text-mute)"><?= $l['code_client'] ?></div>
          </td>
          <td style="font-size:.75rem"><?= htmlspecialchars($l['quartier'] ?? '—') ?></td>
          <td style="text-align:right;font-weight:700;color:var(--red)"><?= number_format($l['total_hl'],2) ?></td>
          <td style="text-align:right;font-size:.75rem"><?= number_format($l['montant_total']) ?> Ar</td>
        </tr>
        <?php endforeach; ?>
        <tr style="background:var(--bg3)">
          <td colspan="2" style="font-weight:700;font-size:.78rem">TOTAL</td>
          <td style="text-align:right;font-weight:700;color:var(--red)"><?= number_format($total_hl_demain,2) ?></td>
          <td style="text-align:right;font-weight:600"><?= number_format(array_sum(array_column($livraisons_demain,'montant_total'))) ?> Ar</td>
        </tr>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

  <!-- Mes commandes récentes -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center">
      <div style="font-size:.85rem;font-weight:600">📋 Mes commandes récentes</div>
      <a href="historique.php" class="btn btn-secondary btn-sm">Historique</a>
    </div>
    <?php if (empty($mes_commandes)): ?>
    <div style="padding:2rem;text-align:center;color:var(--text-mute);font-size:.82rem">
      Aucune commande passée.<br>
      <a href="commande.php" style="color:var(--red)">Passer ma première commande →</a>
    </div>
    <?php else: ?>
    <table class="data-table">
      <thead>
        <tr><th>N°</th><th style="text-align:right">Hl</th><th style="text-align:right">Montant</th><th>Statut</th></tr>
      </thead>
      <tbody>
        <?php foreach ($mes_commandes as $c): ?>
        <tr>
          <td>
            <div style="font-family:monospace;font-size:.72rem;color:var(--text-mute)"><?= $c['code_commande'] ?></div>
            <div style="font-size:.65rem;color:var(--text-mute)"><?= date('d/m/Y', strtotime($c['date_commande'])) ?></div>
          </td>
          <td style="text-align:right;font-weight:700;color:var(--red)"><?= number_format($c['total_hl'],2) ?></td>
          <td style="text-align:right;font-size:.75rem"><?= number_format($c['montant_a_payer']) ?> Ar</td>
          <td><?= statut_badge($c['statut']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

</div>

<?php
function statut_badge(string $s): string {
  return match($s) {
    'EN_ATTENTE_PAIEMENT' => "<span class='badge badge-orange'>Att. paiement</span>",
    'PAYEE'               => "<span class='badge badge-green'>Payée</span>",
    'EN_PREPARATION'      => "<span class='badge badge-blue'>En préparation</span>",
    'LIVREE'              => "<span class='badge badge-green'>Livrée</span>",
    'TERMINEE'            => "<span class='badge badge-mute'>Terminée</span>",
    default               => "<span class='badge badge-mute'>$s</span>",
  };
}
?>
<!-- ── Graphiques ─────────────────────────────────────────── -->
<?php
$j30 = jours_periode(30);
$st = $db->prepare("SELECT DATE(date_commande) d, SUM(total_hl) v FROM commandes WHERE client_id=? AND statut NOT IN ('CREEE') AND date_commande >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY DATE(date_commande)");
$st->execute([$client_id]); $achats = serie($j30, $st->fetchAll());
$st = $db->prepare("SELECT DATE(date_livraison) d, SUM(total_hl) v FROM commandes WHERE distributeur_id=? AND statut IN ('LIVREE','TERMINEE','DEFAUT_SIGNALE') AND date_livraison >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY DATE(date_livraison)");
$st->execute([$client_id]); $livres = serie($j30, $st->fetchAll());
?>
<div style="margin-top:1rem">
<?= graphique('gDist', 'Mes achats à l’agence et mes livraisons aux petits clients (30 jours)', ['type'=>'bar','unite'=>'hl','data'=>['labels'=>etiquettes_jours($j30),'datasets'=>[
  ['label'=>'Achats à l’agence','data'=>array_values($achats),'backgroundColor'=>'rgba(232,0,28,.75)','borderRadius'=>3],
  ['label'=>'Livré aux petits clients','data'=>array_values($livres),'backgroundColor'=>'rgba(31,157,85,.8)','borderRadius'=>3],
]],'options'=>['scales'=>['y'=>['beginAtZero'=>true,'title'=>['display'=>true,'text'=>'hl']]]]], 280) ?>
</div>

<?php close_layout();
?>

<?php
// ============================================================
// modules/distributeur/detail_commande.php (fragment AJAX)
// ============================================================

session_start();
require_once '../../includes/auth_guard.php';
require_once '../../config/db.php';

auth_guard(['DISTRIBUTEUR']);
$user = current_user();
$db   = getDB();

$cmd_id = (int)($_GET['id'] ?? 0);
if (!$cmd_id) { echo '<p>Commande introuvable.</p>'; exit; }

// Vérifier appartenance
$stmt = $db->prepare("
  SELECT c.*, cl.nom AS client_nom, cl.code_client
  FROM commandes c
  JOIN clients cl ON c.client_id = cl.id
  WHERE c.id = ? AND cl.utilisateur_id = ?
");
$stmt->execute([$cmd_id, $user['id']]);
$cmd = $stmt->fetch();
if (!$cmd) { echo '<p style="color:var(--red)">Accès refusé.</p>'; exit; }

// Lignes
$stmt = $db->prepare("
  SELECT lc.*, p.description, p.code, p.type_emballage
  FROM lignes_commande lc
  JOIN produits p ON lc.produit_id = p.id
  WHERE lc.commande_id = ?
");
$stmt->execute([$cmd_id]);
$lignes = $stmt->fetchAll();
?>
<div style="margin-bottom:1rem">
  <div style="display:flex;justify-content:space-between;margin-bottom:.4rem">
    <div style="font-size:.7rem;color:var(--text-mute)">N° Commande</div>
    <div style="font-family:monospace;font-weight:700;color:var(--red)"><?= htmlspecialchars($cmd['code_commande']) ?></div>
  </div>
  <div style="display:flex;justify-content:space-between;margin-bottom:.4rem">
    <div style="font-size:.7rem;color:var(--text-mute)">Date</div>
    <div style="font-size:.8rem"><?= date('d/m/Y H:i', strtotime($cmd['date_commande'])) ?></div>
  </div>
  <div style="display:flex;justify-content:space-between;margin-bottom:.4rem">
    <div style="font-size:.7rem;color:var(--text-mute)">Mode paiement</div>
    <div style="font-size:.8rem"><?= $cmd['mode_paiement'] ?? '—' ?></div>
  </div>
  <?php if ($cmd['reference_paiement']): ?>
  <div style="display:flex;justify-content:space-between;margin-bottom:.4rem">
    <div style="font-size:.7rem;color:var(--text-mute)">Référence paiement</div>
    <div style="font-size:.78rem;font-family:monospace"><?= htmlspecialchars($cmd['reference_paiement']) ?></div>
  </div>
  <?php endif; ?>
</div>

<table style="width:100%;border-collapse:collapse;font-size:.78rem;margin-bottom:1rem">
  <thead>
    <tr style="background:var(--bg3)">
      <th style="padding:.4rem .6rem;text-align:left;color:var(--text-mute);font-size:.65rem">Produit</th>
      <th style="padding:.4rem .6rem;text-align:center;color:var(--text-mute);font-size:.65rem">Quantité</th>
      <th style="padding:.4rem .6rem;text-align:right;color:var(--text-mute);font-size:.65rem">Montant</th>
      <th style="padding:.4rem .6rem;text-align:right;color:var(--text-mute);font-size:.65rem">Volume</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($lignes as $l): ?>
    <tr style="border-bottom:1px solid var(--bg3)">
      <td style="padding:.4rem .6rem">
        <div style="font-weight:500"><?= htmlspecialchars($l['description']) ?></div>
        <div style="font-size:.63rem;color:var(--text-mute)"><?= $l['code'] ?></div>
      </td>
      <td style="padding:.4rem .6rem;text-align:center;font-weight:700"><?= trim(($l['quantite_casiers'] ? $l['quantite_casiers'].' cas.' : '').' '.($l['quantite_bouteilles'] ? '+ '.$l['quantite_bouteilles'].' btl' : '')) ?></td>
      <td style="padding:.4rem .6rem;text-align:right"><?= number_format($l['sous_total']) ?> Ar</td>
      <td style="padding:.4rem .6rem;text-align:right;font-weight:700;color:var(--red);white-space:nowrap"><?= number_format($l['volume_hl'],4) ?> hl</td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<div style="border-top:1px solid var(--border);padding-top:.8rem">
  <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-bottom:.3rem">
    <span style="color:var(--text-mute)">Volume total</span>
    <span style="font-weight:700;color:var(--red)"><?= number_format($cmd['total_hl'],4) ?> hl</span>
  </div>
  <?php if ($cmd['credit_consigne_utilise'] > 0): ?>
  <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-bottom:.3rem;color:#00c864">
    <span>Crédit consigne déduit</span>
    <span>−<?= number_format($cmd['credit_consigne_utilise']) ?> Ar</span>
  </div>
  <?php endif; ?>
  <div style="display:flex;justify-content:space-between;font-size:.92rem;font-weight:700;margin-top:.3rem">
    <span><?= $cmd['statut_paiement']==='CONFIRME' ? 'Total payé' : 'Total à payer' ?></span>
    <span style="color:var(--red)"><?= number_format($cmd['montant_a_payer']) ?> Ar</span>
  </div>
</div>

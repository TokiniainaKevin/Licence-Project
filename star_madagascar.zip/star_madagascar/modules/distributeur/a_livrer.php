<?php
// ============================================================
// modules/distributeur/a_livrer.php
// Détail des livraisons du lendemain
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('À livrer demain', ['DISTRIBUTEUR']);
$user = $ctx['user'];
$db   = getDB();

$stmt = $db->prepare("SELECT * FROM clients WHERE utilisateur_id=? LIMIT 1");
$stmt->execute([$user['id']]);
$mon_client = $stmt->fetch();
if (!$mon_client) { close_layout(); exit; }

$client_id = $mon_client['id'];
$demain    = date('Y-m-d', strtotime('+1 day'));

// Le distributeur confirme la livraison chez le petit client (avant, aucune
// action n'existait : les commandes restaient « Validée » indéfiniment).
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'livrer') {
  $st = $db->prepare("UPDATE commandes SET statut='LIVREE' WHERE id=? AND distributeur_id=? AND statut IN ('VALIDEE','TRANSMISE')");
  $st->execute([(int)($_POST['commande_id'] ?? 0), $client_id]);
  $_SESSION['flash_ok'] = $st->rowCount() ? 'Livraison confirmée.' : '';
  header('Location: a_livrer.php'); exit;
}
$flash_ok = $_SESSION['flash_ok'] ?? ''; unset($_SESSION['flash_ok']);

$stmt = $db->prepare("
  SELECT c.*, cl.nom AS client_nom, cl.code_client,
         cl.adresse, cl.quartier, cl.telephone AS client_tel,
         CONCAT(u.prenom,' ',u.nom) AS commercial_nom
  FROM commandes c
  JOIN clients cl ON c.client_id = cl.id
  LEFT JOIN utilisateurs u ON c.commercial_id = u.id
  WHERE c.distributeur_id = ?
    AND c.date_livraison <= ?          -- demain + les livraisons en retard
    AND c.statut IN ('VALIDEE','TRANSMISE')
  ORDER BY cl.quartier ASC, cl.nom ASC
");
$stmt->execute([$client_id, $demain]);
$livraisons = $stmt->fetchAll();

$total_hl     = array_sum(array_column($livraisons, 'total_hl'));
$total_montant= array_sum(array_column($livraisons, 'montant_total'));
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Livraisons à effectuer (jusqu’au <?= date('d/m/Y', strtotime('+1 day')) ?>)</div>
      <div class="page-subtitle"><?= count($livraisons) ?> client(s) · <?= number_format($total_hl,2) ?> hl</div>
    </div>
    <button onclick="window.print()" class="btn btn-secondary">🖨️ Imprimer la liste</button>
  </div>
</div>

<?php if ($flash_ok): ?><div class="alert alert-success">✅ <?= htmlspecialchars($flash_ok) ?></div><?php endif; ?>
<?php if (empty($livraisons)): ?>
<div class="card" style="text-align:center;padding:3rem">
  <div style="font-size:2rem;margin-bottom:.8rem">📭</div>
  <div style="font-weight:600">Aucune livraison prévue pour demain.</div>
</div>
<?php else: ?>

<!-- Récap -->
<div class="grid-3" style="margin-bottom:1.2rem">
  <div class="card kpi-card card-top-line">
    <div class="kpi-label">Clients à livrer</div>
    <div class="kpi-value"><?= count($livraisons) ?> <span class="unit">clients</span></div>
  </div>
  <div class="card kpi-card card-top-line">
    <div class="kpi-label">Volume total</div>
    <div class="kpi-value"><?= number_format($total_hl,2) ?> <span class="unit">hl</span></div>
  </div>
  <div class="card kpi-card card-top-line">
    <div class="kpi-label">Montant total</div>
    <div class="kpi-value" style="font-size:1.3rem"><?= number_format($total_montant) ?> <span class="unit" style="font-size:.7rem">Ar</span></div>
  </div>
</div>

<!-- Par quartier -->
<?php
$par_quartier = [];
foreach ($livraisons as $l) {
  $q = $l['quartier'] ?: 'Sans quartier';
  $par_quartier[$q][] = $l;
}
?>

<?php foreach ($par_quartier as $quartier => $clients): ?>
<div style="margin-bottom:1.2rem">
  <div style="font-size:.7rem;font-weight:700;color:var(--text-mute);
              text-transform:uppercase;letter-spacing:.08em;
              margin-bottom:.6rem;padding:.3rem .7rem;
              background:var(--bg3);border-radius:6px;display:inline-block">
    📍 <?= htmlspecialchars($quartier) ?> (<?= count($clients) ?> clients)
  </div>

  <?php foreach ($clients as $c):
    $stmt = $db->prepare("
      SELECT lc.*, p.description, p.code
      FROM lignes_commande lc
      JOIN produits p ON lc.produit_id = p.id
      WHERE lc.commande_id = ?
    ");
    $stmt->execute([$c['id']]);
    $lignes = $stmt->fetchAll();
  ?>
  <div class="card" style="margin-bottom:.6rem;padding:0;overflow:hidden">
    <div style="padding:.8rem 1.1rem;background:var(--bg3);border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center">
      <div>
        <div style="font-weight:700"><?= htmlspecialchars($c['client_nom']) ?></div>
        <div style="font-size:.7rem;color:var(--text-mute)">
          <?= $c['code_client'] ?> · <?= htmlspecialchars($c['adresse'] ?? '') ?>
          <?php if ($c['client_tel']): ?> · <?= htmlspecialchars($c['client_tel']) ?><?php endif; ?>
        </div>
      </div>
      <div style="text-align:right">
        <div style="font-weight:700;color:var(--red)"><?= number_format($c['total_hl'],2) ?> hl</div>
        <div style="font-size:.7rem;color:var(--text-mute)"><?= number_format($c['montant_total']) ?> Ar</div>
      </div>
    </div>
    <div style="padding:.6rem 1.1rem">
      <?php foreach ($lignes as $l): ?>
      <div style="display:flex;justify-content:space-between;font-size:.75rem;
                  padding:.25rem 0;border-bottom:1px solid var(--bg3)">
        <span><?= htmlspecialchars($l['description']) ?></span>
        <span style="font-weight:600">
          <?= $l['quantite_casiers'] > 0 ? $l['quantite_casiers'].' casier(s)' : '' ?>
          <?= $l['quantite_bouteilles'] > 0 ? ' + '.$l['quantite_bouteilles'].' btl' : '' ?>
        </span>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="padding:.5rem 1.1rem;text-align:right">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:.6rem;flex-wrap:wrap">
        <div style="font-size:.68rem;color:var(--text-mute)">
          N° <?= $c['code_commande'] ?> · Commercial : <?= htmlspecialchars($c['commercial_nom'] ?? '—') ?>
          · Livraison <?= date('d/m', strtotime($c['date_livraison'])) ?>
          <?= $c['date_livraison'] < date('Y-m-d') ? ' <span class="badge badge-red" style="font-size:.6rem">En retard</span>' : '' ?>
        </div>
        <form method="POST" onsubmit="return confirm('Confirmer la livraison de cette commande ?')">
          <input type="hidden" name="action" value="livrer"><input type="hidden" name="commande_id" value="<?= $c['id'] ?>">
          <button class="btn btn-primary btn-sm">✅ Livrée</button>
        </form>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endforeach; ?>
<?php endif; ?>

<style>
@media print {
  .hamburger, .side-drawer, .drawer-overlay, .app-slider-bg, .btn, button { display: none !important; }
  .card { border: 1px solid #ccc !important; break-inside: avoid; }
  body { background: #fff !important; color: #000 !important; overflow: visible !important; }
  .main-content { padding: 0 !important; height: auto !important; overflow: visible !important; }
}
</style>

<?php close_layout(); ?>

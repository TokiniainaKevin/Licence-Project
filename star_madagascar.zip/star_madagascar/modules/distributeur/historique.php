<?php
// ============================================================
// modules/distributeur/historique.php
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Historique commandes', ['DISTRIBUTEUR']);
$user = $ctx['user'];
$db   = getDB();

$stmt = $db->prepare("SELECT * FROM clients WHERE utilisateur_id=? LIMIT 1");
$stmt->execute([$user['id']]);
$mon_client = $stmt->fetch();
if (!$mon_client) { close_layout(); exit; }

$client_id = $mon_client['id'];

// Commandes
$stmt = $db->prepare("
  SELECT c.*, COUNT(lc.id) AS nb_produits
  FROM commandes c
  LEFT JOIN lignes_commande lc ON lc.commande_id = c.id
  WHERE c.client_id = ?
  GROUP BY c.id
  ORDER BY c.date_commande DESC
");
$stmt->execute([$client_id]);
$commandes = $stmt->fetchAll();

// Solde consigne
$stmt = $db->prepare("SELECT solde_ariary FROM solde_consigne WHERE client_id=?");
$stmt->execute([$client_id]);
$sc = $stmt->fetch();
$solde = $sc ? $sc['solde_ariary'] : 0;
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Historique des commandes</div>
      <div class="page-subtitle">
        <?= count($commandes) ?> commande(s) · Solde consigne :
        <strong style="color:#00c864"><?= number_format($solde) ?> Ar</strong>
      </div>
    </div>
    <a href="dashboard.php" class="btn btn-secondary">← Retour</a>
  </div>
</div>

<div class="card" style="padding:0;overflow:hidden">
  <table class="data-table">
    <thead>
      <tr>
        <th>N° Commande</th>
        <th style="text-align:right">Hl</th>
        <th style="text-align:right">Montant payé</th>
        <th style="text-align:center">Mode paiement</th>
        <th>Statut</th>
        <th>Date</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($commandes as $c): ?>
      <tr>
        <td>
          <div style="font-family:monospace;font-size:.75rem;font-weight:700;color:var(--red)">
            <?= htmlspecialchars($c['code_commande']) ?>
          </div>
          <div style="font-size:.65rem;color:var(--text-mute)"><?= $c['nb_produits'] ?> produit(s)</div>
        </td>
        <td style="text-align:right;font-weight:700;color:var(--red)">
          <?= number_format($c['total_hl'],2) ?>
        </td>
        <td style="text-align:right;font-size:.78rem">
          <?= number_format($c['montant_a_payer']) ?> Ar
        </td>
        <td style="text-align:center;font-size:.72rem">
          <?= $c['mode_paiement'] ? htmlspecialchars($c['mode_paiement']) : '—' ?>
        </td>
        <td><?= statut_badge($c['statut']) ?></td>
        <td style="font-size:.72rem;color:var(--text-mute)">
          <?= date('d/m/Y', strtotime($c['date_commande'])) ?>
        </td>
        <td>
          <button onclick="voirDetail(<?= $c['id'] ?>)" class="btn btn-secondary btn-sm">
            Détail
          </button>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<!-- Modal détail commande -->
<div id="modalDetail" style="display:none;position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.7);backdrop-filter:blur(4px);align-items:flex-start;
  justify-content:center;padding-top:60px">
  <div class="modal-box" style="border:1px solid var(--border);border-radius:16px;
              width:90%;max-width:520px;overflow:hidden">
    <div style="padding:1rem 1.2rem;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center">
      <div style="font-weight:700" id="detailTitre">Détail commande</div>
      <button onclick="document.getElementById('modalDetail').style.display='none'"
        style="background:none;border:none;color:var(--text-mute);cursor:pointer;font-size:1.2rem">✕</button>
    </div>
    <div id="detailContenu" style="padding:1.2rem;max-height:60vh;overflow-y:auto">
      <div style="text-align:center;color:var(--text-mute)">Chargement...</div>
    </div>
  </div>
</div>

<script>
function voirDetail(cmdId) {
  document.getElementById('modalDetail').style.display = 'flex';
  document.getElementById('detailContenu').innerHTML = '<div style="text-align:center;padding:2rem;color:var(--text-mute)">Chargement...</div>';

  fetch('detail_commande.php?id=' + cmdId)
    .then(r => r.text())
    .then(html => {
      document.getElementById('detailContenu').innerHTML = html;
    })
    .catch(() => {
      document.getElementById('detailContenu').innerHTML = '<div style="color:var(--red)">Erreur de chargement.</div>';
    });
}
</script>

<?php
function statut_badge(string $s): string {
  return match($s) {
    'EN_ATTENTE_PAIEMENT' => "<span class='badge badge-orange'>Att. paiement</span>",
    'PAYEE'               => "<span class='badge badge-green'>Payée</span>",
    'EN_PREPARATION'      => "<span class='badge badge-blue'>En préparation</span>",
    'LIVREE'              => "<span class='badge badge-green'>Livrée</span>",
    'TERMINEE'            => "<span class='badge badge-mute'>Terminée</span>",
    default               => "<span class='badge badge-mute'>$s</span>",
  };
}
close_layout();
?>

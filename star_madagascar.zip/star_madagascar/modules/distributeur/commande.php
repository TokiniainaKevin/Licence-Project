<?php
// ============================================================
// modules/distributeur/commande.php
// Distributeur passe une commande à l'agence
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/tarifs.php';
require_once '../../includes/paiement.php';
require_once '../../includes/recu.php';

$ctx  = include_layout('Passer une commande', ['DISTRIBUTEUR']);
$user = $ctx['user'];
$db   = getDB();

$stmt = $db->prepare("SELECT * FROM clients WHERE utilisateur_id=? LIMIT 1");
$stmt->execute([$user['id']]);
$mon_client = $stmt->fetch();
if (!$mon_client) { close_layout(); exit; }

$client_id = $mon_client['id'];

// Solde consigne
$stmt = $db->prepare("SELECT solde_ariary FROM solde_consigne WHERE client_id=?");
$stmt->execute([$client_id]);
$sc = $stmt->fetch();
$solde_consigne = $sc ? $sc['solde_ariary'] : 0;

// Produits
$produits = $db->query("
  SELECT p.*, p.famille AS famille_nom
  FROM produits p
  WHERE p.actif = 1
  ORDER BY p.famille ASC, p.description ASC
")->fetchAll();

$familles = [];
foreach ($produits as $p) $familles[$p['famille_nom']][] = $p;

// Traitement commande confirmée
$success = $error = '';
$commande_creee = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['etape'] ?? '') === 'confirmer') {
  $panier_json = $_POST['panier_json'] ?? '[]';
  $panier      = json_decode($panier_json, true) ?? [];
  $panier      = array_filter($panier, fn($p) => ($p['casiers']??0)>0 || ($p['bouteilles']??0)>0);

  if (!empty($panier)) {
    try {
      $db->beginTransaction();

      $total_hl = $total_prod = $total_csg = 0;

      foreach ($panier as &$ligne) {
        $stmt = $db->prepare("SELECT * FROM produits WHERE id=?");
        $stmt->execute([(int)$ligne['produit_id']]);
        $prod = $stmt->fetch();
        if (!$prod) continue;

        $c = (int)($ligne['casiers'] ?? 0);
        $b = (int)($ligne['bouteilles'] ?? 0);

        $k = calcul_ligne($prod, $c, $b);
        $total_hl   += $k['vol'];
        $total_prod += $k['prix'];
        $total_csg  += $k['csg'];
        $ligne['prod'] = $prod;
      }
      unset($ligne);

      $credit = min($solde_consigne, $total_csg);
      $a_payer = $total_prod + $total_csg - $credit;

      $code_cmd = 'DIST-' . date('Ymd') . '-' . str_pad(
        $db->query("SELECT COUNT(*)+1 FROM commandes WHERE DATE(date_commande)=CURDATE() AND type_commande='CLIENT_DIRECT'")->fetchColumn(),
        4, '0', STR_PAD_LEFT
      );

      $stmt = $db->prepare("
        INSERT INTO commandes
          (code_commande, client_id, type_commande, total_hl, montant_ht,
           montant_consigne, montant_total, credit_consigne_utilise, montant_a_payer, statut)
        VALUES (?,?,'CLIENT_DIRECT',?,?,?,?,?,?,'EN_ATTENTE_PAIEMENT')
      ");
      $stmt->execute([
        $code_cmd, $client_id, $total_hl, $total_prod,
        $total_csg, $total_prod + $total_csg, $credit, $a_payer
      ]);
      $commande_id = $db->lastInsertId();

      foreach ($panier as $ligne) {
        if (!isset($ligne['prod'])) continue;
        $p = $ligne['prod'];
        $c = (int)($ligne['casiers'] ?? 0);
        $b = (int)($ligne['bouteilles'] ?? 0);
        $k = calcul_ligne($p, $c, $b);
        $vol = $k['vol']; $prix = $k['prix']; $csg = $k['csg'];

        $stmt = $db->prepare("
          INSERT INTO lignes_commande
            (commande_id, produit_id, quantite_casiers, quantite_bouteilles,
             prix_pag_kit, prix_consigne, volume_hl, sous_total)
          VALUES (?,?,?,?,?,?,?,?)
        ");
        $stmt->execute([$commande_id, $p['id'], $c, $b, $p['pag_kit_nu'], $csg, $vol, $prix+$csg]);
      }

      if ($credit > 0) {
        $stmt = $db->prepare("UPDATE solde_consigne SET solde_ariary=GREATEST(0,solde_ariary-?) WHERE client_id=?");
        $stmt->execute([$credit, $client_id]);
      }

      notifier_caisse($db, (int)$commande_id, $code_cmd, $a_payer);

      $db->commit();
      $commande_creee = ['id' => (int)$commande_id, 'code' => $code_cmd, 'total_hl' => $total_hl, 'a_payer' => $a_payer];
    } catch (Exception $e) {
      $db->rollBack();
      $error = "Erreur : " . $e->getMessage();
    }
  }
}
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Passer une commande</div>
      <div class="page-subtitle"><?= htmlspecialchars($mon_client['nom']) ?> · Paiement à l'agence</div>
    </div>
    <a href="dashboard.php" class="btn btn-secondary">← Retour</a>
  </div>
</div>

<?php if ($commande_creee): ?>
<!-- Succès -->
<div style="text-align:center;padding:2rem">
  <div style="font-size:3rem;margin-bottom:.8rem">✅</div>
  <div style="font-family:'Space Grotesk',sans-serif;font-size:1.4rem;font-weight:700;margin-bottom:.4rem">
    Commande enregistrée !
  </div>
  <div style="font-size:.85rem;color:var(--text-mute);margin-bottom:1.4rem">
    N° <strong style="color:var(--red)"><?= $commande_creee['code'] ?></strong>
    · <?= number_format($commande_creee['total_hl'],4) ?> hl
  </div>
  <div class="alert alert-info" style="max-width:420px;margin:0 auto 1.4rem;display:block;text-align:center">
    <span>🏦 Veuillez régler <strong><?= number_format($commande_creee['a_payer'], 0, ',', ' ') ?> Ar</strong>
    à la caisse de l'agence (Mobile Money, virement/bordereau ou espèces).</span>
  </div>
  <div style="margin-bottom:1.2rem;text-align:left"><?= render_recu($db, $commande_creee['id'], $mon_client['nom']) ?></div>
  <div style="display:flex;gap:.7rem;justify-content:center">
    <a href="dashboard.php" class="btn btn-secondary">← Retour accueil</a>
    <a href="commande.php" class="btn btn-primary">+ Nouvelle commande</a>
  </div>
</div>
<?php elseif ($error): ?>
<div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
<?php else: ?>

<?php if ($solde_consigne > 0): ?>
<div class="alert alert-info">
  🍾 Vous disposez d'un crédit consigne de <strong><?= number_format($solde_consigne) ?> Ar</strong>
  qui sera automatiquement déduit de votre prochaine commande.
</div>
<?php endif; ?>

<!-- Interface commande (même principe que commercial) -->
<div style="display:grid;grid-template-columns:1fr 300px;gap:1rem;align-items:start">

  <!-- Produits -->
  <div>
    <div class="card" style="padding:.8rem 1rem;margin-bottom:1rem">
      <input type="text" id="searchProd"
        placeholder="🔍 Rechercher un produit..."
        oninput="filterProds(this.value)"
        style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
               padding:.6rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif;outline:none"
        onfocus="this.style.borderColor='var(--red)'"
        onblur="this.style.borderColor='var(--border)'">
    </div>

    <?php foreach ($familles as $famille => $prods): ?>
    <div class="famille-section" style="margin-bottom:1rem">
      <div style="font-size:.65rem;font-weight:700;color:var(--text-mute);text-transform:uppercase;
                  letter-spacing:.1em;margin-bottom:.5rem;padding:.3rem .6rem;
                  background:var(--bg3);border-radius:6px;display:inline-block">
        <?= htmlspecialchars($famille) ?>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:.6rem">
        <?php foreach ($prods as $prod): ?>
        <div class="prod-card"
             data-id="<?= $prod['id'] ?>"
             data-nom="<?= strtolower($prod['description']) ?>"
             data-pag-kit="<?= $prod['pag_kit_nu'] ?>"
             data-pag-nu="<?= $prod['pag_nu'] ?>"
             data-kit="<?= $prod['kit'] ?>"
             data-vol="<?= $prod['volume_hl'] ?>"
             data-consigne-b="<?= $prod['consigne_bouteille'] ?>"
             data-consigne-c="<?= consigne_casier_plein($prod) ?>"
             onclick="toggleProd(this)"
             style="background:var(--bg-solid);border:1px solid var(--border);border-radius:10px;
                    padding:.8rem;cursor:pointer;transition:all .15s">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.5rem">
            <div>
              <div style="font-size:.8rem;font-weight:600"><?= htmlspecialchars($prod['description']) ?></div>
              <div style="font-size:.65rem;color:var(--text-mute)"><?= $prod['code'] ?> · Kit <?= $prod['kit'] ?></div>
            </div>
            <div class="prod-check" style="width:20px;height:20px;border-radius:50%;
              border:2px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:.7rem"></div>
          </div>
          <div style="font-size:.75rem;color:var(--red);font-weight:600">
            <?= number_format($prod['pag_kit_nu'] + consigne_casier_plein($prod)) ?> Ar/casier (logé)
          </div>
          <?php if (consigne_casier_plein($prod) > 0): ?>
          <div style="font-size:.63rem;color:var(--text-mute)">
            dont <?= number_format(consigne_casier_plein($prod)) ?> Ar consigne/casier (<?= $prod['kit'] ?> btl × <?= number_format($prod['consigne_bouteille']) ?> + casier <?= number_format($prod['consigne_casier']) ?>)
          </div>
          <?php endif; ?>

          <div class="prod-qty" style="display:none;margin-top:.8rem;border-top:1px solid var(--border);padding-top:.7rem">
            <div style="display:flex;align-items:center;gap:.4rem">
              <span style="font-size:.65rem;color:var(--text-mute);flex:1">Casiers :</span>
              <button onclick="event.stopPropagation();changeQty(<?= $prod['id'] ?>,'c',-1)"
                style="width:26px;height:26px;border-radius:5px;border:1px solid var(--border);
                       background:var(--bg3);color:var(--text);cursor:pointer">−</button>
              <input type="number" id="qty_c_<?= $prod['id'] ?>" value="0" min="0"
                onclick="event.stopPropagation()" onchange="updatePanier(<?= $prod['id'] ?>)"
                style="width:44px;text-align:center;background:var(--bg3);border:1px solid var(--border);
                       border-radius:5px;padding:.25rem;color:var(--text);font-size:.82rem;font-family:Inter,sans-serif">
              <button onclick="event.stopPropagation();changeQty(<?= $prod['id'] ?>,'c',1)"
                style="width:26px;height:26px;border-radius:5px;border:1px solid var(--red);
                       background:var(--red-dim);color:var(--red);cursor:pointer">+</button>
            </div>
            <div id="st_<?= $prod['id'] ?>" style="font-size:.7rem;color:var(--red);font-weight:600;text-align:right;margin-top:.4rem"></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Panier -->
  <div style="position:sticky;top:calc(var(--topbar-h) + 1rem)">
    <div class="card" style="padding:0;overflow:hidden">
      <div style="padding:.9rem 1.1rem;border-bottom:1px solid var(--border);background:var(--bg3);
                  display:flex;justify-content:space-between;align-items:center">
        <div style="font-size:.85rem;font-weight:600">🛒 Panier</div>
        <span id="panier-count" class="badge badge-red">0</span>
      </div>
      <div id="panier-items" style="max-height:280px;overflow-y:auto;padding:.8rem">
        <div id="panier-empty" style="text-align:center;color:var(--text-mute);font-size:.78rem;padding:1.2rem">
          Aucun produit
        </div>
      </div>
      <div style="padding:.9rem 1.1rem;border-top:1px solid var(--border)">
        <div style="display:flex;justify-content:space-between;font-size:.75rem;margin-bottom:.3rem">
          <span style="color:var(--text-mute)">Volume</span>
          <span id="total-hl" style="font-weight:600">0 hl</span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:.75rem;margin-bottom:.3rem">
          <span style="color:var(--text-mute)">Produits + consigne</span>
          <span id="total-brut">0 Ar</span>
        </div>
        <?php if ($solde_consigne > 0): ?>
        <div style="display:flex;justify-content:space-between;font-size:.75rem;margin-bottom:.3rem;color:#00c864">
          <span>Crédit consigne</span>
          <span id="credit-affiche">—</span>
        </div>
        <?php endif; ?>
        <div style="height:1px;background:var(--border);margin:.4rem 0"></div>
        <div style="display:flex;justify-content:space-between;font-size:.9rem">
          <span style="font-weight:700">À PAYER</span>
          <span id="total-final" style="color:var(--red);font-weight:700">0 Ar</span>
        </div>
      </div>
      <div style="padding:.8rem 1.1rem;border-top:1px solid var(--border)">
        <form method="POST" id="formCmd">
          <input type="hidden" name="etape" value="confirmer">
          <input type="hidden" name="panier_json" id="panier_json" value="[]">
          <button type="button" id="btnCommander" onclick="commander()"
            class="btn btn-primary" style="width:100%;justify-content:center;opacity:.4;pointer-events:none">
            ✅ Confirmer la commande
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
const panier = {};
const SOLDE = <?= $solde_consigne ?>;

function toggleProd(card) {
  const id = card.dataset.id;
  const qty = card.querySelector('.prod-qty');
  const chk = card.querySelector('.prod-check');
  if (qty.style.display === 'none') {
    qty.style.display = '';
    card.style.borderColor = 'var(--red)';
    card.style.background = 'var(--bg-solid-sel)';
    chk.style.background = 'var(--red)'; chk.style.borderColor = 'var(--red)';
    chk.textContent = '✓'; chk.style.color = '#fff';
    panier[id] = {
      nom: card.querySelector('[style*="font-weight:600"]').textContent.trim(),
      casiers: 0, bouteilles: 0,
      vol: parseFloat(card.dataset.vol),
      pag_kit: parseFloat(card.dataset.pagKit),
      pag_nu: parseFloat(card.dataset.pagNu),
      consigne_b: parseFloat(card.dataset.consigneB),
      consigne_c: parseFloat(card.dataset.consigneC),
      kit: parseInt(card.dataset.kit),
    };
  } else {
    qty.style.display = 'none';
    card.style.borderColor = 'var(--border)'; card.style.background = 'var(--bg-solid)';
    chk.style.background = ''; chk.style.borderColor = 'var(--border)'; chk.textContent = '';
    document.getElementById('qty_c_' + id).value = 0;
    delete panier[id];
    updateTotaux(); renderPanier();
  }
}

function changeQty(id, type, delta) {
  const inp = document.getElementById('qty_c_' + id);
  let v = parseInt(inp.value) + delta;
  if (v < 0) v = 0;
  inp.value = v;
  updatePanier(id);
}

function updatePanier(id) {
  if (!panier[id]) return;
  panier[id].casiers = parseInt(document.getElementById('qty_c_' + id).value) || 0;
  const p = panier[id];
  const st = p.casiers * p.pag_kit + p.casiers * p.consigne_c;
  const stEl = document.getElementById('st_' + id);
  if (stEl) stEl.textContent = st > 0 ? fmt(st) + ' Ar' : '';
  updateTotaux(); renderPanier();
}

function updateTotaux() {
  let hl = 0, brut = 0, csg = 0;
  Object.values(panier).forEach(p => {
    hl   += p.casiers * p.vol;
    brut += p.casiers * p.pag_kit;
    csg  += p.casiers * p.consigne_c;
  });
  const credit = Math.min(SOLDE, csg);
  const final  = brut + csg - credit;
  document.getElementById('total-hl').textContent   = hl.toFixed(4) + ' hl';
  document.getElementById('total-brut').textContent = fmt(brut + csg) + ' Ar';
  const ca = document.getElementById('credit-affiche');
  if (ca) ca.textContent = credit > 0 ? '−' + fmt(credit) + ' Ar' : '—';
  document.getElementById('total-final').textContent = fmt(final) + ' Ar';
  document.getElementById('panier_json').value = JSON.stringify(
    Object.entries(panier).map(([id, p]) => ({ produit_id: id, casiers: p.casiers, bouteilles: 0 }))
  );
  const has = Object.values(panier).some(p => p.casiers > 0);
  const btn = document.getElementById('btnCommander');
  btn.style.opacity = has ? '1' : '.4';
  btn.style.pointerEvents = has ? 'auto' : 'none';
}

function renderPanier() {
  const container = document.getElementById('panier-items');
  const empty     = document.getElementById('panier-empty');
  const count     = document.getElementById('panier-count');
  const items     = Object.entries(panier).filter(([,p]) => p.casiers > 0);
  count.textContent = items.length;
  empty.style.display = items.length ? 'none' : '';
  container.querySelectorAll('.pi').forEach(e => e.remove());
  items.forEach(([id, p]) => {
    const d = document.createElement('div');
    d.className = 'pi';
    d.style.cssText = 'padding:.4rem 0;border-bottom:1px solid var(--bg3);font-size:.73rem';
    d.innerHTML = `<div style="font-weight:600">${p.nom}</div>
      <div style="display:flex;justify-content:space-between;color:var(--text-mute)">
        <span>${p.casiers} casier(s)</span>
        <span style="color:var(--red)">${fmt(p.casiers*(p.pag_kit+p.consigne_c))} Ar</span>
      </div>`;
    container.appendChild(d);
  });
}

function commander() {
  const has = Object.values(panier).some(p => p.casiers > 0);
  if (has) document.getElementById('formCmd').submit();
}

function filterProds(q) {
  q = q.toLowerCase();
  document.querySelectorAll('.prod-card').forEach(c => {
    c.style.display = !q || c.dataset.nom.includes(q) ? '' : 'none';
  });
}

function fmt(n) { return Math.round(n).toLocaleString('fr-FR'); }
</script>
<?php endif; ?>

<?php close_layout(); ?>

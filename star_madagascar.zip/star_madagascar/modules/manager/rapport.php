<?php
// ============================================================
// modules/manager/rapport.php
// Rapport journalier par email
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Rapport journalier', ['MANAGER','MANAGER_INTERIM']);
$user = $ctx['user'];
$db   = getDB();

$secteur_id = $user['secteur'];
$today     = date('Y-m-d');

// Performances du jour
$stmt = $db->prepare("
  SELECT
    u.id, CONCAT(u.prenom,' ',u.nom) AS nom,
    COUNT(c.id) AS nb_commandes,
    COALESCE(SUM(c.total_hl),0) AS total_hl,
    COALESCE(SUM(c.montant_total),0) AS montant,
    COUNT(DISTINCT c.client_id) AS nb_clients,
    -- Le commercial n'a pas d'objectif HL : on suit ses visites du jour (faites / prévues)
    (SELECT COUNT(*) FROM visites v WHERE v.commercial_id=u.id AND DATE(v.date_visite)=CURDATE() AND v.statut IN ('PLANIFIE','VISITE')) AS obj_j,
    (SELECT COUNT(*) FROM visites v WHERE v.commercial_id=u.id AND DATE(v.date_visite)=CURDATE() AND v.statut='VISITE') AS visites_j
  FROM utilisateurs u
  LEFT JOIN commandes c ON c.commercial_id=u.id AND DATE(c.date_commande)=? AND c.statut NOT IN ('CREEE')
  WHERE u.secteur_id=? AND u.role IN ('COMMERCIAL','MANAGER_INTERIM') AND u.actif=1
  GROUP BY u.id
  ORDER BY total_hl DESC
");
$stmt->execute([$today, $secteur_id]);
$perfs = $stmt->fetchAll();

$total_hl     = array_sum(array_column($perfs, 'total_hl'));
$total_montant= array_sum(array_column($perfs, 'montant'));
$total_cmd    = array_sum(array_column($perfs, 'nb_commandes'));
$total_clients= array_sum(array_column($perfs, 'nb_clients'));

// Infos équipe
$stmt = $db->prepare("SELECT nom FROM secteurs WHERE id=?");
$stmt->execute([$secteur_id]);
$equipe = $stmt->fetch();

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email_dest = trim($_POST['email_dest'] ?? '');
  $notes      = trim($_POST['notes'] ?? '');

  if (!filter_var($email_dest, FILTER_VALIDATE_EMAIL)) {
    $error = 'Adresse email invalide.';
  } else {
    // Construire contenu rapport
    $contenu_html = generer_rapport_html($perfs, $total_hl, $total_montant, $total_cmd, $total_clients, $equipe['nom'] ?? '', $user['nom'], $notes, $today);

    // En-têtes email HTML
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "From: star-madagascar-noreply@star.mg\r\n";

    $sujet = "Rapport journalier — " . ($equipe['nom'] ?? 'Équipe') . " — " . date('d/m/Y');

    if (@mail($email_dest, $sujet, $contenu_html, $headers)) {
      $success = "Rapport envoyé avec succès à $email_dest";
    } else {
      $error = "Erreur d'envoi email.";
    }
  }
}

function generer_rapport_html(array $perfs, float $hl, float $montant, int $cmd, int $clients, string $equipe, string $manager, string $notes, string $date): string {
  $rows = '';
  foreach ($perfs as $p) {
    $pct = ($p['obj_j'] ?? 0) > 0 ? round($p['visites_j'] / $p['obj_j'] * 100) : 0;
    $color = $pct >= 100 ? '#00c864' : ($pct >= 60 ? '#ffa000' : '#E8001C');
    $rows .= "<tr>
      <td style='padding:.5rem .8rem;border-bottom:1px solid #eee'>" . htmlspecialchars($p['nom']) . "</td>
      <td style='padding:.5rem .8rem;border-bottom:1px solid #eee;text-align:right;font-weight:700;color:#E8001C'>" . number_format($p['total_hl'],2) . " hl</td>
      <td style='padding:.5rem .8rem;border-bottom:1px solid #eee;text-align:right'>" . ($p['obj_j'] ? $p['visites_j'].' / '.$p['obj_j'] : '—') . "</td>
      <td style='padding:.5rem .8rem;border-bottom:1px solid #eee;text-align:center;font-weight:700;color:$color'>{$pct}%</td>
      <td style='padding:.5rem .8rem;border-bottom:1px solid #eee;text-align:center'>{$p['nb_clients']}</td>
      <td style='padding:.5rem .8rem;border-bottom:1px solid #eee;text-align:right'>" . number_format($p['montant']) . " Ar</td>
    </tr>";
  }

  return "<!DOCTYPE html><html><head><meta charset='UTF-8'></head><body style='font-family:Arial,sans-serif;background:#f5f5f5;margin:0;padding:20px'>
  <div style='max-width:700px;margin:0 auto;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.1)'>
    <div style='background:#E8001C;padding:1.5rem;color:#fff'>
      <div style='font-size:1.2rem;font-weight:700'>STAR MADAGASCAR</div>
      <div style='font-size:.9rem;opacity:.85;margin-top:.3rem'>Rapport journalier — $equipe</div>
      <div style='font-size:.85rem;opacity:.7;margin-top:.2rem'>" . date('d/m/Y', strtotime($date)) . " · Manager : $manager</div>
    </div>
    <div style='padding:1.5rem'>
      <div style='display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:1.5rem'>
        <div style='text-align:center;padding:1rem;background:#f8f8f8;border-radius:6px'>
          <div style='font-size:1.6rem;font-weight:700;color:#E8001C'>" . number_format($hl,1) . "</div>
          <div style='font-size:.75rem;color:#666'>Hl total</div>
        </div>
        <div style='text-align:center;padding:1rem;background:#f8f8f8;border-radius:6px'>
          <div style='font-size:1.6rem;font-weight:700;color:#333'>$cmd</div>
          <div style='font-size:.75rem;color:#666'>Commandes</div>
        </div>
        <div style='text-align:center;padding:1rem;background:#f8f8f8;border-radius:6px'>
          <div style='font-size:1.6rem;font-weight:700;color:#333'>$clients</div>
          <div style='font-size:.75rem;color:#666'>Clients visités</div>
        </div>
        <div style='text-align:center;padding:1rem;background:#f8f8f8;border-radius:6px'>
          <div style='font-size:1.1rem;font-weight:700;color:#333'>" . number_format($montant) . "</div>
          <div style='font-size:.75rem;color:#666'>Ariary</div>
        </div>
      </div>
      <table style='width:100%;border-collapse:collapse;margin-bottom:1.5rem'>
        <thead>
          <tr style='background:#f0f0f0'>
            <th style='padding:.5rem .8rem;text-align:left;font-size:.75rem'>Commercial</th>
            <th style='padding:.5rem .8rem;text-align:right;font-size:.75rem'>Volume</th>
            <th style='padding:.5rem .8rem;text-align:right;font-size:.75rem'>Visites faites / prévues</th>
            <th style='padding:.5rem .8rem;text-align:center;font-size:.75rem'>%</th>
            <th style='padding:.5rem .8rem;text-align:center;font-size:.75rem'>Clients</th>
            <th style='padding:.5rem .8rem;text-align:right;font-size:.75rem'>Montant</th>
          </tr>
        </thead>
        <tbody>$rows</tbody>
      </table>
      " . ($notes ? "<div style='padding:1rem;background:#fff8ec;border-left:3px solid #ffa000;border-radius:4px;font-size:.85rem'><strong>Notes du manager :</strong><br>" . nl2br(htmlspecialchars($notes)) . "</div>" : "") . "
    </div>
    <div style='padding:1rem 1.5rem;background:#f5f5f5;font-size:.72rem;color:#999;text-align:center'>
      Rapport généré automatiquement par le système Star Madagascar · " . date('d/m/Y H:i') . "
    </div>
  </div>
  </body></html>";
}
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Rapport journalier</div>
      <div class="page-subtitle">Envoi par email — <?= date('d/m/Y') ?> · <?= htmlspecialchars($equipe['nom'] ?? '') ?></div>
    </div>
  </div>
</div>

<?php if ($success): ?><div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 320px;gap:1rem;align-items:start">

  <!-- Aperçu rapport -->
  <div>
    <div class="card" style="padding:0;overflow:hidden">
      <div style="background:var(--red);padding:1rem 1.2rem;color:#fff">
        <img src="../../assets/images/logos/star_logo_white.png" alt="STAR Madagascar" style="height:34px;width:auto">
        <div style="font-size:.8rem;opacity:.85">Rapport journalier — <?= htmlspecialchars($equipe['nom'] ?? '') ?></div>
        <div style="font-size:.75rem;opacity:.7"><?= date('d/m/Y') ?> · Manager : <?= htmlspecialchars($user['nom']) ?></div>
      </div>
      <!-- KPI -->
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:0;border-bottom:1px solid var(--border)">
        <?php foreach ([
          [$total_hl > 0 ? number_format($total_hl,1) : '0', 'Hl total', 'var(--red)'],
          [$total_cmd, 'Commandes', 'var(--text)'],
          [$total_clients, 'Clients visités', 'var(--text)'],
          [number_format($total_montant).' Ar', 'Montant', 'var(--text)'],
        ] as [$val, $label, $color]): ?>
        <div style="text-align:center;padding:1rem;border-right:1px solid var(--border)">
          <div style="font-family:'Space Grotesk',sans-serif;font-size:1.3rem;font-weight:700;color:<?= $color ?>"><?= $val ?></div>
          <div style="font-size:.65rem;color:var(--text-mute)"><?= $label ?></div>
        </div>
        <?php endforeach; ?>
      </div>
      <!-- Table commerciaux -->
      <table class="data-table">
        <thead>
          <tr>
            <th>Commercial</th>
            <th style="text-align:right">Hl</th>
            <th style="text-align:right">Visites faites / prévues</th>
            <th style="text-align:center">%</th>
            <th style="text-align:center">Clients</th>
            <th style="text-align:right">Montant</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($perfs as $p):
            $pct = ($p['obj_j'] ?? 0) > 0 ? round($p['visites_j'] / $p['obj_j'] * 100) : 0;
            $c = $pct >= 100 ? '#00c864' : ($pct >= 60 ? '#ffa000' : 'var(--red)');
          ?>
          <tr>
            <td style="font-weight:500"><?= htmlspecialchars($p['nom']) ?></td>
            <td style="text-align:right;font-weight:700;color:var(--red)"><?= number_format($p['total_hl'],2) ?></td>
            <td style="text-align:right;color:var(--text-mute)"><?= $p['obj_j'] ? $p['visites_j'].' / '.$p['obj_j'] : '—' ?></td>
            <td style="text-align:center;font-weight:700;color:<?= $c ?>"><?= $pct ?>%</td>
            <td style="text-align:center"><?= $p['nb_clients'] ?></td>
            <td style="text-align:right;font-size:.75rem"><?= number_format($p['montant']) ?> Ar</td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Formulaire envoi -->
  <div class="card card-top-line">
    <div style="font-size:.85rem;font-weight:600;margin-bottom:1.2rem">Envoyer le rapport</div>
    <form method="POST" style="display:flex;flex-direction:column;gap:.9rem">
      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Email du destinataire *</label>
        <input type="email" name="email_dest" required
          placeholder="superieur@star-madagascar.mg"
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.7rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif"
          onfocus="this.style.borderColor='var(--red)'"
          onblur="this.style.borderColor='var(--border)'">
      </div>
      <div>
        <label style="font-size:.72rem;color:var(--text-mute);display:block;margin-bottom:.4rem">Notes additionnelles</label>
        <textarea name="notes" rows="4"
          placeholder="Observations, points d'attention, actions prévues..."
          style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
                 padding:.7rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif;resize:vertical"
          onfocus="this.style.borderColor='var(--red)'"
          onblur="this.style.borderColor='var(--border)'"></textarea>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">
        📧 Envoyer le rapport
      </button>
    </form>
  </div>

</div>

<?php close_layout(); ?>

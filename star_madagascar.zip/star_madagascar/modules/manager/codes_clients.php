<?php
// ============================================================
// modules/manager/codes_clients.php
// Validation demandes de code client
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Codes clients', ['MANAGER','MANAGER_INTERIM','ADMIN']);
$user = $ctx['user'];
$db   = getDB();

// Traitement action
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action    = $_POST['action'] ?? '';
  $demande_id= (int)($_POST['demande_id'] ?? 0);

  if ($action === 'valider' && $demande_id) {
    $stmt = $db->prepare("
      UPDATE clients SET statut='VALIDE_MANAGER', manager_id=?
      WHERE id=? AND statut='EN_ATTENTE'
    ");
    $stmt->execute([$user['id'], $demande_id]);

    // Notifier admin
    $admin = $db->query("SELECT id FROM utilisateurs WHERE role='ADMIN' AND actif=1 LIMIT 1")->fetch();
    if ($admin) {
      $stmt = $db->prepare("
        INSERT INTO notifications (utilisateur_id, titre, message, type, reference_id)
        VALUES (?,?,?,'CODE_CLIENT',?)
      ");
      $stmt->execute([
        $admin['id'],
        'Demande de code client à approuver',
        "Validée par manager — en attente d'attribution du code",
        $demande_id
      ]);
    }
  } elseif ($action === 'rejeter' && $demande_id) {
    $motif = trim($_POST['motif'] ?? 'Demande rejetée par le manager.');
    $stmt = $db->prepare("
      UPDATE clients SET statut='REJETE', motif_rejet=?, manager_id=?
      WHERE id=? AND statut='EN_ATTENTE'
    ");
    $stmt->execute([$motif, $user['id'], $demande_id]);
  }
  header('Location: codes_clients.php');
  exit;
}

// Récupérer demandes (= clients dont le statut fait encore partie du workflow de validation)
$stmt = $db->prepare("
  SELECT d.*, u.prenom, u.nom AS commercial_nom, s.nom AS secteur_nom
  FROM clients d
  JOIN utilisateurs u ON d.demandeur_id = u.id
  LEFT JOIN secteurs s ON d.secteur_id = s.id
  WHERE d.demandeur_id IS NOT NULL
    AND (d.manager_id = ? OR (d.manager_id IS NULL AND ? IS NOT NULL))
  ORDER BY d.created_at DESC
");
$stmt->execute([$user['id'], $user['id']]);
$demandes = $stmt->fetchAll();

$en_attente = array_filter($demandes, fn($d) => $d['statut'] === 'EN_ATTENTE');
$traitees   = array_filter($demandes, fn($d) => $d['statut'] !== 'EN_ATTENTE');
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Demandes de code client</div>
      <div class="page-subtitle"><?= count($en_attente) ?> demande(s) en attente de validation</div>
    </div>
  </div>
</div>

<?php if (!empty($en_attente)): ?>
<div style="margin-bottom:1.4rem">
  <div style="font-size:.72rem;color:var(--text-mute);font-weight:600;
              text-transform:uppercase;letter-spacing:.06em;margin-bottom:.7rem">
    ⏳ En attente (<?= count($en_attente) ?>)
  </div>
  <?php foreach ($en_attente as $d): ?>
  <div class="card" style="margin-bottom:.7rem">
    <div style="display:grid;grid-template-columns:1fr auto;gap:1rem;align-items:start">
      <div>
        <div style="font-size:.95rem;font-weight:700;margin-bottom:.3rem"><?= htmlspecialchars($d['nom']) ?></div>
        <div style="display:flex;gap:1rem;flex-wrap:wrap;font-size:.75rem;color:var(--text-mute);margin-bottom:.6rem">
          <span>Type : <strong style="color:var(--text)"><?= htmlspecialchars($d['type']) ?></strong></span>
          <span>Quartier : <strong style="color:var(--text)"><?= htmlspecialchars($d['quartier'] ?? '—') ?></strong></span>
          <span>Secteur : <strong style="color:var(--text)"><?= htmlspecialchars($d['secteur_nom'] ?? '—') ?></strong></span>
          <span>Tél : <strong style="color:var(--text)"><?= htmlspecialchars($d['telephone'] ?? '—') ?></strong></span>
        </div>
        <div style="font-size:.75rem;color:var(--text-mute)">
          Adresse : <?= htmlspecialchars($d['adresse']) ?>
        </div>
        <div style="font-size:.72rem;color:var(--text-mute);margin-top:.3rem">
          Demandé par <strong><?= htmlspecialchars($d['prenom'].' '.$d['commercial_nom']) ?></strong>
          le <?= date('d/m/Y à H:i', strtotime($d['created_at'])) ?>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:.5rem;min-width:160px">
        <form method="POST" style="margin:0">
          <input type="hidden" name="action" value="valider">
          <input type="hidden" name="demande_id" value="<?= $d['id'] ?>">
          <button type="submit" class="btn btn-primary btn-sm" style="width:100%;justify-content:center">
            ✓ Valider → Admin
          </button>
        </form>
        <button onclick="rejeter(<?= $d['id'] ?>)" class="btn btn-secondary btn-sm"
          style="width:100%;justify-content:center;color:var(--red)">
          ✗ Rejeter
        </button>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Historique -->
<?php if (!empty($traitees)): ?>
<div>
  <div style="font-size:.72rem;color:var(--text-mute);font-weight:600;
              text-transform:uppercase;letter-spacing:.06em;margin-bottom:.7rem">
    Historique des demandes traitées
  </div>
  <div class="card" style="padding:0;overflow:hidden">
    <table class="data-table">
      <thead>
        <tr><th>Client</th><th>Type</th><th>Commercial</th><th>Statut</th><th>Code attribué</th><th>Date</th></tr>
      </thead>
      <tbody>
        <?php foreach ($traitees as $d): ?>
        <tr>
          <td style="font-weight:500"><?= htmlspecialchars($d['nom']) ?></td>
          <td><?= htmlspecialchars($d['type']) ?></td>
          <td><?= htmlspecialchars($d['prenom'].' '.$d['commercial_nom']) ?></td>
          <td><?= statut_badge($d['statut']) ?></td>
          <td style="font-family:monospace;color:var(--red);font-weight:600">
            <?= $d['code_client'] ? htmlspecialchars($d['code_client']) : '—' ?>
          </td>
          <td style="font-size:.72rem"><?= date('d/m/Y', strtotime($d['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- Modal rejet -->
<div id="modalRejet" style="display:none;position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.7);backdrop-filter:blur(4px);align-items:center;justify-content:center">
  <div class="modal-box" style="border:1px solid var(--border);border-radius:16px;
              padding:1.6rem;max-width:380px;width:90%">
    <div style="font-weight:700;margin-bottom:1rem">Motif du rejet</div>
    <form method="POST" id="formRejet">
      <input type="hidden" name="action" value="rejeter">
      <input type="hidden" name="demande_id" id="rejetId">
      <textarea name="motif" rows="3" placeholder="Ex: zone non couverte, client déjà existant..."
        style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
               padding:.7rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif;
               resize:vertical;margin-bottom:1rem"></textarea>
      <div style="display:flex;gap:.6rem">
        <button type="button" onclick="document.getElementById('modalRejet').style.display='none'"
          class="btn btn-secondary" style="flex:1;justify-content:center">Annuler</button>
        <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center;background:rgba(51,51,51,.15);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px)">
          Confirmer le rejet
        </button>
      </div>
    </form>
  </div>
</div>

<script>
function rejeter(id) {
  document.getElementById('rejetId').value = id;
  document.getElementById('modalRejet').style.display = 'flex';
}
</script>

<?php
function statut_badge(string $s): string {
  return match($s) {
    'VALIDE_MANAGER' => "<span class='badge badge-blue'>Validé manager</span>",
    'ACTIF'          => "<span class='badge badge-green'>Approuvé</span>",
    'REJETE'         => "<span class='badge badge-red'>Rejeté</span>",
    default          => "<span class='badge badge-mute'>$s</span>",
  };
}
close_layout();
?>

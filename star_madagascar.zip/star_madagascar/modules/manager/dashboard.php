<?php
// ============================================================
// modules/manager/dashboard.php
// Tableau de bord Manager
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';
require_once '../../includes/objectifs.php';

$ctx  = include_layout('Tableau de bord', ['MANAGER','MANAGER_INTERIM','ADMIN','DIRECTEUR']);
$user = $ctx['user'];
$db   = getDB();

$today     = date('Y-m-d');
$secteur_id = $user['secteur'];

// Objectif de l'agence (jour / semaine / mois) — réalisé = clients achetant à l'agence
$synth_agence = synthese_objectif_agence($db);

// Performances équipe aujourd'hui
$stmt = $db->prepare("
  SELECT
    u.id, CONCAT(u.prenom,' ',u.nom) AS nom,
    COUNT(c.id)                        AS nb_commandes,
    COALESCE(SUM(c.total_hl),0)        AS total_hl,
    COALESCE(SUM(c.montant_total),0)   AS montant,
    COUNT(DISTINCT c.client_id)        AS nb_clients,
    (SELECT COUNT(*) FROM visites vv WHERE vv.commercial_id=u.id AND vv.statut='VISITE' AND MONTH(vv.date_visite)=MONTH(CURDATE()) AND YEAR(vv.date_visite)=YEAR(CURDATE())) AS nb_visites,
    (SELECT COALESCE(obj2.objectif_clients,0) FROM objectifs obj2
     WHERE obj2.commercial_id=u.id AND obj2.annee=YEAR(CURDATE()) AND obj2.mois=MONTH(CURDATE())
       AND obj2.semaine IS NULL AND obj2.jour IS NULL ORDER BY obj2.id DESC LIMIT 1) AS obj_clients
  FROM utilisateurs u
  LEFT JOIN commandes c
    ON c.commercial_id = u.id
    AND DATE(c.date_commande) = ?
    AND c.statut NOT IN ('CREEE')
  WHERE u.secteur_id = ?
    AND u.role IN ('COMMERCIAL','MANAGER_INTERIM')
    AND u.actif = 1
  GROUP BY u.id, u.prenom, u.nom
  ORDER BY total_hl DESC
");
$stmt->execute([$today, $secteur_id]);
$perfs = $stmt->fetchAll();

// Totaux équipe aujourd'hui
$total_hl_equipe     = array_sum(array_column($perfs, 'total_hl'));
$total_montant_equipe= array_sum(array_column($perfs, 'montant'));
$total_cmd_equipe    = array_sum(array_column($perfs, 'nb_commandes'));
$total_clients_equipe= array_sum(array_column($perfs, 'nb_clients'));

// Hl mensuel cumulé équipe
$stmt = $db->prepare("
  SELECT COALESCE(SUM(c.total_hl),0)
  FROM commandes c
  JOIN utilisateurs u ON c.commercial_id = u.id
  WHERE u.secteur_id = ?
    AND MONTH(c.date_commande) = MONTH(CURDATE())
    AND YEAR(c.date_commande) = YEAR(CURDATE())
    AND c.statut NOT IN ('CREEE')
");
$stmt->execute([$secteur_id]);
$hl_mensuel = $stmt->fetchColumn();


// Demandes code client en attente
$stmt = $db->prepare("
  SELECT COUNT(*) FROM clients
  WHERE manager_id = ? AND statut = 'EN_ATTENTE'
");
$stmt->execute([$user['id']]);
$nb_codes_attente = $stmt->fetchColumn();

// Défauts en attente
$stmt = $db->prepare("
  SELECT COUNT(*) FROM defauts_produits
  WHERE manager_id = ? AND statut = 'SIGNALE'
");
$stmt->execute([$user['id']]);
$nb_defauts = $stmt->fetchColumn();

// Commandes des 7 derniers jours (pour graphique)
$stmt = $db->prepare("
  SELECT DATE(c.date_commande) AS jour,
         COALESCE(SUM(c.total_hl),0) AS hl
  FROM commandes c
  JOIN utilisateurs u ON c.commercial_id = u.id
  WHERE u.secteur_id = ?
    AND c.date_commande >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
    AND c.statut NOT IN ('CREEE')
  GROUP BY DATE(c.date_commande)
  ORDER BY jour ASC
");
$stmt->execute([$secteur_id]);
$historique_7j = $stmt->fetchAll();

// Préparer données graphique
$labels_7j = [];
$data_7j   = [];
for ($i = 6; $i >= 0; $i--) {
  $d = date('Y-m-d', strtotime("-$i days"));
  $labels_7j[] = date('d/m', strtotime($d));
  $found = array_filter($historique_7j, fn($h) => $h['jour'] === $d);
  $data_7j[] = $found ? round(array_values($found)[0]['hl'], 2) : 0;
}
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Tableau de bord équipe</div>
      <div class="page-subtitle">
        <?= date_fr() ?> ·
        <?php if ($nb_codes_attente > 0): ?>
          <span style="color:#ffa000">⚠️ <?= $nb_codes_attente ?> demande(s) de code en attente</span>
        <?php endif; ?>
      </div>
    </div>
    <div style="display:flex;gap:.6rem">
      <?php if ($nb_codes_attente > 0): ?>
      <a href="codes_clients.php" class="btn btn-secondary" style="color:#ffa000;border-color:#ffa000">
        🆔 <?= $nb_codes_attente ?> code(s)
      </a>
      <?php endif; ?>
      <?php if ($nb_defauts > 0): ?>
      <a href="defauts.php" class="btn btn-secondary" style="color:var(--red);border-color:var(--red)">
        ⚠️ <?= $nb_defauts ?> défaut(s)
      </a>
      <?php endif; ?>
      <a href="rapport.php" class="btn btn-primary">📧 Rapport journalier</a>
    </div>
  </div>
</div>

<?= bloc_objectif_agence($synth_agence) ?>

<!-- KPI Cards -->
<div class="grid-4" style="margin-bottom:1.2rem">
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Volume équipe aujourd'hui</div>
    <div class="kpi-value"><?= number_format($total_hl_equipe,1) ?> <span class="unit">hl</span></div>
    <div class="kpi-trend neutral"><?= $total_cmd_equipe ?> commandes</div>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Volume équipe du mois</div>
    <div class="kpi-value"><?= number_format($hl_mensuel,1) ?> <span class="unit">hl</span></div>
    <div class="kpi-trend neutral">Activité des commerciaux (base de la prime)</div>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Montant total aujourd'hui</div>
    <div class="kpi-value" style="font-size:1.4rem"><?= number_format($total_montant_equipe) ?> <span class="unit">Ar</span></div>
    <div class="kpi-trend neutral"><?= $total_clients_equipe ?> clients visités</div>
  </div>
  <div class="card card-top-line kpi-card">
    <div class="kpi-label">Commerciaux actifs</div>
    <div class="kpi-value"><?= count($perfs) ?> <span class="unit">agents</span></div>
    <div class="kpi-trend neutral">
      <?= count(array_filter($perfs, fn($p) => $p['total_hl'] > 0)) ?> ont déjà vendu
    </div>
  </div>
</div>

<div class="grid-2">

  <!-- Performances individuelles -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:.85rem;font-weight:600">
      Performances commerciaux — Aujourd'hui
    </div>
    <table class="data-table">
      <thead>
        <tr>
          <th>Commercial</th>
          <th style="text-align:right">Hl</th>
          <th style="text-align:right">Objectif clients</th>
          <th style="text-align:center">%</th>
          <th style="text-align:center">Visites (mois)</th>
          <th style="text-align:right">Montant</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($perfs as $p):
          // % = visites réalisées du mois / objectif de clients à visiter
          $pct = ($p['obj_clients'] ?? 0) > 0 ? min(100, round($p['nb_visites'] / $p['obj_clients'] * 100)) : 0;
          $color = $pct >= 100 ? '#00c864' : ($pct >= 60 ? '#ffa000' : 'var(--red)');
        ?>
        <tr>
          <td style="font-weight:500;color:var(--text)"><?= htmlspecialchars($p['nom']) ?></td>
          <td style="text-align:right;font-weight:700;color:var(--red)"><?= number_format($p['total_hl'],2) ?></td>
          <td style="text-align:right;color:var(--text-mute)"><?= $p['obj_clients'] ? $p['obj_clients'] : '—' ?></td>
          <td style="text-align:center">
            <?php if ($p['obj_clients']): ?>
            <span style="font-weight:700;color:<?= $color ?>;font-size:.8rem"><?= $pct ?>%</span>
            <?php else: ?>
            <span style="color:var(--text-mute)">—</span>
            <?php endif; ?>
          </td>
          <td style="text-align:center"><?= $p['nb_visites'] ?></td>
          <td style="text-align:right;font-size:.75rem"><?= number_format($p['montant']) ?> Ar</td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Graphique 7 jours -->
  <div class="card">
    <div style="font-size:.85rem;font-weight:600;margin-bottom:1rem">
      Volume Hl — 7 derniers jours (équipe)
    </div>
    <div style="position:relative;height:180px">
      <?php
      $max_val = max(array_merge($data_7j, [1]));
      ?>
      <div style="display:flex;align-items:flex-end;gap:6px;height:160px;padding-bottom:24px">
        <?php foreach ($data_7j as $i => $val):
          $h = $max_val > 0 ? round($val / $max_val * 100) : 0;
          $is_today = $i === 6;
        ?>
        <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;height:100%;justify-content:flex-end">
          <?php if ($val > 0): ?>
          <div style="font-size:.6rem;color:var(--text-mute)"><?= number_format($val,1) ?></div>
          <?php endif; ?>
          <div style="width:100%;border-radius:4px 4px 0 0;
                      background:<?= $is_today ? 'var(--red)' : 'rgba(232,0,28,.3)' ?>;
                      height:<?= max(4,$h) ?>%;
                      transition:height .3s ease"></div>
          <div style="font-size:.6rem;color:<?= $is_today ? 'var(--red)' : 'var(--text-mute)' ?>;
                      font-weight:<?= $is_today ? '700' : '400' ?>">
            <?= $labels_7j[$i] ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div style="margin-top:.5rem;text-align:center;font-size:.7rem;color:var(--text-mute)">
      Total 7 jours : <strong style="color:var(--red)"><?= number_format(array_sum($data_7j),1) ?> hl</strong>
    </div>
  </div>

</div>

<?php ?>
<!-- ── Graphiques ─────────────────────────────────────────── -->
<?php
$j30 = jours_periode(30);
$st = $db->prepare("SELECT DATE(c.date_commande) d, SUM(c.total_hl) v FROM commandes c JOIN utilisateurs u ON u.id=c.commercial_id
  WHERE u.secteur_id=? AND c.statut NOT IN ('CREEE') AND c.date_commande >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY DATE(c.date_commande)");
$st->execute([$secteur_id]); $s_hl = serie($j30, $st->fetchAll());
$st = $db->prepare("SELECT DATE(v.date_visite) d, COUNT(*) v FROM visites v JOIN utilisateurs u ON u.id=v.commercial_id
  WHERE u.secteur_id=? AND v.statut='VISITE' AND v.date_visite >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY DATE(v.date_visite)");
$st->execute([$secteur_id]); $s_vis = serie($j30, $st->fetchAll());
$st = $db->prepare("SELECT CONCAT(u.prenom,' ',u.nom) l, COALESCE(SUM(c.total_hl),0) v,
    (SELECT COUNT(*) FROM visites vv WHERE vv.commercial_id=u.id AND vv.statut='VISITE' AND YEAR(vv.date_visite)=YEAR(CURDATE()) AND MONTH(vv.date_visite)=MONTH(CURDATE())) vis
  FROM utilisateurs u LEFT JOIN commandes c ON c.commercial_id=u.id AND c.statut NOT IN ('CREEE') AND YEAR(c.date_commande)=YEAR(CURDATE()) AND MONTH(c.date_commande)=MONTH(CURDATE())
  WHERE u.secteur_id=? AND u.role IN ('COMMERCIAL','MANAGER_INTERIM') AND u.actif=1 GROUP BY u.id ORDER BY v DESC");
$st->execute([$secteur_id]); $par_com = $st->fetchAll();
?>
<div style="margin-top:1rem">
<?= graphique('gEquipe', 'Volume et visites de l’équipe (30 derniers jours)', ['type'=>'bar','data'=>['labels'=>etiquettes_jours($j30),'datasets'=>[
  ['type'=>'bar','label'=>'Volume (hl)','data'=>array_values($s_hl),'backgroundColor'=>'rgba(232,0,28,.75)','borderRadius'=>4,'yAxisID'=>'y'],
  ['type'=>'line','label'=>'Visites réalisées','data'=>array_values($s_vis),'borderColor'=>'#1f9d55','backgroundColor'=>'#1f9d55','tension'=>.3,'yAxisID'=>'y1','pointRadius'=>2],
]],'options'=>['scales'=>['y'=>['beginAtZero'=>true,'title'=>['display'=>true,'text'=>'hl']],'y1'=>['beginAtZero'=>true,'position'=>'right','grid'=>['drawOnChartArea'=>false],'title'=>['display'=>true,'text'=>'visites']]]]], 280) ?>
<?= graphique('gCom', 'Volume du mois par commercial (base de la prime)', ['type'=>'bar','unite'=>'hl','data'=>['labels'=>array_column($par_com,'l'),'datasets'=>[
  ['label'=>'Volume du mois','data'=>array_map(fn($x)=>round((float)$x,2),array_column($par_com,'v')),'backgroundColor'=>'rgba(232,0,28,.75)','borderRadius'=>4]]],
  'options'=>['indexAxis'=>'y','plugins'=>['legend'=>['display'=>false]]]], max(160, 60 + 45*count($par_com))) ?>
</div>

<?php close_layout(); ?>

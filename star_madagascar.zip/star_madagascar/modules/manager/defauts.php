<?php
// ============================================================
// modules/manager/defauts.php
// ============================================================

require_once '../../includes/layout.php';
require_once '../../config/db.php';

$ctx  = include_layout('Défauts produits', ['MANAGER','MANAGER_INTERIM','ADMIN']);
$user = $ctx['user'];
$db   = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action   = $_POST['action'] ?? '';
  $defaut_id= (int)($_POST['defaut_id'] ?? 0);

  if ($defaut_id) {
    if ($action === 'valider') {
      $stmt = $db->prepare("
        UPDATE defauts_produits SET statut='VALIDE_MANAGER', manager_id=?
        WHERE id=? AND statut='SIGNALE'
      ");
      $stmt->execute([$user['id'], $defaut_id]);
      if (!$stmt->rowCount()) { header('Location: defauts.php'); exit; } // déjà traité

      // Notifier logistique
      foreach ($db->query("SELECT id FROM utilisateurs WHERE role='LOGISTIQUE' AND actif=1")->fetchAll() as $logistic) {
        $stmt = $db->prepare("
          INSERT INTO notifications (utilisateur_id, titre, message, type, reference_id)
          VALUES (?,?,?,'DEFAUT_PRODUIT',?)
        ");
        $stmt->execute([
          $logistic['id'],
          'Remplacement produit défectueux à préparer',
          'Défaut validé par manager — remplacement à préparer',
          $defaut_id
        ]);
      }
    } elseif ($action === 'rejeter') {
      $motif = trim($_POST['motif'] ?? 'Non conforme aux conditions de remplacement.');
      $stmt = $db->prepare("
        UPDATE defauts_produits SET statut='REJETE', motif_rejet=?, manager_id=?
        WHERE id=? AND statut='SIGNALE'
      ");
      $stmt->execute([$motif, $user['id'], $defaut_id]);
      if ($stmt->rowCount()) {
        // Prévenir le commercial du refus et du motif
        $db->prepare("INSERT INTO notifications (utilisateur_id,titre,message,type,reference_id)
                      SELECT commercial_id,'Défaut rejeté',?, 'DEFAUT_PRODUIT', id FROM defauts_produits WHERE id=?")
           ->execute(['Motif : ' . $motif, $defaut_id]);
      }
    }
    header('Location: defauts.php');
    exit;
  }
}

$stmt = $db->prepare("
  SELECT d.*, p.description AS produit_nom, p.code AS produit_code,
         c.code_commande, cl.nom AS client_nom,
         CONCAT(u.prenom,' ',u.nom) AS commercial_nom
  FROM defauts_produits d
  JOIN produits p ON d.produit_id = p.id
  JOIN commandes c ON d.commande_id = c.id
  JOIN clients cl ON c.client_id = cl.id
  JOIN utilisateurs u ON d.commercial_id = u.id
  WHERE d.manager_id = ?
  ORDER BY d.created_at DESC
");
$stmt->execute([$user['id']]);
$defauts = $stmt->fetchAll();

$en_attente = array_filter($defauts, fn($d) => $d['statut'] === 'SIGNALE');
$traites    = array_filter($defauts, fn($d) => $d['statut'] !== 'SIGNALE');
?>

<div class="page-header">
  <div class="page-header-top">
    <div>
      <div class="page-title">Défauts produits</div>
      <div class="page-subtitle"><?= count($en_attente) ?> signalement(s) à traiter</div>
    </div>
  </div>
</div>

<?php foreach ($en_attente as $d): ?>
<div class="card" style="margin-bottom:.8rem;border-color:rgba(232,0,28,.3)">
  <div style="display:grid;grid-template-columns:1fr auto;gap:1rem;align-items:start">
    <div>
      <div style="display:flex;align-items:center;gap:.6rem;margin-bottom:.5rem">
        <span style="font-size:.95rem;font-weight:700"><?= htmlspecialchars($d['produit_nom']) ?></span>
        <span class="badge badge-red">⚠️ Défaut signalé</span>
      </div>
      <div style="display:flex;gap:1rem;flex-wrap:wrap;font-size:.75rem;color:var(--text-mute);margin-bottom:.5rem">
        <span>Code : <strong><?= $d['produit_code'] ?></strong></span>
        <span>Quantité : <strong style="color:var(--red)"><?= $d['quantite'] ?> bouteille(s)</strong></span>
        <span>Commande : <strong><?= $d['code_commande'] ?></strong></span>
        <span>Client : <strong><?= htmlspecialchars($d['client_nom']) ?></strong></span>
      </div>
      <div style="font-size:.78rem;padding:.6rem .8rem;background:var(--bg3);border-radius:6px;margin-bottom:.4rem;line-height:1.5">
        <?= htmlspecialchars($d['description']) ?>
      </div>
      <div style="font-size:.7rem;color:var(--text-mute)">
        Signalé par <strong><?= htmlspecialchars($d['commercial_nom']) ?></strong>
        le <?= date('d/m/Y à H:i', strtotime($d['created_at'])) ?>
      </div>
    </div>
    <div style="display:flex;flex-direction:column;gap:.5rem;min-width:160px">
      <form method="POST">
        <input type="hidden" name="action" value="valider">
        <input type="hidden" name="defaut_id" value="<?= $d['id'] ?>">
        <button type="submit" class="btn btn-primary btn-sm" style="width:100%;justify-content:center">
          ✓ Valider → Logistique
        </button>
      </form>
      <button onclick="rejeterDefaut(<?= $d['id'] ?>)" class="btn btn-secondary btn-sm"
        style="width:100%;justify-content:center;color:var(--red)">
        ✗ Rejeter
      </button>
    </div>
  </div>
</div>
<?php endforeach; ?>

<?php if (!empty($traites)): ?>
<div class="card" style="padding:0;overflow:hidden;margin-top:1rem">
  <div style="padding:.9rem 1.2rem;border-bottom:1px solid var(--border);font-size:.85rem;font-weight:600">
    Historique des défauts traités
  </div>
  <table class="data-table">
    <thead>
      <tr><th>Produit</th><th>Client</th><th>Qté</th><th>Statut</th><th>Date</th></tr>
    </thead>
    <tbody>
      <?php foreach ($traites as $d): ?>
      <tr>
        <td><?= htmlspecialchars($d['produit_nom']) ?></td>
        <td><?= htmlspecialchars($d['client_nom']) ?></td>
        <td><?= $d['quantite'] ?></td>
        <td><?= match($d['statut']) {
          'VALIDE_MANAGER'         => "<span class='badge badge-blue'>Validé</span>",
          'REMPLACEMENT_CONFIRME'  => "<span class='badge badge-green'>Remplacé</span>",
          'REJETE'                 => "<span class='badge badge-red'>Rejeté</span>",
          default                  => "<span class='badge badge-mute'>{$d['statut']}</span>",
        } ?></td>
        <td style="font-size:.72rem"><?= date('d/m/Y', strtotime($d['created_at'])) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<!-- Modal rejet -->
<div id="modalRejet" style="display:none;position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.7);backdrop-filter:blur(4px);align-items:center;justify-content:center">
  <div class="modal-box" style="border:1px solid var(--border);border-radius:16px;
              padding:1.6rem;max-width:380px;width:90%">
    <div style="font-weight:700;margin-bottom:1rem">Motif du rejet</div>
    <form method="POST" id="formRejet">
      <input type="hidden" name="action" value="rejeter">
      <input type="hidden" name="defaut_id" id="rejetId">
      <textarea name="motif" rows="3"
        placeholder="Ex: produit falsifié, conditions non réunies..."
        style="width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;
               padding:.7rem .9rem;color:var(--text);font-size:.85rem;font-family:Inter,sans-serif;
               resize:vertical;margin-bottom:1rem"></textarea>
      <div style="display:flex;gap:.6rem">
        <button type="button" onclick="document.getElementById('modalRejet').style.display='none'"
          class="btn btn-secondary" style="flex:1;justify-content:center">Annuler</button>
        <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center;background:rgba(51,51,51,.15);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px)">
          Confirmer
        </button>
      </div>
    </form>
  </div>
</div>

<script>
function rejeterDefaut(id) {
  document.getElementById('rejetId').value = id;
  document.getElementById('modalRejet').style.display = 'flex';
}
</script>

<?php close_layout(); ?>

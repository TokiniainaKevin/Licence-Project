<?php
// ============================================================
// api/notifications.php
// Retourne les notifications non lues (polling AJAX)
// ============================================================

session_start();
require_once '../includes/auth_guard.php';
require_once '../config/db.php';

auth_guard();
$user = current_user();
$db   = getDB();

header('Content-Type: application/json');

$action = $_GET['action'] ?? 'lister';

if ($action === 'lister') {
  $stmt = $db->prepare("
    SELECT id, titre, message, type, reference_id, lu, created_at
    FROM notifications
    WHERE utilisateur_id = ?
    ORDER BY created_at DESC LIMIT 20
  ");
  $stmt->execute([$user['id']]);
  $notifs = $stmt->fetchAll();

  $nb_non_lues = count(array_filter($notifs, fn($n) => !$n['lu']));

  echo json_encode([
    'success'     => true,
    'notifications'=> $notifs,
    'nb_non_lues' => $nb_non_lues,
  ]);

} elseif ($action === 'marquer_lu') {
  $id = (int)($_GET['id'] ?? 0);
  if ($id) {
    $db->prepare("UPDATE notifications SET lu=1 WHERE id=? AND utilisateur_id=?")
      ->execute([$id, $user['id']]);
  } else {
    $db->prepare("UPDATE notifications SET lu=1 WHERE utilisateur_id=?")
      ->execute([$user['id']]);
  }
  echo json_encode(['success' => true]);
}

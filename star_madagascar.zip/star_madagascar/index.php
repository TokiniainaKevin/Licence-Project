<?php
require_once __DIR__ . '/includes/icones.php';
ob_start('embellir_icones');
session_start();
require_once 'config/db.php';

if (!empty($_SESSION['user_id'])) {
  $routes = [
    'ADMIN'           => 'modules/admin/dashboard.php',
    'DIRECTEUR'       => 'modules/admin/dashboard.php',
    'MANAGER'         => 'modules/manager/dashboard.php',
    'MANAGER_INTERIM' => 'modules/manager/dashboard.php',
    'COMMERCIAL'      => 'modules/commercial/dashboard.php',
    'LOGISTIQUE'      => 'modules/logistique/dashboard.php',
    'CAISSIER'        => 'modules/caissier/dashboard.php',
    'DISTRIBUTEUR'    => 'modules/distributeur/dashboard.php',
  ];
  header('Location: ' . ($routes[$_SESSION['user_role']] ?? 'index.php'));
  exit;
}

$error  = (int)($_GET['error'] ?? 0);
$logout = (int)($_GET['logout'] ?? 0);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="app-root" content="">
<title>Star Madagascar — Connexion</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;900&family=Space+Grotesk:wght@400;500;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{color-scheme:dark;--bg:#111111;--bg2:rgba(18,18,18,.42);--bg3:rgba(24,24,24,.62);--border:rgba(255,255,255,.14);--red:#E8001C;--red-dim:rgba(232,0,28,.12);--text:#f5f5f5;--text-mute:#b8b8b8;--text-dim:#d8d8d8}
body, .form-input, input { text-shadow: 0 1px 3px rgba(0,0,0,.85); }
html,body{height:100%;overflow:hidden}
body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);position:relative}
.slider-side{position:fixed;inset:0;overflow:hidden;height:100vh;z-index:0}
.slides{position:relative;height:100%}
.slide{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:flex-end;padding:3rem;opacity:0;transition:opacity 1.6s ease}
.slide.active{opacity:1}
.slide{
  background-image:
    linear-gradient(100deg,rgba(9,9,9,.62) 0%,rgba(9,9,9,.52) 32%,rgba(9,9,9,.40) 56%,rgba(9,9,9,.46) 78%,rgba(9,9,9,.58) 100%),
    var(--bg-img);
  background-repeat:no-repeat;
  background-position:center, 34% bottom;
  background-size:cover, auto 86%;
}
.slide::after{content:'';position:absolute;inset:0;background:radial-gradient(circle at 30% 30%, var(--accent-glow), transparent 50%);pointer-events:none}
.slide-content{position:relative;z-index:1;max-width:480px}
.slide-tag{display:inline-block;background:var(--accent,var(--red));color:#fff;font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:.25rem .7rem;border-radius:4px;margin-bottom:.8rem}
.slide-quote{font-family:'Space Grotesk',sans-serif;font-size:clamp(1.4rem,2.5vw,2rem);font-weight:700;line-height:1.2;margin-bottom:.5rem;text-shadow:0 2px 24px rgba(0,0,0,.7)}
.slide-sub{font-size:.85rem;color:rgba(255,255,255,.78);text-shadow:0 1px 10px rgba(0,0,0,.7)}
.slider-logo{position:absolute;top:2rem;left:2rem;z-index:10;font-family:'Space Grotesk',sans-serif;font-size:1.1rem;font-weight:700;display:flex;align-items:center;gap:.6rem}
.slider-logo-icon{width:36px;height:36px;border-radius:8px;background:var(--red);display:flex;align-items:center;justify-content:center;font-size:1.1rem}
.slide-dots{position:absolute;bottom:2rem;left:2rem;z-index:10;display:flex;gap:.4rem}
.dot{width:6px;height:6px;border-radius:3px;background:rgba(255,255,255,.3);transition:all .4s}
.dot.active{width:24px;background:var(--red)}
.slide-progress{position:absolute;top:0;left:0;right:0;height:2px;z-index:10;background:rgba(255,255,255,.08)}
.slide-progress-fill{height:100%;background:var(--red);width:0%;transition:width linear}
.login-side{position:fixed;top:0;right:0;width:420px;height:100vh;background:rgba(16,16,16,.09);backdrop-filter:blur(26px);-webkit-backdrop-filter:blur(26px);border-left:1px solid var(--border);display:flex;flex-direction:column;justify-content:center;padding:3rem 2.5rem;overflow:hidden;z-index:2}
.login-side::before{content:'';position:absolute;bottom:-100px;right:-100px;width:300px;height:300px;border-radius:50%;background:radial-gradient(circle,rgba(232,0,28,.25),transparent 70%);pointer-events:none}
.login-header{margin-bottom:2.8rem}
.login-welcome{font-size:.75rem;color:var(--red);font-weight:600;letter-spacing:.1em;text-transform:uppercase;margin-bottom:.6rem}
.login-title{font-family:'Space Grotesk',sans-serif;font-size:1.8rem;font-weight:700;line-height:1.15}
.login-sub{font-size:.82rem;color:var(--text-mute);margin-top:.5rem;line-height:1.5}
.form-group{margin-bottom:1.2rem}
.form-label{display:block;font-size:.72rem;font-weight:600;color:var(--text-dim);margin-bottom:.5rem;letter-spacing:.04em}
.form-input{width:100%;background:var(--bg3);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);border:1px solid var(--border);border-radius:10px;padding:.85rem 1rem;font-size:.9rem;font-family:'Inter',sans-serif;color:var(--text);outline:none;transition:border-color .2s,box-shadow .2s}
.form-input:focus{border-color:var(--red);box-shadow:0 0 0 3px var(--red-dim)}
.form-input::placeholder{color:#888}
.pw-wrap{position:relative}
.pw-toggle{position:absolute;right:.9rem;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-mute);cursor:pointer;font-size:.75rem;font-weight:500;padding:.2rem .4rem;border-radius:4px;transition:color .15s}
.pw-toggle:hover{color:var(--text)}
.btn-login{width:100%;padding:.9rem;background:rgba(232,0,28,.9);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border:none;border-radius:10px;color:#fff;font-size:.9rem;font-weight:600;font-family:'Inter',sans-serif;cursor:pointer;margin-top:.4rem;position:relative;overflow:hidden;transition:opacity .2s,transform .15s}
.btn-login:hover{opacity:.9;transform:translateY(-1px)}
.btn-login.loading{opacity:.7;pointer-events:none}
.btn-login .spinner{display:none;width:16px;height:16px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;margin:0 auto}
.btn-login.loading .spinner{display:block}
.btn-login.loading .btn-text{display:none}
@keyframes spin{to{transform:rotate(360deg)}}
.msg-box{border-radius:8px;padding:.7rem .9rem;font-size:.78rem;margin-bottom:1rem}
.msg-error{background:rgba(232,0,28,.12);border:1px solid rgba(232,0,28,.25);color:#ff8080}
.msg-success{background:rgba(0,200,100,.12);border:1px solid rgba(0,200,100,.25);color:#3ddb92}
.login-footer{position:absolute;bottom:1.5rem;left:2.5rem;right:2.5rem;text-align:center;font-size:.68rem;color:var(--text-mute);border-top:1px solid var(--border);padding-top:1rem}
.login-footer span{color:var(--red)}
@media(max-width:768px){
  html,body{overflow:auto}
  .login-side{position:fixed;top:auto;bottom:0;left:0;right:0;width:100%;height:64vh;border-left:none;border-top:1px solid var(--border);border-radius:20px 20px 0 0}
  .slide-content{max-width:none;right:1.5rem}
  .slide{padding:2rem}
}
</style>
</head>
<body>
<?php require_once __DIR__ . '/includes/slider_data.php'; $slides = slider_produits(); ?>
<div class="slider-side">
  <div class="slide-progress"><div class="slide-progress-fill" id="progressFill"></div></div>
  <div class="slider-logo"><img src="assets/images/logos/star_logo_white.png" alt="STAR Madagascar" style="height:46px;width:auto"></div>
  <div class="slides" id="slides">
    <?php foreach ($slides as $i => $s): ?>
    <div class="slide<?= $i === 0 ? ' active' : '' ?>" style="--bg-img:url('assets/images/produits/<?= $s['img'] ?>');--accent:<?= $s['accent'] ?>;--accent-glow:<?= $s['accent'] ?>33">
      <div class="slide-content">
        <div class="slide-tag"><?= htmlspecialchars($s['tag']) ?></div>
        <div class="slide-quote"><?= $s['quote'] ?></div>
        <div class="slide-sub"><?= htmlspecialchars($s['sub']) ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <div class="slide-dots">
    <?php foreach ($slides as $i => $s): ?><div class="dot<?= $i === 0 ? ' active' : '' ?>"></div><?php endforeach; ?>
  </div>
</div>

<div class="login-side">
  <div class="login-header">
    <div class="login-welcome">Bienvenue</div>
    <div class="login-title">Connectez-vous à<br>votre espace</div>
    <div class="login-sub">Accédez à votre tableau de bord selon votre profil.</div>
  </div>

  <?php if($error===1): ?><div class="msg-box msg-error">❌ Identifiants incorrects. Veuillez réessayer.</div><?php endif; ?>
  <?php if($error===2): ?><div class="msg-box msg-error">🔒 Compte désactivé. Contactez votre administrateur.</div><?php endif; ?>
  <?php if($error===3): ?><div class="msg-box msg-error">⏱️ Session expirée. Veuillez vous reconnecter.</div><?php endif; ?>
  <?php if($logout===1): ?><div class="msg-box msg-success">✅ Déconnexion réussie.</div><?php endif; ?>

  <form method="POST" action="auth/login.php" id="loginForm" autocomplete="off">
    <div class="form-group">
      <label class="form-label" for="email">Adresse email</label>
      <input class="form-input" type="email" id="email" name="email"
        placeholder="votre.email@star-madagascar.mg" autocomplete="off" value="" required>
    </div>
    <div class="form-group">
      <label class="form-label" for="password">Mot de passe</label>
      <div class="pw-wrap">
        <input class="form-input" type="password" id="password" name="password"
          placeholder="••••••••" autocomplete="new-password" value="" required>
        <button type="button" class="pw-toggle" id="pwToggle">Voir</button>
      </div>
    </div>
    <button type="submit" class="btn-login" id="btnLogin">
      <span class="btn-text">Se connecter</span>
      <div class="spinner"></div>
    </button>
  </form>

  <div class="login-footer">
    Problème de connexion ? Contactez votre <span>administrateur</span>.<br>
    Star Madagascar · Système de gestion interne v1.0
  </div>
</div>

<script>
const DURATION = 5000;
const slideEls = document.querySelectorAll('.slide');
const dotEls = document.querySelectorAll('.dot');
const fill = document.getElementById('progressFill');
let current = 0;
function showSlide(n) {
  slideEls[current].classList.remove('active');
  dotEls[current].classList.remove('active');
  current = n;
  slideEls[current].classList.add('active');
  dotEls[current].classList.add('active');
}
function next() { showSlide((current + 1) % slideEls.length); resetProgress(); }
function resetProgress() {
  fill.style.transition = 'none'; fill.style.width = '0%';
  requestAnimationFrame(() => { fill.style.transition = `width ${DURATION}ms linear`; fill.style.width = '100%'; });
}
resetProgress();
setInterval(next, DURATION);
document.getElementById('email').value = '';
document.getElementById('password').value = '';
setTimeout(function () {
  document.getElementById('email').value = '';
  document.getElementById('password').value = '';
}, 100);
document.getElementById('pwToggle').addEventListener('click', function () {
  const i = document.getElementById('password'); const t = i.type === 'text';
  i.type = t ? 'password' : 'text'; this.textContent = t ? 'Voir' : 'Cacher';
});
document.getElementById('loginForm').addEventListener('submit', function () {
  document.getElementById('btnLogin').classList.add('loading');
});
</script>
</body>
</html>

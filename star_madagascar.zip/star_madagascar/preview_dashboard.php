<?php
// ============================================================
// preview_dashboard.php — Aperçu autonome : slider produits + contenu
// du dashboard Admin, pour valider le style avant de l'appliquer
// partout. Basé sur modules/admin/dashboard.php (mêmes requêtes).
// À placer à la racine du projet (à côté de index.php).
// ============================================================
require_once __DIR__ . '/includes/auth_guard.php';
auth_guard(['ADMIN','DIRECTEUR']); // page d'aperçu : ne doit pas être publique
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/stock.php';
require_once __DIR__ . '/includes/slider_data.php';
$slides = slider_produits();

$db = getDB();

$stats = $db->query("
  SELECT
    (SELECT COUNT(*) FROM utilisateurs WHERE actif=1)                     AS nb_users,
    (SELECT COUNT(*) FROM clients WHERE statut='ACTIF')                    AS nb_clients,
    (SELECT COUNT(*) FROM commandes WHERE DATE(date_commande)=CURDATE())   AS nb_cmd_jour,
    (SELECT COALESCE(SUM(total_hl),0) FROM commandes
     WHERE DATE(date_commande)=CURDATE() AND statut NOT IN ('CREEE'))      AS hl_jour,
    (SELECT COUNT(*) FROM clients WHERE statut IN ('EN_ATTENTE','VALIDE_MANAGER')) AS nb_codes,
    (SELECT COUNT(*) FROM produits p
     " . stock_join_sql() . "
     WHERE COALESCE(se.total_btl,0) <= 0 AND p.actif=1)           AS nb_alertes
")->fetch();

$top_com = $db->query("
  SELECT CONCAT(u.prenom,' ',u.nom) AS nom, e.nom AS equipe,
         COALESCE(SUM(c.total_hl),0) AS hl, COUNT(c.id) AS nb_cmd
  FROM utilisateurs u
  LEFT JOIN commandes c ON c.commercial_id=u.id AND DATE(c.date_commande)=CURDATE() AND c.statut NOT IN ('CREEE')
  LEFT JOIN secteurs e ON u.secteur_id=e.id
  WHERE u.role IN ('COMMERCIAL','MANAGER_INTERIM') AND u.actif=1
  GROUP BY u.id ORDER BY hl DESC LIMIT 8
")->fetchAll();

$raccourcis = [
  ['👥', 'Utilisateurs',  'modules/admin/utilisateurs.php',  'Gérer les comptes et rôles'],
  ['🏪', 'Clients',       'modules/admin/clients.php',       'Codes clients, types, secteurs'],
  ['🍺', 'Produits',      'modules/admin/produits.php',      'Catalogue, prix, familles'],
  ['🗺️', 'Secteurs',      'modules/admin/secteurs.php',      'Zones et équipes commerciales'],
  ['🎯', 'Objectifs',     'modules/admin/objectifs.php',     'Objectif agence (mois/semaine/jour) et visites'],
  ['🆔', 'Codes clients', 'modules/admin/codes_clients.php', 'Valider les nouvelles demandes'],
  ['📦', 'Stock',         'modules/admin/stock.php',         'Entrepôt et alertes'],
  ['📋', 'Commandes',     'modules/admin/commandes.php',     'Toutes les commandes'],
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Star Madagascar — Aperçu dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;900&family=Space+Grotesk:wght@400;500;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  color-scheme: dark;
  --bg:#111111; --bg2:rgba(16,16,16,.09); --bg3:rgba(24,24,24,.62); --bg4:rgba(28,28,28,.55);
  --border:rgba(255,255,255,.14); --red:#E8001C; --red-dim:rgba(232,0,28,.14);
  --text:#ffffff; --text-dim:#e4e4e4; --text-mute:#b9b9b9; --amber:#ffa000;
}
html,body{min-height:100%;height:100%}
body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);position:relative;overflow:hidden}

/* ── Slider plein écran : le texte et l'effet de lumière sont conservés,
     mais en version beaucoup plus douce pour ne plus bloquer la vue ── */
.app-slider-bg{position:fixed;inset:0;z-index:0;overflow:hidden;pointer-events:none;background:#0c0c0c}
.app-slider-bg .bg-slide{
  position:absolute;inset:0;opacity:0;transition:opacity 1.6s ease;
  background-image:
    linear-gradient(100deg,rgba(9,9,9,.55) 0%,rgba(9,9,9,.40) 34%,rgba(9,9,9,.18) 58%,rgba(9,9,9,.38) 100%),
    var(--bg-img);
  background-repeat:no-repeat; background-position:center, right 3vw bottom -30px; background-size:cover, auto 88%;
}
.app-slider-bg .bg-slide.active{opacity:1}
.app-slider-bg .bg-slide::after{content:"";position:absolute;inset:0;background:radial-gradient(circle at 82% 28%, var(--accent-glow), transparent 50%)}
.app-slider-bg .bg-content{position:absolute;left:6vw;bottom:9vh;max-width:460px}
.app-slider-bg .bg-tag{display:inline-block;color:#fff;background:var(--accent,var(--red));font-size:.6rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:.25rem .6rem;border-radius:4px;margin-bottom:.7rem}
.app-slider-bg .bg-quote{font-family:'Space Grotesk',sans-serif;font-size:clamp(1.3rem,2.6vw,2.3rem);font-weight:700;line-height:1.18;color:#fff;text-shadow:0 2px 24px rgba(0,0,0,.7)}
.app-slider-bg .bg-sub{margin-top:.6rem;font-size:.75rem;color:rgba(255,255,255,.75);text-shadow:0 1px 10px rgba(0,0,0,.7)}

/* ── Contenu du dashboard, flottant au-dessus du slider ── */
.page{position:relative;z-index:1;height:100vh;max-width:1280px;margin:0 auto;padding:1.3rem 1.6rem 1.2rem;display:flex;flex-direction:column;overflow:hidden}
.page-header{margin-bottom:.9rem;flex:0 0 auto;padding-left:3.4rem}
.page-header-top{display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:.8rem}
.page-title{font-family:'Space Grotesk',sans-serif;font-size:1.4rem;font-weight:700;text-shadow:0 2px 16px rgba(0,0,0,.6)}
.page-subtitle{font-size:.78rem;color:var(--text-mute);margin-top:.2rem;text-shadow:0 1px 8px rgba(0,0,0,.6)}

.grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:.9rem;flex:0 0 auto;margin-bottom:.9rem}
.grid-2{display:grid;grid-template-columns:1.1fr .9fr;gap:.9rem;flex:1;min-height:0}
@media(max-width:1000px){.grid-4{grid-template-columns:repeat(2,1fr)}.grid-2{grid-template-columns:1fr}}

.card{
  background:var(--bg2); border:1px solid var(--border); border-radius:14px; padding:.9rem 1.05rem;
  backdrop-filter:blur(26px); -webkit-backdrop-filter:blur(26px);
  box-shadow:0 8px 22px rgba(0,0,0,.25);
}
.card-top-line{position:relative;overflow:hidden}
.card-top-line::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--red),transparent)}

.kpi-card{display:flex;flex-direction:column;gap:.4rem}
.kpi-label{font-size:.7rem;color:var(--text-mute);font-weight:600;letter-spacing:.03em;text-transform:uppercase;text-shadow:0 1px 6px rgba(0,0,0,.6)}
.kpi-value{font-family:'Space Grotesk',sans-serif;font-size:1.5rem;font-weight:700;color:#fff;text-shadow:0 1px 14px rgba(0,0,0,.7)}
.kpi-value .unit{font-size:.72rem;font-weight:500;color:var(--text-mute);margin-left:.2rem}

.btn{display:inline-flex;align-items:center;gap:.4rem;padding:.5rem .85rem;border-radius:8px;font-size:.76rem;font-weight:600;text-decoration:none;border:1px solid transparent;transition:transform .15s,border-color .15s,background .15s;cursor:pointer}
.btn-secondary{background:rgba(255,255,255,.06);border:1px solid var(--border);color:var(--text)}
.btn-secondary:hover{background:rgba(255,255,255,.14)}
.btn-amber{background:rgba(255,160,0,.14);border:1px solid rgba(255,160,0,.55);color:var(--amber)}
.btn-amber:hover{background:rgba(255,160,0,.24)}
.btn-danger{background:rgba(232,0,28,.14);border:1px solid rgba(232,0,28,.55);color:#ff5c5c}
.btn-danger:hover{background:rgba(232,0,28,.24)}

.data-table{width:100%;border-collapse:collapse;font-size:.8rem}
.data-table th{text-align:left;font-size:.66rem;text-transform:uppercase;letter-spacing:.04em;color:var(--text-mute);padding:.55rem 1rem;border-bottom:1px solid var(--border);background:rgba(255,255,255,.03);position:sticky;top:0}
.data-table td{padding:.5rem 1rem;border-bottom:1px solid rgba(255,255,255,.06);color:var(--text-dim)}
.data-table tr:last-child td{border-bottom:none}
.data-table tr:hover td{background:rgba(255,255,255,.05)}
.table-scroll{overflow-y:auto;height:100%}

.shortcut{display:block;text-decoration:none;color:inherit;transition:transform .15s,border-color .15s}
.shortcut:hover{transform:translateY(-2px);border-color:var(--red) !important}
.shortcut-icon{width:32px;height:32px;border-radius:9px;background:rgba(232,0,28,.16);display:flex;align-items:center;justify-content:center;font-size:1rem;margin-bottom:.4rem}
.shortcut-title{font-size:.8rem;font-weight:700;color:#fff;margin-bottom:.15rem}
.shortcut-desc{font-size:.66rem;color:var(--text-mute);line-height:1.35}
.shortcuts-grid{display:grid;grid-template-columns:1fr 1fr;gap:.6rem;height:100%;overflow-y:auto}
.shortcuts-grid .card{padding:.75rem .85rem}

/* ── Menu hamburger : tiroir qui s'ouvre vers la droite ── */
.hamburger{position:fixed;top:1.1rem;left:1.2rem;z-index:60;width:42px;height:42px;border-radius:10px;
  background:rgba(255,255,255,.08);border:1px solid var(--border);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);
  display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background .15s}
.hamburger:hover{background:rgba(255,255,255,.16)}
.hamburger span{display:block;width:18px;height:2px;background:#fff;position:relative;transition:background .2s}
.hamburger span::before,.hamburger span::after{content:'';position:absolute;left:0;width:18px;height:2px;background:#fff;transition:transform .25s}
.hamburger span::before{top:-6px}
.hamburger span::after{top:6px}
.hamburger.open span{background:transparent}
.hamburger.open span::before{transform:translateY(6px) rotate(45deg)}
.hamburger.open span::after{transform:translateY(-6px) rotate(-45deg)}

.drawer-overlay{position:fixed;inset:0;background:rgba(0,0,0,.35);z-index:55;opacity:0;pointer-events:none;transition:opacity .3s}
.drawer-overlay.open{opacity:1;pointer-events:auto}
.side-drawer{position:fixed;top:0;left:0;bottom:0;width:280px;z-index:58;
  background:rgba(16,16,16,.5);backdrop-filter:blur(28px);-webkit-backdrop-filter:blur(28px);
  border-right:1px solid var(--border);padding:5rem 1rem 1.5rem;overflow-y:auto;
  transform:translateX(-100%);transition:transform .32s cubic-bezier(.4,0,.2,1)}
.side-drawer.open{transform:translateX(0)}
.side-drawer .drawer-title{font-size:.68rem;text-transform:uppercase;letter-spacing:.08em;color:var(--text-mute);padding:0 .7rem;margin-bottom:.6rem}
.side-drawer a{display:flex;align-items:center;gap:.7rem;padding:.65rem .7rem;border-radius:9px;color:var(--text-dim);text-decoration:none;font-size:.84rem;margin-bottom:.2rem;transition:background .15s,color .15s}
.side-drawer a:hover{background:rgba(255,255,255,.08);color:#fff}
.side-drawer a .ico{width:20px;text-align:center;font-size:1rem}

@media(prefers-reduced-motion:reduce){.app-slider-bg .bg-slide{transition:none}}
</style>
</head>
<body>

<div class="app-slider-bg" aria-hidden="true">
  <?php foreach ($slides as $i => $s): ?>
  <div class="bg-slide<?= $i === 0 ? ' active' : '' ?>" style="--bg-img:url('assets/images/produits/<?= $s['img'] ?>');--accent:<?= $s['accent'] ?>;--accent-glow:<?= $s['accent'] ?>40">
    <div class="bg-content">
      <div class="bg-tag"><?= htmlspecialchars($s['tag']) ?></div>
      <div class="bg-quote"><?= $s['quote'] ?></div>
      <div class="bg-sub"><?= htmlspecialchars($s['sub']) ?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<div class="hamburger" id="hamburger" onclick="toggleDrawer()"><span></span></div>
<div class="drawer-overlay" id="drawerOverlay" onclick="toggleDrawer(false)"></div>
<nav class="side-drawer" id="sideDrawer">
  <div class="drawer-title">Administration</div>
  <a href="preview_dashboard.php"><span class="ico">📊</span> Tableau de bord</a>
  <?php foreach ($raccourcis as [$ico, $titre, $url, $desc]): ?>
  <a href="<?= $url ?>"><span class="ico"><?= $ico ?></span> <?= htmlspecialchars($titre) ?></a>
  <?php endforeach; ?>
  <div class="drawer-title" style="margin-top:1.2rem">Compte</div>
  <a href="modules/common/profil.php"><span class="ico">👤</span> Mon profil</a>
  <a href="auth/logout.php"><span class="ico">🚪</span> Déconnexion</a>
</nav>

<div class="page">
  <div class="page-header">
    <div class="page-header-top">
      <div>
        <div class="page-title">Administration</div>
        <div class="page-subtitle"><?= date('d/m/Y H:i') ?> — Vue globale</div>
      </div>
      <div style="display:flex;gap:.6rem;flex-wrap:wrap">
        <?php if ($stats['nb_codes'] > 0): ?>
        <a href="modules/admin/codes_clients.php" class="btn btn-amber">🆔 <?= $stats['nb_codes'] ?> code(s) à traiter</a>
        <?php endif; ?>
        <?php if ($stats['nb_alertes'] > 0): ?>
        <a href="modules/admin/stock.php?filtre=alerte" class="btn btn-danger">⚠️ <?= $stats['nb_alertes'] ?> alerte(s) stock</a>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="grid-4" style="margin-bottom:1.2rem">
    <div class="card card-top-line kpi-card">
      <div class="kpi-label">Utilisateurs actifs</div>
      <div class="kpi-value"><?= $stats['nb_users'] ?></div>
      <a href="modules/admin/utilisateurs.php" style="font-size:.72rem;color:var(--red)">Gérer →</a>
    </div>
    <div class="card card-top-line kpi-card">
      <div class="kpi-label">Clients actifs</div>
      <div class="kpi-value"><?= $stats['nb_clients'] ?></div>
      <a href="modules/admin/clients.php" style="font-size:.72rem;color:var(--red)">Gérer →</a>
    </div>
    <div class="card card-top-line kpi-card">
      <div class="kpi-label">Commandes aujourd'hui</div>
      <div class="kpi-value"><?= $stats['nb_cmd_jour'] ?> <span class="unit"><?= number_format($stats['hl_jour'],2) ?> Hl</span></div>
      <a href="modules/admin/commandes.php" style="font-size:.72rem;color:var(--red)">Voir →</a>
    </div>
    <div class="card card-top-line kpi-card">
      <div class="kpi-label">Alertes stock</div>
      <div class="kpi-value" style="color:<?= $stats['nb_alertes']>0?'var(--amber)':'var(--text)' ?>">
        <?= $stats['nb_alertes'] ?> <span class="unit">produits</span>
      </div>
      <a href="modules/admin/stock.php" style="font-size:.72rem;color:var(--amber)">Voir stock →</a>
    </div>
  </div>

  <div class="grid-2">
    <div class="card" style="padding:0;overflow:hidden;display:flex;flex-direction:column;background:rgba(14,14,14,.06)">
      <div style="padding:.7rem 1.1rem;border-bottom:1px solid var(--border);font-size:.82rem;font-weight:700;flex:0 0 auto">
        Performances commerciaux — Aujourd'hui
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>Commercial</th><th>Équipe</th><th style="text-align:right">Hl</th><th style="text-align:center">Cmd</th></tr></thead>
          <tbody>
            <?php if (!$top_com): ?>
            <tr><td colspan="4" style="text-align:center;color:var(--text-mute);padding:1.2rem">Aucune activité aujourd'hui</td></tr>
            <?php endif; ?>
            <?php foreach ($top_com as $c): ?>
            <tr>
              <td style="font-weight:600;color:#fff"><?= htmlspecialchars($c['nom']) ?></td>
              <td style="font-size:.75rem;color:var(--text-mute)"><?= htmlspecialchars($c['equipe'] ?? '—') ?></td>
              <td style="text-align:right;font-weight:700;color:<?= $c['hl']>0?'var(--red)':'var(--text-mute)' ?>"><?= number_format($c['hl'],2) ?></td>
              <td style="text-align:center"><?= $c['nb_cmd'] ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="shortcuts-grid">
      <?php foreach ($raccourcis as [$ico, $titre, $url, $desc]): ?>
      <a href="<?= $url ?>" class="card shortcut">
        <div class="shortcut-icon"><?= $ico ?></div>
        <div class="shortcut-title"><?= htmlspecialchars($titre) ?></div>
        <div class="shortcut-desc"><?= htmlspecialchars($desc) ?></div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<script>
function toggleDrawer(force) {
  const drawer = document.getElementById('sideDrawer');
  const overlay = document.getElementById('drawerOverlay');
  const burger = document.getElementById('hamburger');
  const open = typeof force === 'boolean' ? force : !drawer.classList.contains('open');
  drawer.classList.toggle('open', open);
  overlay.classList.toggle('open', open);
  burger.classList.toggle('open', open);
}
(function(){
  const slides = document.querySelectorAll('.app-slider-bg .bg-slide');
  if (!slides.length) return;
  let i = 0;
  setInterval(function(){
    slides[i].classList.remove('active');
    i = (i + 1) % slides.length;
    slides[i].classList.add('active');
  }, 5000);
})();
</script>
</body>
</html>

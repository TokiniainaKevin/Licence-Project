-- ============================================================
-- migration_correctifs.sql
-- À exécuter UNE FOIS sur une base star_madagascar DÉJÀ installée
-- (inutile si vous réimportez star_madagascar_base.sql, qui contient déjà tout).
-- ============================================================
SET NAMES utf8mb4;
USE `star_madagascar`;

-- 1) Objectif global agence : commercial_id doit pouvoir être NULL
--    (sinon l'import de base plantait et la saisie de l'objectif HL agence échouait)
ALTER TABLE `objectifs` MODIFY `commercial_id` INT UNSIGNED DEFAULT NULL
  COMMENT 'NULL = objectif global de l agence (HL)';

-- 2) Nouveau rôle CAISSIER + traçabilité des paiements
ALTER TABLE `utilisateurs` MODIFY `role` ENUM('ADMIN','DIRECTEUR','MANAGER','MANAGER_INTERIM',
  'COMMERCIAL','LOGISTIQUE','CAISSIER','DISTRIBUTEUR') NOT NULL;
ALTER TABLE `commandes`
  ADD COLUMN `caissier_id`   INT UNSIGNED DEFAULT NULL COMMENT 'Caissier ayant confirme le paiement' AFTER `reference_paiement`,
  ADD COLUMN `date_paiement` DATETIME DEFAULT NULL COMMENT 'Date/heure de confirmation du paiement' AFTER `caissier_id`,
  ADD CONSTRAINT `fk_commandes_caissier` FOREIGN KEY (`caissier_id`) REFERENCES `utilisateurs`(`id`) ON UPDATE CASCADE;
INSERT IGNORE INTO `utilisateurs` (`nom`,`prenom`,`email`,`mot_de_passe`,`telephone`,`role`)
VALUES ('Randria','Nirina','caissier@star-madagascar.mg', SHA2('Test@2025',256), '0341000008', 'CAISSIER');

-- 3) Grille de consigne officielle (verre uniquement)
UPDATE `produits` SET
  `consigne_bouteille` = CASE WHEN `type_emballage`<>'VER' THEN 0
                              WHEN `contenance_cl`>=100 THEN 700
                              WHEN `contenance_cl`>=65  THEN 500
                              ELSE 400 END,
  `consigne_casier`    = CASE WHEN `type_emballage`='VER' THEN 8000 ELSE 0 END;
UPDATE `produits` SET `pag_kit_loge` = `pag_kit_nu` + `kit`*`consigne_bouteille` + `consigne_casier`;

-- 4) Anciens remplacements de défauts : la quantité (en bouteilles) avait été
--    enregistrée comme des CASIERS. On la remet en bouteilles.
UPDATE `mouvements_stock` SET `quantite_bouteilles` = `quantite_casiers`, `quantite_casiers` = 0
WHERE `type`='RETOUR_DEFAUT' AND `quantite_bouteilles`=0 AND `quantite_casiers`>0;

-- ============================================================
-- Version 20
-- ============================================================
-- 5) Photo de profil
ALTER TABLE `utilisateurs` ADD COLUMN `photo` VARCHAR(255) DEFAULT NULL
  COMMENT 'Photo de profil (assets/images/profils/)' AFTER `statut_presence`;
-- 6) Objectif agence : les lignes semaine/jour sont désormais générées par
--    l'application à l'enregistrement de l'objectif mensuel (rien à migrer :
--    un objectif mensuel existant est découpé automatiquement à l'affichage).

-- ============================================================
-- Version 21 : consigne selon la grille officielle STAR
--   30/33 cl 400 Ar · 50 cl 500 Ar (Booster 400 Ar) · 65 cl 500 Ar ·
--   100 cl et plus 700 Ar · casier 8 000 Ar · PET et canettes 0
-- ============================================================
UPDATE `produits` SET
  `consigne_bouteille` = CASE WHEN `type_emballage`<>'VER' THEN 0
                              WHEN `contenance_cl`>=100 THEN 700
                              WHEN `contenance_cl`>=65  THEN 500
                              WHEN `contenance_cl`>=50  THEN IF(`famille` LIKE '%Booster%', 400, 500)
                              ELSE 400 END,
  `consigne_casier`    = CASE WHEN `type_emballage`='VER' THEN 8000 ELSE 0 END;
UPDATE `produits` SET `pag_kit_loge` = `pag_kit_nu` + `kit`*`consigne_bouteille` + `consigne_casier`;
